#pragma once
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
/********************************************************************
 FileName:		Form1.h
 Dependencies:	Windows Server 2003 Platform SDK during development.  
				Also need WDK 6001.18001 (see includes section for 
				additional details).  When compiled, needs .NET 
				framework 2.0 redistributable to run.  May also
				need MS VC++ redistributable to run.
 Hardware:		Need a free USB port to connect USB peripheral device
				programming with appropriate WinUSB firmware.  VID and
				PID in firmware must match the VID and PID in this
				program.
 Compiler:  	Microsoft Visual C++ 2005 Express Edition (or better)
 Company:		Microchip Technology, Inc.

 Software License Agreement:

 The software supplied herewith by Microchip Technology Incorporated
 (the �Company�) for its PIC� Microcontroller is intended and
 supplied to you, the Company�s customer, for use solely and
 exclusively with Microchip PIC Microcontroller products. The
 software is owned by the Company and/or its supplier, and is
 protected under applicable copyright laws. All rights are reserved.
 Any use in violation of the foregoing restrictions may subject the
 user to criminal sanctions under applicable laws, as well as to
 civil liability for the breach of the terms and conditions of this
 license.

 THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.

********************************************************************
 File Description:

 Change History:
  Rev   Date         Description
  1.0   05/21/2008   Initial release
  2.3	08/11/2008	 Slight update for improved robustness
  2.7a	08/29/2010	 Adding explicit calling conventions to the DllImports.
					 This is needed for Visual Studio 2010 compatibility.
					 No functional changes to the code.  Backwards compatibility
					 should be retained.  Also modified the #include <Winusb.h>
					 inline comment, as it also contains information relevant
					 when building this project with Visual Studio 2010.
********************************************************************
NOTE:	All user made code contained in this project is in the Form1.h file.
		All other code and files were generated automatically by either the
		new project wizard, or by the development environment (ex: code is
		automatically generated if you create a new button on the form, and
		then double click on it, which creates a click event handler
		function).  All user made code is contained in clearly marked cut and
		paste blocks.
********************************************************************/

//Includes
#include <Windows.h>	//Definitions for various common and not so common types like DWORD, PCHAR, HANDLE, etc.
#include <Dbt.h>		//Need this for definitions of WM_DEVICECHANGE messages
#include <setupapi.h>	//From Windows Server 2003 R2 Platform SDK.  Untested with Windows SDK.  Setupapi.h provides
						//definitions needed for the SetupDixxx() functions, which we use to find our plug and 
						//play device.  If getting build errors when trying to compile this project, make sure the
						//platform SDK is correctly installed, and that it has been integrated into the VC++ development
						//environment.  In other words, make sure the include paths have been setup correctly in this IDE.
						//Microsoft created some small tutorial videos showing how to do this.
						//These may be located at:
						//http://msdn.microsoft.com/en-us/visualc/aa336415.aspx 
						//The link is functional as of 21 May 2008, but could move.  If the above link does not work,
						//try searching for "Video1_PSDK.wmv", which may be associated with:
						//"Using Visual C++ Express Edition and the Platform SDK"
						//Also see the below comments on how to add directories to the include path.


						//IMPORTANT: READ THIS BEFORE TRYING TO BUILD THIS CODE
						//----------------------------------------------------
#include <Winusb.h>		//Winusb.h comes as a part of the Windows Driver Kit (WDK) build 6001.18002 (and later versions).
						//The WDK is a free download from http://connect.microsoft.com (must create an account
						//and then sign up for the WDK connection).
						//You will need the WDK build 6001.18002 (or later) installed on
						//your computer to use this source code.  Once you have it installed, you will also need to add
						//the include path directories from the WDK to your VC++ IDE.  This can be done by clicking
						//Tools-->Options-->+Projects and Solutions-->VC++ Directories-->Show Directories for: "Include files"
						//Then click the Folder icon (new line) and then the "..." button and add these directories (to the 
						//bottom of the list!  The order of the list is important, and the project will not build correctly
						//if the order is wrong.):
						//C:\WINDDK\6001.18002\inc\ddk		
						//C:\WINDDK\6001.18002\inc\api		
						//The above directory locations assume the default location for the WDK, build 6001.18002.
						//Change the directory if installed in a different location, or if a different version of the WDK
						//was used.
						//If the above procedure is not followed correctly, a variety of build errors looking for various
						//files such as winusbio.h, usb200.h, usb100.h, usb.h, etc. will occur.

						//Special note for Microsoft Visual C++ 2010: The "Tools-->Options-->+Projects and Solutions-->VC++ Directories"
						//menu area is deprecated in MS VC++ 2010.  The included paths can instead be added to the project by
						//Clicking: Project-->[project name] Properties...-->+Configuration Properties-->VC++ Directories.			
							//NOTE: if the "Project" menu only shows "Properties", this means you have a file (ex: Form1.h) selected 
							//in the solution explorer, and you are trying to edit the properties specific to that file.  Therefore, 
							//make sure you deselect the file before clicking "Project" (you can do this by clicking somewhere else, 
							//ex: in this editor text area).  Only then will the Project --> "[project name] Properties..." option 
							//appear in the menu.
						//In the "Configuration" drop down box, select "All Configurations".
						//Then in the "Include Directories" entry, add the [wdk install dir]\inc\ddk and [wdk install dir]\inc\api path 
						//entries at the END OF THE EXISTING LIST (must be the end of the list, the order is important).
						//If using the WDK 7600, the Include Directories list would look something (or maybe exactly) like this:
						//$(VCInstallDir)include;$(VCInstallDir)atlmfc\include;$(WindowsSdkDir)include;$(FrameworkSDKDir)\include;C:\WinDDK\7600.16385.0\inc\ddk;C:\WinDDK\7600.16385.0\inc\api						


#include "rollingTrace.h"
#include "simpleTransmit.h"
#include "registerView.h"
#include "hardwareSetup.h"
#include "fixedTrace.h"
#include "toolStatus.h"
#include "testForm.h"
#include "LogFileSetup.h"


//Modify this value to match the VID and PID in your USB device descriptor.
//Use the formatting: "Vid_xxxx&Pid_xxxx" where xxxx is a 16-bit hexadecimal number.
#define MY_DEVICE_ID  "Vid_04d8&Pid_0A30"	
//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------


namespace SimpleWinUSBDemo {
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
    using namespace System::Threading;
	using namespace System::IO;

#include "myForms.h"	
    

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------
	using namespace System::Runtime::InteropServices;  //Need this to support "unmanaged" code.

	/*
	In order to use these unmanaged functions from within the managed .NET environment, we need
	to explicitly import the functions which we will be using from other .DLL file(s).  Simply
	including the appropriate header files is not enough. 

	Note: In order to avoid potential name conflicts in the header files (which we still use),
	I have renamed the functions by adding "UM" (unmanaged) onto the end of them.  To find 
	documentation for the functions in MSDN, search for the function name without the extra 
	"UM" attached.
	Note2: In the header files (such as setupapi.h), normally the function names are 
	remapped, depending upon if UNICODE is defined or not.  For example, two versions of the
	function SetupDiGetDeviceInterfaceDetail() exist.  One for UNICODE, and one for ANSI.  
	If the wrong version of the function is called, things won't work correctly.  Therefore,
	in order to make sure the correct one gets called (based on your compiler settings, which
	may or may not define "UNICODE"), it is useful to explicity specify the CharSet when doing
	the DLL import.
	*/

	#ifdef UNICODE
	#define	Seeifdef	Unicode
	#else
	#define Seeifdef	Ansi
	#endif

	//Returns a HDEVINFO type for a device information set (WinUSB devices in
	//our case).  We will need the HDEVINFO as in input parameter for calling many of
	//the other SetupDixxx() functions.
	[DllImport("setupapi.dll" , CharSet = CharSet::Seeifdef, EntryPoint="SetupDiGetClassDevs", CallingConvention=CallingConvention::Winapi)]		
	extern "C" HDEVINFO  SetupDiGetClassDevsUM(
		LPGUID  ClassGuid,					//Input: Supply the class GUID here. 
		PCTSTR  Enumerator,					//Input: Use NULL here, not important for our purposes
		HWND  hwndParent,					//Input: Use NULL here, not important for our purposes
		DWORD  Flags);						//Input: Flags describing what kind of filtering to use.

	//Gives us "PSP_DEVICE_INTERFACE_DATA" which contains the Interface specific GUID (different
	//from class GUID).  We need the interface GUID to get the device path.
	[DllImport("setupapi.dll" , CharSet = CharSet::Seeifdef, EntryPoint="SetupDiEnumDeviceInterfaces", CallingConvention=CallingConvention::Winapi)]				
	extern "C" WINSETUPAPI BOOL WINAPI  SetupDiEnumDeviceInterfacesUM(
		HDEVINFO  DeviceInfoSet,			//Input: Give it the HDEVINFO we got from SetupDiGetClassDevs()
		PSP_DEVINFO_DATA  DeviceInfoData,	//Input (optional)
		LPGUID  InterfaceClassGuid,			//Input 
		DWORD  MemberIndex,					//Input: "Index" of the device you are interested in getting the path for.
		PSP_DEVICE_INTERFACE_DATA  DeviceInterfaceData);//Output: This function fills in an "SP_DEVICE_INTERFACE_DATA" structure.

	//SetupDiDestroyDeviceInfoList() frees up memory by destroying a DeviceInfoList
	[DllImport("setupapi.dll" , CharSet = CharSet::Seeifdef, EntryPoint="SetupDiDestroyDeviceInfoList", CallingConvention=CallingConvention::Winapi)]
	extern "C" WINSETUPAPI BOOL WINAPI  SetupDiDestroyDeviceInfoListUM(			
		HDEVINFO  DeviceInfoSet);			//Input: Give it a handle to a device info list to deallocate from RAM.

	//SetupDiEnumDeviceInfo() fills in an "SP_DEVINFO_DATA" structure, which we need for SetupDiGetDeviceRegistryProperty()
	[DllImport("setupapi.dll" , CharSet = CharSet::Seeifdef, EntryPoint="SetupDiEnumDeviceInfo", CallingConvention=CallingConvention::Winapi)]
	extern "C" WINSETUPAPI BOOL WINAPI  SetupDiEnumDeviceInfoUM(
		HDEVINFO  DeviceInfoSet,
		DWORD  MemberIndex,
		PSP_DEVINFO_DATA  DeviceInfoData);

	//SetupDiGetDeviceRegistryProperty() gives us the hardware ID, which we use to check to see if it has matching VID/PID
	[DllImport("setupapi.dll" , CharSet = CharSet::Seeifdef, EntryPoint="SetupDiGetDeviceRegistryProperty", CallingConvention=CallingConvention::Winapi)]
	extern "C"	WINSETUPAPI BOOL WINAPI  SetupDiGetDeviceRegistryPropertyUM(
		HDEVINFO  DeviceInfoSet,
		PSP_DEVINFO_DATA  DeviceInfoData,
		DWORD  Property,
		PDWORD  PropertyRegDataType,
		PBYTE  PropertyBuffer,   
		DWORD  PropertyBufferSize,  
		PDWORD  RequiredSize);

	//SetupDiGetDeviceInterfaceDetail() gives us a device path, which is needed before CreateFile() can be used.
	[DllImport("setupapi.dll" , CharSet = CharSet::Seeifdef, EntryPoint="SetupDiGetDeviceInterfaceDetail", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL SetupDiGetDeviceInterfaceDetailUM(
		HDEVINFO DeviceInfoSet,										//Input: Wants HDEVINFO which can be obtained from SetupDiGetClassDevs()
		PSP_DEVICE_INTERFACE_DATA DeviceInterfaceData,				//Input: Pointer to an structure which defines the device interface.  
		PSP_DEVICE_INTERFACE_DETAIL_DATA DeviceInterfaceDetailData,	//Output: Pointer to a strucutre, which will contain the device path.
		DWORD DeviceInterfaceDetailDataSize,						//Input: Number of bytes to retrieve.
		PDWORD RequiredSize,										//Output (optional): Te number of bytes needed to hold the entire struct 
		PSP_DEVINFO_DATA DeviceInfoData);							//Output

	//Need this function for receiving all of the WM_DEVICECHANGE messages.  See MSDN documentation for
	//description of what this function does/how to use it. Note: name is remapped "RegisterDeviceNotificationUM" to
	//avoid possible build error conflicts.
	[DllImport("user32.dll" , CharSet = CharSet::Seeifdef, EntryPoint="RegisterDeviceNotification", CallingConvention=CallingConvention::Winapi)]					
	extern "C" HDEVNOTIFY WINAPI RegisterDeviceNotificationUM(
		HANDLE hRecipient,
		LPVOID NotificationFilter,
		DWORD Flags);

	//WinUsb_Initialize() needs to be called before the application can begin sending/receiving data with the USB device.
	[DllImport("winusb.dll" , CharSet = CharSet::Seeifdef, EntryPoint="WinUsb_Initialize", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL WinUsb_Initialize(
		HANDLE	DeviceHandle,
		PWINUSB_INTERFACE_HANDLE InterfaceHandle);

	//WinUsb_ResetPipe() is the basic function used to write data to the USB device (sends data to OUT endpoints on the device)
	[DllImport("winusb.dll" , CharSet = CharSet::Seeifdef, EntryPoint="WinUsb_ResetPipe", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL WinUsb_ResetPipe(
		WINUSB_INTERFACE_HANDLE InterfaceHandle,
		UCHAR PipeID);



	//WinUsb_Free()
	[DllImport("winusb.dll" , CharSet = CharSet::Seeifdef, EntryPoint="WinUsb_Free", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL WinUsb_Free(
		WINUSB_INTERFACE_HANDLE  InterfaceHandle 
		);



	//WinUsb_FlushPipe() is the basic function used to write data to the USB device (sends data to OUT endpoints on the device)
	[DllImport("winusb.dll" , CharSet = CharSet::Seeifdef, EntryPoint="WinUsb_FlushPipe", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL WinUsb_FlushPipe(
		WINUSB_INTERFACE_HANDLE InterfaceHandle,
		UCHAR PipeID
		);


	//WinUsb_SetPipePolicy()
	[DllImport("winusb.dll" , CharSet = CharSet::Seeifdef, EntryPoint="WinUsb_SetPipePolicy", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL WinUsb_SetPipePolicy(
		WINUSB_INTERFACE_HANDLE  InterfaceHandle,
		UCHAR  PipeID,
		ULONG  PolicyType,
		ULONG  ValueLength,
		PVOID  Value
		);


	//WinUsb_WritePipe() is the basic function used to write data to the USB device (sends data to OUT endpoints on the device)
	[DllImport("winusb.dll" , CharSet = CharSet::Seeifdef, EntryPoint="WinUsb_WritePipe", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL WinUsb_WritePipe(
		WINUSB_INTERFACE_HANDLE InterfaceHandle,
		UCHAR PipeID,
		PUCHAR Buffer,
		ULONG BufferLength,
		PULONG LengthTransferred,
		LPOVERLAPPED Overlapped);

	//WinUsb_ReadPipe() is the basic function used to read data from the USB device (polls for and obtains data from
	//IN endpoints on the device)
	[DllImport("winusb.dll" , CharSet = CharSet::Seeifdef, EntryPoint="WinUsb_ReadPipe", CallingConvention=CallingConvention::Winapi)]
	extern "C" BOOL WinUsb_ReadPipe(
		WINUSB_INTERFACE_HANDLE InterfaceHandle,
		UCHAR PipeID,
		PUCHAR Buffer,
		ULONG BufferLength,
		PULONG LengthTransferred,
		LPOVERLAPPED Overlapped);


//  Variables that need to have wide scope.
	HANDLE MyDeviceHandle = INVALID_HANDLE_VALUE;		//First need to get the Device handle
	WINUSB_INTERFACE_HANDLE MyWinUSBInterfaceHandle;	//And then can call WinUsb_Initialize() to get the interface handle
														//which is needed for doing other operations with the device (like
														//reading and writing to the USB device).


//	HANDLE DeviceInterfaceHandle = INVALID_HANDLE_VALUE;

#pragma region Global Variables

	/*** This section is all of the global variables related to this namespace ***/

	//Globally Unique Identifier (GUID). Windows uses GUIDs to identify things.  This GUID needs to match
	//the GUID that is used in the .INF file used to install the WinUSB driver onto the system.
	//The INF file creates a register entry which associates a GUID with the WinUSB device.  In order for
	//a user mode application (such as this one) to find the USB device on the bus, it needs to known the
	//correct GUID that got put into the registry.
	GUID InterfaceClassGuid = {0x58D07210, 0x27C1, 0x11DD, 0xBD, 0x0B, 0x08, 0x00, 0x20, 0x0C, 0x9A, 0x66}; 

	BOOL AttachedState = FALSE;						//Need to keep track of the USB device attachment status for proper plug and play operation.
	BOOL AttachedButBroken = FALSE;					
	PSP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA;	//Global
    unsigned char data;
	BOOL PushbuttonPressed = FALSE;		//Updated by ReadWriteThread, read by FormUpdateTimer tick handler (needs to be atomic)



//For Log File
    unsigned char userSelectedIDFormat;
    unsigned char userSelectedDataFormat;
	unsigned int TransmitUSBMessageLifeCounter;
	unsigned int ReceivedCANMessageLifeCounter;
	unsigned int TransmitCANMessageLifeCounter;
	unsigned int ReceivedUSBMessageLifeCounter;
	unsigned int EatBadMsgLifeCounter;
	unsigned int badCheckSumCounter;

	unsigned long timeStamp;

	unsigned long rtTempTimeStampdiff;
	unsigned long rtTempTimeStamp;
	unsigned long rtTempTimeStampOld;

	unsigned long fixTempTimeStampdiff;
	unsigned long fixTempTimeStamp;
	unsigned long fixTempTimeStampOld;


	unsigned int refreshCounter;
	#define CAN_MESSAGE_BUFFER_SIZE	20000u
	volatile unsigned int NumBytesInMessageBuffer = 0;
	unsigned char CANMessageBuffer[CAN_MESSAGE_BUFFER_SIZE];
	static unsigned char* CANMessageReadPointer = &CANMessageBuffer[0];
	static unsigned char* CANMessageWritePointer = &CANMessageBuffer[0];
	
	//static unsigned long tempTimeStamp = 0;
	//static unsigned long tempTimeStampOld3 = 0;
	//static unsigned long tempTimeStampOld2 = 0;
	//static unsigned long tempTimeStampOld1 = 0;
	//static unsigned long OverAllTimeStamp = 0;

	static unsigned char USBFirmwareMajorVersion = 0;
	static unsigned char USBFirmwareMinorVersion = 0;
	static unsigned char CANFirmwareMajorVersion = 0;
	static unsigned char CANFirmwareMinorVersion = 0;
	static unsigned char GUIMajorVersion = 2;
	static unsigned char GUIMinorVersion = 0;

	static unsigned char TerminationResistanceSetting = 0;


#pragma endregion
//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------


	/// <summary>
	/// Summary for Form1
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>


	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:

	private: System::Windows::Forms::ToolStripLabel^  toolStripLabel10;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator2;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator3;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator4;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator5;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator6;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator11;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator7;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator8;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator9;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator10;
	public: 
		transmitCANMsgDataClass ^t0;
		bitrateDataClass ^b0;
	private: System::Windows::Forms::ToolStripLabel^  toolStripLabel11;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator12;
	private: System::Windows::Forms::Timer^  processSlowUserRequest;
	private: System::Windows::Forms::Timer^  processFastUserRequest;
	private: System::Windows::Forms::ToolStripMenuItem^  groupTransmitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  group1ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  group2ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  group3ToolStripMenuItem;
	private: System::Windows::Forms::OpenFileDialog^  openFileDialog1;





			 logFileDataClass ^l0;
	public: 


		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			b0 = gcnew bitrateDataClass();
			t0 = gcnew transmitCANMsgDataClass();
			l0 = gcnew logFileDataClass();

//Setup forms
			Forms::rollingTraceForm = gcnew rollingTrace();
            Forms::simpleTransmitForm = gcnew simpleTransmit(t0);
			Forms::registerViewForm = gcnew registerView();
			Forms::hardwareSetupForm = gcnew hardwareSetup(b0);
			Forms::fixedTraceForm = gcnew fixedTrace();
			Forms::toolStatusForm = gcnew toolStatus();
			Forms::mytestForm = gcnew testForm();
			Forms::logFileSetup = gcnew logFileSetup(l0);

			Threads::mySemaphore = gcnew Semaphore(0,1);
//			Data::myQ = gcnew Queue();

			Threads::mySemaphore->Release(1);

//          Set the Parent Form of the Child window.
			Forms::rollingTraceForm->MdiParent = this;
			Forms::simpleTransmitForm->MdiParent = this;
			Forms::registerViewForm->MdiParent = this;
			Forms::hardwareSetupForm->MdiParent = this;
			Forms::fixedTraceForm->MdiParent = this;
			Forms::toolStatusForm->MdiParent = this;
			Forms::logFileSetup->MdiParent = this;

//			System::Windows::Forms::Button^ tempButton;
//			System::Windows::Forms::MdiClient^ tempMdiClient;
			unsigned int tempControlCount;
			this->IsMdiContainer = true;
			tempControlCount = this->Controls->Count;
			String^ tempString;

				 this->toolStripLabel1->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel2->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel3->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel4->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel5->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel6->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel7->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel8->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel9->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel10->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel11->BackColor = System::Drawing::SystemColors::Control;


			for(unsigned int c = 0; c < tempControlCount; c++)
			{
				tempString = this->Controls[c]->ToString();
				if (tempString == "System.Windows.Forms.MdiClient") 
				{
					this->Controls[c]->BackColor=System::Drawing::Color::White;
				}
			}

			//Register for WM_DEVICECHANGE notifications.  This code uses these messages to detect plug and play connection/disconnection events for USB devices
			DEV_BROADCAST_DEVICEINTERFACE MyDeviceBroadcastHeader;// = new DEV_BROADCAST_HDR;
			MyDeviceBroadcastHeader.dbcc_devicetype = DBT_DEVTYP_DEVICEINTERFACE;
			MyDeviceBroadcastHeader.dbcc_size = sizeof(DEV_BROADCAST_DEVICEINTERFACE);
			MyDeviceBroadcastHeader.dbcc_reserved = 0;	//Reserved says not to use...
			MyDeviceBroadcastHeader.dbcc_classguid = InterfaceClassGuid;
			RegisterDeviceNotificationUM((HANDLE)this->Handle, &MyDeviceBroadcastHeader, DEVICE_NOTIFY_WINDOW_HANDLE);

			//Now make an initial attempt to find the USB device, if it was already connected to the PC and enumerated prior to launching the application.
			//If it is connected and present, we should open read and write handles to the device so we can communicate with it later.
			//If it was not connected, we will have to wait until the user plugs the device in, and the WM_DEVICECHANGE callback function can process
			//the message and again search for the device.
			if(CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
			{
				DWORD ErrorStatus;
				BOOL WinUSBSuccess;
				unsigned long value = 500;
				
				//We now have the proper device path, and we can finally open read and write handles to the device.
				MyDeviceHandle = CreateFile(DetailedInterfaceDataStructure->DevicePath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0);

				ErrorStatus = GetLastError();

				if(ErrorStatus == ERROR_SUCCESS)
				{
					WinUSBSuccess = WinUsb_Initialize(MyDeviceHandle, &MyWinUSBInterfaceHandle);

					if(WinUSBSuccess == TRUE)
					{
//						if (WinUsb_SetPipePolicy(&MyWinUSBInterfaceHandle,0x81,PIPE_TRANSFER_TIMEOUT,4,&value)) //Ulong is 4 bytes and 500 mseconds
//						{
							AttachedState = TRUE;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
							AttachedButBroken = FALSE;
//						}
//						else
//						{
//							AttachedState = FALSE;		//Let the rest of this application known not to read/write to the device.
//							AttachedButBroken = TRUE;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
//							CloseHandle(MyDeviceHandle);
//						}
					}
					else //One of the WinUSB handles didn't open successfully...
					{
						AttachedState = FALSE;		//Let the rest of this application known not to read/write to the device.
						AttachedButBroken = TRUE;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
						CloseHandle(MyDeviceHandle);
					}
				}
				else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
				{
					AttachedState = FALSE;		//Let the rest of this application known not to read/write to the device.
					AttachedButBroken = TRUE;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
				}
			}
			else	//Device must not be connected (or not programmed with correct firmware)
			{
				AttachedState = FALSE;
				AttachedButBroken = FALSE;
			}

	        TransmitUSBMessageLifeCounter = 0;
            ReceivedCANMessageLifeCounter = 0;
			TransmitCANMessageLifeCounter = 0;
			ReceivedUSBMessageLifeCounter = 0;	
			EatBadMsgLifeCounter = 0;
			badCheckSumCounter = 0;

//should init these...
			b0->setBitrateFlag(false);
			t0->setCANDataFlag(false);

			updateGUIThread->Start();
			this->processSlowUserRequest->Enabled=true;
			this->processFastUserRequest->Enabled=true;

            readWriteUSBThread->RunWorkerAsync();
			
//Recommend performing USB read/write operations in a separate thread.  Otherwise,
//the Read/Write operations are effectively blocking functions and can lock up the
//user interface if the I/O operations take a long time to complete.
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}

	protected: 




	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  openToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator;
	private: System::Windows::Forms::ToolStripMenuItem^  saveToolStripMenuItem;
	private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
	private: System::Windows::Forms::ToolStripMenuItem^  exitToolStripMenuItem;


	private: System::Windows::Forms::ToolStripMenuItem^  toolsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  customizeToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  optionsToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  helpToolStripMenuItem;


	private: System::Windows::Forms::ToolStripMenuItem^  aboutToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  viewToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  transmitToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  registerViewToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  setupToolStripMenuItem;

	private: System::ComponentModel::BackgroundWorker^  readWriteUSBThread;
private: System::Windows::Forms::Timer^  updateGUIThread;
private: System::Windows::Forms::ToolStrip^  toolStrip1;
private: System::Windows::Forms::ToolStripLabel^  toolStripLabel1;

private: System::Windows::Forms::ToolStripLabel^  toolStripLabel2;

private: System::Windows::Forms::ToolStripLabel^  toolStripLabel3;

private: System::Windows::Forms::ToolStripLabel^  toolStripLabel4;

private: System::Windows::Forms::ToolStripLabel^  toolStripLabel5;

private: System::Windows::Forms::ToolStripLabel^  toolStripLabel6;

private: System::Windows::Forms::ToolStripLabel^  toolStripLabel7;

private: System::Windows::Forms::ToolStripMenuItem^  showIdInHexToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  showDataInHexToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  closeAllToolStripMenuItem;



private: System::Windows::Forms::ToolStripMenuItem^  hardwareSetupToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  logFileSetupToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  triggerSetupToolStripMenuItem;
private: System::Windows::Forms::ToolStripLabel^  toolStripLabel8;

private: System::Windows::Forms::ToolStripLabel^  toolStripLabel9;







private: System::Windows::Forms::ToolStripMenuItem^  toolStatusToolStripMenuItem;



private: System::ComponentModel::IContainer^  components;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->saveToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->exitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->viewToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->showIdInHexToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->showDataInHexToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->closeAllToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->customizeToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->optionsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->transmitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->registerViewToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->groupTransmitToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->group1ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->group2ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->group3ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->setupToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->logFileSetupToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->triggerSetupToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->hardwareSetupToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStatusToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->helpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->aboutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->readWriteUSBThread = (gcnew System::ComponentModel::BackgroundWorker());
			this->updateGUIThread = (gcnew System::Windows::Forms::Timer(this->components));
			this->toolStrip1 = (gcnew System::Windows::Forms::ToolStrip());
			this->toolStripLabel1 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator2 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel2 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator3 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel3 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator4 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel4 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator5 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel5 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator6 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel6 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator11 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel10 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator7 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel7 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator8 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel11 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator9 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel8 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator12 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->toolStripLabel9 = (gcnew System::Windows::Forms::ToolStripLabel());
			this->toolStripSeparator10 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->processSlowUserRequest = (gcnew System::Windows::Forms::Timer(this->components));
			this->processFastUserRequest = (gcnew System::Windows::Forms::Timer(this->components));
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->menuStrip1->SuspendLayout();
			this->toolStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {this->fileToolStripMenuItem, 
				this->viewToolStripMenuItem, this->toolsToolStripMenuItem, this->setupToolStripMenuItem, this->helpToolStripMenuItem});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(1113, 26);
			this->menuStrip1->TabIndex = 6;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {this->openToolStripMenuItem, 
				this->toolStripSeparator, this->saveToolStripMenuItem, this->toolStripSeparator1, this->exitToolStripMenuItem});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(40, 22);
			this->fileToolStripMenuItem->Text = L"&File";
			// 
			// openToolStripMenuItem
			// 
			this->openToolStripMenuItem->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"openToolStripMenuItem.Image")));
			this->openToolStripMenuItem->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->openToolStripMenuItem->Name = L"openToolStripMenuItem";
			this->openToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::O));
			this->openToolStripMenuItem->Size = System::Drawing::Size(266, 22);
			this->openToolStripMenuItem->Text = L"&Open Configuration";
			this->openToolStripMenuItem->Visible = false;
			this->openToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::openToolStripMenuItem_Click);
			// 
			// toolStripSeparator
			// 
			this->toolStripSeparator->Name = L"toolStripSeparator";
			this->toolStripSeparator->Size = System::Drawing::Size(263, 6);
			this->toolStripSeparator->Visible = false;
			// 
			// saveToolStripMenuItem
			// 
			this->saveToolStripMenuItem->Image = (cli::safe_cast<System::Drawing::Image^  >(resources->GetObject(L"saveToolStripMenuItem.Image")));
			this->saveToolStripMenuItem->ImageTransparentColor = System::Drawing::Color::Magenta;
			this->saveToolStripMenuItem->Name = L"saveToolStripMenuItem";
			this->saveToolStripMenuItem->ShortcutKeys = static_cast<System::Windows::Forms::Keys>((System::Windows::Forms::Keys::Control | System::Windows::Forms::Keys::S));
			this->saveToolStripMenuItem->Size = System::Drawing::Size(266, 22);
			this->saveToolStripMenuItem->Text = L"&Save Configuration";
			this->saveToolStripMenuItem->Visible = false;
			this->saveToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveToolStripMenuItem_Click);
			// 
			// toolStripSeparator1
			// 
			this->toolStripSeparator1->Name = L"toolStripSeparator1";
			this->toolStripSeparator1->Size = System::Drawing::Size(263, 6);
			this->toolStripSeparator1->Visible = false;
			// 
			// exitToolStripMenuItem
			// 
			this->exitToolStripMenuItem->Name = L"exitToolStripMenuItem";
			this->exitToolStripMenuItem->Size = System::Drawing::Size(266, 22);
			this->exitToolStripMenuItem->Text = L"E&xit";
			this->exitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exitToolStripMenuItem_Click);
			// 
			// viewToolStripMenuItem
			// 
			this->viewToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->showIdInHexToolStripMenuItem, 
				this->showDataInHexToolStripMenuItem, this->closeAllToolStripMenuItem});
			this->viewToolStripMenuItem->Name = L"viewToolStripMenuItem";
			this->viewToolStripMenuItem->Size = System::Drawing::Size(49, 22);
			this->viewToolStripMenuItem->Text = L"View";
			// 
			// showIdInHexToolStripMenuItem
			// 
			this->showIdInHexToolStripMenuItem->Name = L"showIdInHexToolStripMenuItem";
			this->showIdInHexToolStripMenuItem->Size = System::Drawing::Size(242, 22);
			this->showIdInHexToolStripMenuItem->Text = L"Show Id in DECIMAL";
			this->showIdInHexToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::showIdInHexToolStripMenuItem_Click);
			// 
			// showDataInHexToolStripMenuItem
			// 
			this->showDataInHexToolStripMenuItem->Name = L"showDataInHexToolStripMenuItem";
			this->showDataInHexToolStripMenuItem->Size = System::Drawing::Size(242, 22);
			this->showDataInHexToolStripMenuItem->Text = L"Show Data in DECIMAL";
			this->showDataInHexToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::showDataInHexToolStripMenuItem_Click);
			// 
			// closeAllToolStripMenuItem
			// 
			this->closeAllToolStripMenuItem->Name = L"closeAllToolStripMenuItem";
			this->closeAllToolStripMenuItem->Size = System::Drawing::Size(242, 22);
			this->closeAllToolStripMenuItem->Text = L"Close All Tool Windows";
			this->closeAllToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::closeAllToolStripMenuItem_Click);
			// 
			// toolsToolStripMenuItem
			// 
			this->toolsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {this->customizeToolStripMenuItem, 
				this->optionsToolStripMenuItem, this->transmitToolStripMenuItem, this->registerViewToolStripMenuItem, this->groupTransmitToolStripMenuItem});
			this->toolsToolStripMenuItem->Name = L"toolsToolStripMenuItem";
			this->toolsToolStripMenuItem->Size = System::Drawing::Size(55, 22);
			this->toolsToolStripMenuItem->Text = L"&Tools";
			// 
			// customizeToolStripMenuItem
			// 
			this->customizeToolStripMenuItem->Name = L"customizeToolStripMenuItem";
			this->customizeToolStripMenuItem->Size = System::Drawing::Size(193, 22);
			this->customizeToolStripMenuItem->Text = L"&Rolling Trace";
			this->customizeToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::customizeToolStripMenuItem_Click);
			// 
			// optionsToolStripMenuItem
			// 
			this->optionsToolStripMenuItem->Name = L"optionsToolStripMenuItem";
			this->optionsToolStripMenuItem->Size = System::Drawing::Size(193, 22);
			this->optionsToolStripMenuItem->Text = L"&Fixed Trace";
			this->optionsToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::optionsToolStripMenuItem_Click);
			// 
			// transmitToolStripMenuItem
			// 
			this->transmitToolStripMenuItem->Name = L"transmitToolStripMenuItem";
			this->transmitToolStripMenuItem->Size = System::Drawing::Size(193, 22);
			this->transmitToolStripMenuItem->Text = L"&Transmit";
			this->transmitToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::transmitToolStripMenuItem_Click);
			// 
			// registerViewToolStripMenuItem
			// 
			this->registerViewToolStripMenuItem->Name = L"registerViewToolStripMenuItem";
			this->registerViewToolStripMenuItem->Size = System::Drawing::Size(193, 22);
			this->registerViewToolStripMenuItem->Text = L"Register View";
			this->registerViewToolStripMenuItem->Visible = false;
			this->registerViewToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::registerViewToolStripMenuItem_Click);
			// 
			// groupTransmitToolStripMenuItem
			// 
			this->groupTransmitToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->group1ToolStripMenuItem, 
				this->group2ToolStripMenuItem, this->group3ToolStripMenuItem});
			this->groupTransmitToolStripMenuItem->Name = L"groupTransmitToolStripMenuItem";
			this->groupTransmitToolStripMenuItem->Size = System::Drawing::Size(193, 22);
			this->groupTransmitToolStripMenuItem->Text = L"Group Transmit";
			this->groupTransmitToolStripMenuItem->Visible = false;
			// 
			// group1ToolStripMenuItem
			// 
			this->group1ToolStripMenuItem->Name = L"group1ToolStripMenuItem";
			this->group1ToolStripMenuItem->Size = System::Drawing::Size(143, 22);
			this->group1ToolStripMenuItem->Text = L"Group 1";
			this->group1ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::group1ToolStripMenuItem_Click);
			// 
			// group2ToolStripMenuItem
			// 
			this->group2ToolStripMenuItem->Name = L"group2ToolStripMenuItem";
			this->group2ToolStripMenuItem->Size = System::Drawing::Size(143, 22);
			this->group2ToolStripMenuItem->Text = L"Group 2";
			// 
			// group3ToolStripMenuItem
			// 
			this->group3ToolStripMenuItem->Name = L"group3ToolStripMenuItem";
			this->group3ToolStripMenuItem->Size = System::Drawing::Size(143, 22);
			this->group3ToolStripMenuItem->Text = L"Group 3";
			// 
			// setupToolStripMenuItem
			// 
			this->setupToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->logFileSetupToolStripMenuItem, 
				this->triggerSetupToolStripMenuItem, this->hardwareSetupToolStripMenuItem, this->toolStatusToolStripMenuItem});
			this->setupToolStripMenuItem->Name = L"setupToolStripMenuItem";
			this->setupToolStripMenuItem->Size = System::Drawing::Size(57, 22);
			this->setupToolStripMenuItem->Text = L"&Setup";
			// 
			// logFileSetupToolStripMenuItem
			// 
			this->logFileSetupToolStripMenuItem->Name = L"logFileSetupToolStripMenuItem";
			this->logFileSetupToolStripMenuItem->Size = System::Drawing::Size(195, 22);
			this->logFileSetupToolStripMenuItem->Text = L"Log File Setup";
			this->logFileSetupToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::logFileSetupToolStripMenuItem_Click);
			// 
			// triggerSetupToolStripMenuItem
			// 
			this->triggerSetupToolStripMenuItem->Name = L"triggerSetupToolStripMenuItem";
			this->triggerSetupToolStripMenuItem->Size = System::Drawing::Size(195, 22);
			this->triggerSetupToolStripMenuItem->Text = L"Trigger Setup";
			this->triggerSetupToolStripMenuItem->Visible = false;
			// 
			// hardwareSetupToolStripMenuItem
			// 
			this->hardwareSetupToolStripMenuItem->Name = L"hardwareSetupToolStripMenuItem";
			this->hardwareSetupToolStripMenuItem->Size = System::Drawing::Size(195, 22);
			this->hardwareSetupToolStripMenuItem->Text = L"Hardware Setup";
			this->hardwareSetupToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::hardwareSetupToolStripMenuItem_Click);
			// 
			// toolStatusToolStripMenuItem
			// 
			this->toolStatusToolStripMenuItem->Name = L"toolStatusToolStripMenuItem";
			this->toolStatusToolStripMenuItem->Size = System::Drawing::Size(195, 22);
			this->toolStatusToolStripMenuItem->Text = L"Tool Status";
			this->toolStatusToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::toolStatusToolStripMenuItem_Click);
			// 
			// helpToolStripMenuItem
			// 
			this->helpToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->aboutToolStripMenuItem});
			this->helpToolStripMenuItem->Name = L"helpToolStripMenuItem";
			this->helpToolStripMenuItem->Size = System::Drawing::Size(48, 22);
			this->helpToolStripMenuItem->Text = L"&Help";
			// 
			// aboutToolStripMenuItem
			// 
			this->aboutToolStripMenuItem->Name = L"aboutToolStripMenuItem";
			this->aboutToolStripMenuItem->Size = System::Drawing::Size(144, 22);
			this->aboutToolStripMenuItem->Text = L"&About...";
			this->aboutToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::aboutToolStripMenuItem_Click);
			// 
			// readWriteUSBThread
			// 
			this->readWriteUSBThread->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::readWriteUSBThread_DoWork);
			// 
			// updateGUIThread
			// 
			this->updateGUIThread->Interval = 500;
			this->updateGUIThread->Tick += gcnew System::EventHandler(this, &Form1::updateGUIThread_Tick);
			// 
			// toolStrip1
			// 
			this->toolStrip1->Dock = System::Windows::Forms::DockStyle::Bottom;
			this->toolStrip1->GripStyle = System::Windows::Forms::ToolStripGripStyle::Hidden;
			this->toolStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(22) {this->toolStripLabel1, 
				this->toolStripSeparator2, this->toolStripLabel2, this->toolStripSeparator3, this->toolStripLabel3, this->toolStripSeparator4, 
				this->toolStripLabel4, this->toolStripSeparator5, this->toolStripLabel5, this->toolStripSeparator6, this->toolStripLabel6, this->toolStripSeparator11, 
				this->toolStripLabel10, this->toolStripSeparator7, this->toolStripLabel7, this->toolStripSeparator8, this->toolStripLabel11, 
				this->toolStripSeparator9, this->toolStripLabel8, this->toolStripSeparator12, this->toolStripLabel9, this->toolStripSeparator10});
			this->toolStrip1->Location = System::Drawing::Point(0, 453);
			this->toolStrip1->Name = L"toolStrip1";
			this->toolStrip1->RenderMode = System::Windows::Forms::ToolStripRenderMode::System;
			this->toolStrip1->Size = System::Drawing::Size(1113, 25);
			this->toolStrip1->TabIndex = 10;
			this->toolStrip1->Text = L"toolStrip1";
			// 
			// toolStripLabel1
			// 
			this->toolStripLabel1->Name = L"toolStripLabel1";
			this->toolStripLabel1->Size = System::Drawing::Size(127, 22);
			this->toolStripLabel1->Text = L"Tool Disconnected";
			// 
			// toolStripSeparator2
			// 
			this->toolStripSeparator2->Name = L"toolStripSeparator2";
			this->toolStripSeparator2->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel2
			// 
			this->toolStripLabel2->AutoSize = false;
			this->toolStripLabel2->Name = L"toolStripLabel2";
			this->toolStripLabel2->Size = System::Drawing::Size(113, 22);
			this->toolStripLabel2->Text = L"CAN BUS Speed";
			// 
			// toolStripSeparator3
			// 
			this->toolStripSeparator3->Name = L"toolStripSeparator3";
			this->toolStripSeparator3->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel3
			// 
			this->toolStripLabel3->Name = L"toolStripLabel3";
			this->toolStripLabel3->Size = System::Drawing::Size(77, 22);
			this->toolStripLabel3->Text = L"CAN Mode";
			// 
			// toolStripSeparator4
			// 
			this->toolStripSeparator4->Name = L"toolStripSeparator4";
			this->toolStripSeparator4->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel4
			// 
			this->toolStripLabel4->Name = L"toolStripLabel4";
			this->toolStripLabel4->Size = System::Drawing::Size(85, 22);
			this->toolStripLabel4->Text = L"Error Status";
			// 
			// toolStripSeparator5
			// 
			this->toolStripSeparator5->Name = L"toolStripSeparator5";
			this->toolStripSeparator5->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel5
			// 
			this->toolStripLabel5->Name = L"toolStripLabel5";
			this->toolStripLabel5->Size = System::Drawing::Size(75, 22);
			this->toolStripLabel5->Text = L"TX ERR: \?";
			// 
			// toolStripSeparator6
			// 
			this->toolStripSeparator6->Name = L"toolStripSeparator6";
			this->toolStripSeparator6->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel6
			// 
			this->toolStripLabel6->Name = L"toolStripLabel6";
			this->toolStripLabel6->Size = System::Drawing::Size(74, 22);
			this->toolStripLabel6->Text = L"RX ERR: \?";
			// 
			// toolStripSeparator11
			// 
			this->toolStripSeparator11->Name = L"toolStripSeparator11";
			this->toolStripSeparator11->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel10
			// 
			this->toolStripLabel10->Name = L"toolStripLabel10";
			this->toolStripLabel10->Size = System::Drawing::Size(102, 22);
			this->toolStripLabel10->Text = L"Termination: \?";
			// 
			// toolStripSeparator7
			// 
			this->toolStripSeparator7->Name = L"toolStripSeparator7";
			this->toolStripSeparator7->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel7
			// 
			this->toolStripLabel7->Name = L"toolStripLabel7";
			this->toolStripLabel7->Size = System::Drawing::Size(90, 22);
			this->toolStripLabel7->Text = L"Trace Active";
			// 
			// toolStripSeparator8
			// 
			this->toolStripSeparator8->Name = L"toolStripSeparator8";
			this->toolStripSeparator8->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel11
			// 
			this->toolStripLabel11->Name = L"toolStripLabel11";
			this->toolStripLabel11->Size = System::Drawing::Size(114, 22);
			this->toolStripLabel11->Text = L"Logging Inactive";
			// 
			// toolStripSeparator9
			// 
			this->toolStripSeparator9->Name = L"toolStripSeparator9";
			this->toolStripSeparator9->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel8
			// 
			this->toolStripLabel8->Name = L"toolStripLabel8";
			this->toolStripLabel8->Size = System::Drawing::Size(71, 22);
			this->toolStripLabel8->Text = L"ID in HEX";
			// 
			// toolStripSeparator12
			// 
			this->toolStripSeparator12->Name = L"toolStripSeparator12";
			this->toolStripSeparator12->Size = System::Drawing::Size(6, 25);
			// 
			// toolStripLabel9
			// 
			this->toolStripLabel9->Name = L"toolStripLabel9";
			this->toolStripLabel9->Size = System::Drawing::Size(93, 22);
			this->toolStripLabel9->Text = L"DATA in HEX";
			// 
			// toolStripSeparator10
			// 
			this->toolStripSeparator10->Name = L"toolStripSeparator10";
			this->toolStripSeparator10->Size = System::Drawing::Size(6, 25);
			// 
			// processSlowUserRequest
			// 
			this->processSlowUserRequest->Interval = 300;
			this->processSlowUserRequest->Tick += gcnew System::EventHandler(this, &Form1::processSlowUserRequest_Tick);
			// 
			// processFastUserRequest
			// 
			this->processFastUserRequest->Interval = 1;
			this->processFastUserRequest->Tick += gcnew System::EventHandler(this, &Form1::processFastUserRequest_Tick);
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->FileName = L"openFileDialog1";
			this->openFileDialog1->FileOk += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::openFileDialog1_FileOk);
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::White;
			this->ClientSize = System::Drawing::Size(1113, 478);
			this->Controls->Add(this->toolStrip1);
			this->Controls->Add(this->menuStrip1);
			this->DoubleBuffered = true;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->IsMdiContainer = true;
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"Form1";
			this->Text = L"CAN BUS Analyzer";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &Form1::Form1_FormClosing);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->toolStrip1->ResumeLayout(false);
			this->toolStrip1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void customizeToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
      // Display the receive window
		 if (Forms::rollingTraceForm->Visible == false)
		 {
			 Forms::rollingTraceForm->Show();
		 }
		 else
		 {
//notify user window is already open...
		 }
		 }

private: System::Void transmitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
      // Display transit window
			 if (Forms::simpleTransmitForm->Visible == false)
			 {
			 Forms::simpleTransmitForm->Show();
			 }
			 else
			 {
				 //notify user window is already open...
			 }
		 }

private: System::Void registerViewToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
//Show Register window
      // Display the new form.
			 if (Forms::registerViewForm->Visible == false)
			 {
			 Forms::registerViewForm->Show();
			 }
			 else
			 {
				 //notify user window is already open...
			 }
		 }

private: System::Void hardwareSetupToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (Forms::hardwareSetupForm->Visible == false)
			 {
			 Forms::hardwareSetupForm->Show();
			 }
			 else
			 {
				 //notify user window is already open...
			 }
		 }

private: System::Void optionsToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (Forms::fixedTraceForm->Visible == false)
			 {
			 Forms::fixedTraceForm->Show();
			 }
			 else
			 {
				 //notify user window is already open...
			 }
		 }


private: System::Void toolStatusToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (Forms::toolStatusForm->Visible == false)
			 {
				 Forms::toolStatusForm->Show();
			 }
			 else
			 {
				 //notify user window is already open...
			 }
		 }

private: System::Void showIdInHexToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (userSelectedIDFormat == dNUMBER_FORMAT_HEX)
			 {
				 userSelectedIDFormat = dNUMBER_FORMAT_DECIMAL;
				 this->showIdInHexToolStripMenuItem->Text="Show Id in HEX"; //Shows what the user can switch too..
				 this->toolStripLabel8->Text="ID in DEC"; //Shows what the user currently has selected..
			 }
			 else
			 {
				 userSelectedIDFormat = dNUMBER_FORMAT_HEX;
				 this->showIdInHexToolStripMenuItem->Text="Show Id in DECIMAL"; //Shows what the user can switch too..
				 this->toolStripLabel8->Text="ID in HEX"; //Shows what the user currently has selected..
			 }
		 }
private: System::Void showDataInHexToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (userSelectedDataFormat == dNUMBER_FORMAT_HEX)
			 {
				 userSelectedDataFormat = dNUMBER_FORMAT_DECIMAL;
				 this->showDataInHexToolStripMenuItem->Text="Show Data in HEX"; //Shows what the user can switch too..
				 this->toolStripLabel9->Text="DATA in DEC"; //Shows what the user currently has selected..
			 }
			 else
			 {
				 userSelectedDataFormat = dNUMBER_FORMAT_HEX;
				 this->showDataInHexToolStripMenuItem->Text="Show Data in DECIMAL"; //Shows what the user can switch too..
				 this->toolStripLabel9->Text="DATA in HEX"; //Shows what the user currently has selected..
			 }
		 }
private: System::Void closeAllToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 Forms::rollingTraceForm->Hide();
			 Forms::simpleTransmitForm->Hide();
			 Forms::registerViewForm->Hide();
			 Forms::hardwareSetupForm->Hide();
			 Forms::fixedTraceForm->Hide();
			 Forms::toolStatusForm->Hide();
			 Forms::logFileSetup->Hide();
		 }

private: System::Void aboutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if (CANFirmwareMajorVersion == 0)
			 {
				 if(CANFirmwareMinorVersion == 0)
				 {
//"+System::Environment::NewLine+"
					 System::Windows::Forms::MessageBox::Show("ERROR 2.00.0\nTrouble reading the CAN firmware version", "Error");
				 }
			 }
			 if (CANFirmwareMajorVersion == 0xFF)
			 {
				 if(CANFirmwareMinorVersion == 0xFF)
				 {
					 System::Windows::Forms::MessageBox::Show("ERROR 2.00.1\nTrouble reading the CAN firmware version", "Error");
				 }
			 }

			 if (USBFirmwareMajorVersion == 0)
			 {
				 if(USBFirmwareMinorVersion == 0)
				 {
					 System::Windows::Forms::MessageBox::Show("ERROR 1.00.0\nTrouble reading the USB firmware version", "Error");
				 }
			 }
			 if (USBFirmwareMajorVersion == 0xFF)
			 {
				 if(USBFirmwareMinorVersion == 0xFF)
				 {
					 System::Windows::Forms::MessageBox::Show("ERROR 1.00.1\nTrouble reading the USB firmware version", "Error");
				 }
			 }

			 System::Windows::Forms::MessageBox::Show("Microchip Technology Inc.\nCAN BUS Analyzer\n\nPC Software Information:\nReleased November 2nd 2011\nGUI Version: "+GUIMajorVersion.ToString()+"."+GUIMinorVersion.ToString()+"\n\nFirmware Information:\nUSB Version: "+USBFirmwareMajorVersion.ToString()+"."+USBFirmwareMinorVersion.ToString()+"\nCAN Version: "+CANFirmwareMajorVersion.ToString()+"."+CANFirmwareMinorVersion.ToString(), "Version Information");
		 }

private: System::Void logFileSetupToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 if (Forms::logFileSetup->Visible==false)
			 {
				 Forms::logFileSetup->Show();
			 }
			 else
			 {
				 //notify user window is already open...
			 }
		 }


private: System::Void exitToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
			 Forms::rollingTraceForm->Close();
			 Forms::simpleTransmitForm->Close();
			 Forms::registerViewForm->Close();
			 Forms::hardwareSetupForm->Close();
			 Forms::fixedTraceForm->Close();
			 Forms::toolStatusForm->Close();
			 Application::Exit();
		 }
private: System::Void Form1_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
			 this->updateGUIThread->Stop();
			 this->processSlowUserRequest->Stop();
			 this->processFastUserRequest->Stop();

			 Forms::rollingTraceForm->Close();
			 Forms::simpleTransmitForm->Close();
			 Forms::registerViewForm->Close();
			 Forms::hardwareSetupForm->Close();
			 Forms::fixedTraceForm->Close();
			 Forms::toolStatusForm->Close();
			 Application::Exit();
		 }

//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

//FUNCTION:	CheckIfPresentAndGetUSBDevicePath()
//PURPOSE:	Check if a USB device is currently plugged in with a matching VID and PID
//INPUT:	Uses globally declared "DetailedInterfaceDataStructure" structure, globally declared GUID, and the MY_DEVICE_ID constant.
//OUTPUT:	Returns BOOL.  TRUE when device with matching VID/PID found.  FALSE if device with VID/PID could not be found.
//			When returns TRUE, the globally accessable "DetailedInterfaceDataStructure" will contain the device path
//			to the USB device with the matching VID/PID.

BOOL	CheckIfPresentAndGetUSBDevicePath(void)
{
		/* 
		Before we can "connect" our application to our USB embedded device, we must first find the device.
		A USB bus can have many devices simultaneously connected, so somehow we have to find our device only.
		This is done with the Vendor ID (VID) and Product ID (PID).  Each USB product line should have
		a unique combination of VID and PID.  

		Microsoft has created a number of functions which are useful for finding plug and play devices.  Documentation
		for each function used can be found in the MSDN library.  We will be using the following functions:

		SetupDiGetClassDevs()					//provided by setupapi.dll, which comes with Windows
		SetupDiEnumDeviceInterfaces()			//provided by setupapi.dll, which comes with Windows
		GetLastError()							//provided by kernel32.dll, which comes with Windows
		SetupDiDestroyDeviceInfoList()			//provided by setupapi.dll, which comes with Windows
		SetupDiGetDeviceInterfaceDetail()		//provided by setupapi.dll, which comes with Windows
		SetupDiGetDeviceRegistryProperty()		//provided by setupapi.dll, which comes with Windows
		malloc()								//part of C runtime library, msvcrt.dll?
		CreateFile()							//provided by kernel32.dll, which comes with Windows

		We will also be using the following unusual data types and structures.  Documentation can also be found in
		the MSDN library:

		PSP_DEVICE_INTERFACE_DATA
		PSP_DEVICE_INTERFACE_DETAIL_DATA
		SP_DEVINFO_DATA
		HDEVINFO
		HANDLE
		GUID

		The ultimate objective of the following code is to get the device path, which will be used elsewhere for getting
		read and write handles to the USB device.  Once the read/write handles are opened, only then can this
		PC application begin reading/writing to the USB device using the WriteFile() and ReadFile() functions.

		Getting the device path is a multi-step round about process, which requires calling several of the
		SetupDixxx() functions provided by setupapi.dll.
		*/

		HDEVINFO DeviceInfoTable = INVALID_HANDLE_VALUE;
		PSP_DEVICE_INTERFACE_DATA InterfaceDataStructure = new SP_DEVICE_INTERFACE_DATA;
//		PSP_DEVICE_INTERFACE_DETAIL_DATA DetailedInterfaceDataStructure = new SP_DEVICE_INTERFACE_DETAIL_DATA;	//Globally declared instead
		SP_DEVINFO_DATA DevInfoData;

		DWORD InterfaceIndex = 0;
		DWORD StatusLastError = 0;
		DWORD dwRegType;
		DWORD dwRegSize;
		DWORD StructureSize = 0;
		PBYTE PropertyValueBuffer;
		bool MatchFound = false;
		DWORD ErrorStatus;
		BOOL BoolStatus = FALSE;
		DWORD LoopCounter = 0;

		String^ DeviceIDToFind = MY_DEVICE_ID;

		//First populate a list of plugged in devices (by specifying "DIGCF_PRESENT"), which are of the specified class GUID. 
		DeviceInfoTable = SetupDiGetClassDevsUM(&InterfaceClassGuid, NULL, NULL, DIGCF_PRESENT | DIGCF_DEVICEINTERFACE);

		//Now look through the list we just populated.  We are trying to see if any of them match our device. 
		while(true)
		{
			InterfaceDataStructure->cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
			if(SetupDiEnumDeviceInterfacesUM(DeviceInfoTable, NULL, &InterfaceClassGuid, InterfaceIndex, InterfaceDataStructure))
			{
				ErrorStatus = GetLastError();
				if(ErrorStatus == ERROR_NO_MORE_ITEMS)	//Did we reach the end of the list of matching devices in the DeviceInfoTable?
				{	//Cound not find the device.  Must not have been attached.
					SetupDiDestroyDeviceInfoListUM(DeviceInfoTable);	//Clean up the old structure we no longer need.
					return FALSE;		
				}
			}
			else	//Else some other kind of unknown error ocurred...
			{
				ErrorStatus = GetLastError();
				SetupDiDestroyDeviceInfoListUM(DeviceInfoTable);	//Clean up the old structure we no longer need.
				return FALSE;	
			}

			//Now retrieve the hardware ID from the registry.  The hardware ID contains the VID and PID, which we will then 
			//check to see if it is the correct device or not.

			//Initialize an appropriate SP_DEVINFO_DATA structure.  We need this structure for SetupDiGetDeviceRegistryProperty().
			DevInfoData.cbSize = sizeof(SP_DEVINFO_DATA);
			SetupDiEnumDeviceInfoUM(DeviceInfoTable, InterfaceIndex, &DevInfoData);

			//First query for the size of the hardware ID, so we can know how big a buffer to allocate for the data.
			SetupDiGetDeviceRegistryPropertyUM(DeviceInfoTable, &DevInfoData, SPDRP_HARDWAREID, &dwRegType, NULL, 0, &dwRegSize);

			//Allocate a buffer for the hardware ID.
			PropertyValueBuffer = (BYTE *) malloc (dwRegSize);
			if(PropertyValueBuffer == NULL)	//if null, error, couldn't allocate enough memory
			{	//Can't really recover from this situation, just exit instead.
				SetupDiDestroyDeviceInfoListUM(DeviceInfoTable);	//Clean up the old structure we no longer need.
				return FALSE;		
			}

			//Retrieve the hardware IDs for the current device we are looking at.  PropertyValueBuffer gets filled with a 
			//REG_MULTI_SZ (array of null terminated strings).  To find a device, we only care about the very first string in the
			//buffer, which will be the "device ID".  The device ID is a string which contains the VID and PID, in the example 
			//format "Vid_04d8&Pid_003f".
			SetupDiGetDeviceRegistryPropertyUM(DeviceInfoTable, &DevInfoData, SPDRP_HARDWAREID, &dwRegType, PropertyValueBuffer, dwRegSize, NULL);

			//Now check if the first string in the hardware ID matches the device ID of my USB device.
			#ifdef UNICODE
			String^ DeviceIDFromRegistry = gcnew String((wchar_t *)PropertyValueBuffer);
			#else
			String^ DeviceIDFromRegistry = gcnew String((char *)PropertyValueBuffer);
			#endif

			free(PropertyValueBuffer);		//No longer need the PropertyValueBuffer, free the memory to prevent potential memory leaks

			//Convert both strings to lower case.  This makes the code more robust/portable accross OS Versions
			DeviceIDFromRegistry = DeviceIDFromRegistry->ToLowerInvariant();	
			DeviceIDToFind = DeviceIDToFind->ToLowerInvariant();				
			//Now check if the hardware ID we are looking at contains the correct VID/PID
			MatchFound = DeviceIDFromRegistry->Contains(DeviceIDToFind);		
			if(MatchFound == true)
			{
				//Device must have been found.  Open WinUSB interface handle now.  In order to do this, we will need the actual device path first.
				//We can get the path by calling SetupDiGetDeviceInterfaceDetail(), however, we have to call this function twice:  The first
				//time to get the size of the required structure/buffer to hold the detailed interface data, then a second time to actually 
				//get the structure (after we have allocated enough memory for the structure.)
				DetailedInterfaceDataStructure->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
				//First call populates "StructureSize" with the correct value
				SetupDiGetDeviceInterfaceDetailUM(DeviceInfoTable, InterfaceDataStructure, NULL, NULL, &StructureSize, NULL);	
				DetailedInterfaceDataStructure = (PSP_DEVICE_INTERFACE_DETAIL_DATA)(malloc(StructureSize));		//Allocate enough memory
				if(DetailedInterfaceDataStructure == NULL)	//if null, error, couldn't allocate enough memory
				{	//Can't really recover from this situation, just exit instead.
					SetupDiDestroyDeviceInfoListUM(DeviceInfoTable);	//Clean up the old structure we no longer need.
					return FALSE;		
				}
				DetailedInterfaceDataStructure->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
				 //Now call SetupDiGetDeviceInterfaceDetail() a second time to receive the goods.  
				SetupDiGetDeviceInterfaceDetailUM(DeviceInfoTable, InterfaceDataStructure, DetailedInterfaceDataStructure, StructureSize, NULL, NULL); 

				//We now have the proper device path, and we can finally open a device handle to the device.
				//WinUSB requires the device handle to be opened with the FILE_FLAG_OVERLAPPED attribute.
				SetupDiDestroyDeviceInfoListUM(DeviceInfoTable);	//Clean up the old structure we no longer need.
				return TRUE;
			}

			InterfaceIndex++;	
			//Keep looping until we either find a device with matching VID and PID, or until we run out of devices to check.
			//However, just in case some unexpected error occurs, keep track of the number of loops executed.
			//If the number of loops exceeds a very large number, exit anyway, to prevent inadvertent infinite looping.
			LoopCounter++;
			if(LoopCounter == 10000000)	//Surely there aren't more than 10 million devices attached to any forseeable PC...
			{
				return FALSE;
			}
		}//end of while(true)
}
//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------

///////////////////////////////////
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

//This is a callback function that gets called when a Windows message is received by the form.
//We will receive various different types of messages, but the ones we really want to use are the WM_DEVICECHANGE messages.
protected: virtual void WndProc( Message% m ) override{
		 if(m.Msg == WM_DEVICECHANGE)
		 {
			 if(((int)m.WParam == DBT_DEVICEARRIVAL) || ((int)m.WParam == DBT_DEVICEREMOVEPENDING) || ((int)m.WParam == DBT_DEVICEREMOVECOMPLETE) || ((int)m.WParam == DBT_CONFIGCHANGED) )
			 {
				//WM_DEVICECHANGE messages by themselves are quite generic, and can be caused by a number of different
				//sources, not just your USB hardware device.  Therefore, must check to find out if any changes relavant
				//to your device (with known VID/PID) took place before doing any kind of opening or closing of handles/endpoints.
				//(the message could have been totally unrelated to your application/USB device)

				if(CheckIfPresentAndGetUSBDevicePath())	//Check and make sure at least one device with matching VID/PID is attached
				{
					//If executes to here, this means the device is currently attached and was found.
					//This code needs to decide however what to do, based on whether or not the device was previously known to be
					//attached or not.
					if((AttachedState == FALSE) || (AttachedButBroken == TRUE))	//Check the previous attachment state
					{
						DWORD ErrorStatus;
						BOOL WinUSBSuccess;

						//We obtained the proper device path (from CheckIfPresentAndGetUSBDevicePath() function call), and it
						//is now possible to open read and write handles to the device.
						MyDeviceHandle = CreateFile(DetailedInterfaceDataStructure->DevicePath, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, 0);
						ErrorStatus = GetLastError();

						if(ErrorStatus == ERROR_SUCCESS)
						{
							WinUSBSuccess = WinUsb_Initialize(MyDeviceHandle, &MyWinUSBInterfaceHandle);

							if(WinUSBSuccess == TRUE)
							{
								AttachedState = TRUE;		//Let the rest of the PC application know the USB device is connected, and it is safe to read/write to it
								AttachedButBroken = FALSE;
							}
							else //One of the WinUSB handles didn't open successfully...
							{
								AttachedState = FALSE;		//Let the rest of this application known not to read/write to the device.
								AttachedButBroken = TRUE;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
								CloseHandle(MyDeviceHandle);
							}
						}
						else //for some reason the device was physically plugged in, but one or both of the read/write handles didn't open successfully...
						{
							AttachedState = FALSE;		//Let the rest of this application known not to read/write to the device.
							AttachedButBroken = TRUE;	//Flag so that next time a WM_DEVICECHANGE message occurs, can retry to re-open read/write pipes
						}
					}
					//else we did find the device, but AttachedState was already TRUE.  In this case, don't do anything to the read/write handles,
					//since the WM_DEVICECHANGE message presumably wasn't caused by our USB device.  
				}
				else	//Device must not be connected (or not programmed with correct firmware)
				{
					if(AttachedState == TRUE)		//If it is currently set to TRUE, that means the device was just now disconnected
					{
						AttachedState = FALSE;
//						WinUsb_Free(MyDeviceHandle);
						CloseHandle(MyDeviceHandle);

					}
					AttachedState = FALSE;
					AttachedButBroken = FALSE;
				}				 
			 }
		 } //end of: if(m.Msg == WM_DEVICECHANGE)

		 Form::WndProc( m );
	} //end of: WndProc() function
//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------

///////////////////////////////////

long get_prop( Object^ v )
{
    return (long)Convert::ToInt64( v );
}


private: System::Void updateGUIThread_Tick(System::Object^  sender, System::EventArgs^  e) {
			 static unsigned int timeCounter;
			 unsigned int LocalMessageBuf[dSPI_CAN_PACKET_SIZE];
//			 unsigned char numberOfBytes;
//			 unsigned int tempIntCount;
//			 unsigned long value1;
			 //long value2;
			 Queue^ LocalQueue = gcnew Queue();
			 unsigned int i;
			 unsigned char MessageChecksum;
//			 unsigned char tempbyte;
			 static unsigned char counter;



////test the display
//			 MessageChecksum = 0;
//			 for(i = 1; i < dSPI_CAN_PACKET_CHECKSUM_LOCATION; i++)
//			 {
//				 LocalMessageBuf[i] = i;
//			 }
//			 LocalMessageBuf[7] = timeCounter++;
//			 processMessageRollingTrace(LocalMessageBuf);
			 


			 //Quick check to see if tool is attached
			 if(AttachedState == TRUE)
			 {
				 this->toolStripLabel1->Text="Tool Connected";
				 //Autoclear these if we reach a limit...
				 Forms::toolStatusForm->label2->Text=ReceivedCANMessageLifeCounter.ToString();
				 Forms::toolStatusForm->label4->Text=TransmitCANMessageLifeCounter.ToString();
				 Forms::toolStatusForm->label6->Text=ReceivedUSBMessageLifeCounter.ToString();
				 Forms::toolStatusForm->label8->Text=TransmitUSBMessageLifeCounter.ToString();
				 Forms::toolStatusForm->label10->Text=EatBadMsgLifeCounter.ToString();
				 Forms::toolStatusForm->label12->Text=badCheckSumCounter.ToString();



				 //#define CAN_MESSAGE_BUFFER_SIZE	20000u
				 //unsigned int NumBytesInMessageBuffer = 0;
				 //unsigned char CANMessageBuffer[CAN_MESSAGE_BUFFER_SIZE];
				 //static unsigned char* CANMessageReadPointer = &CANMessageBuffer[0];
				 //static unsigned char* CANMessageWritePointer = &CANMessageBuffer[0];

				 //if (Forms::newMDIChild->getPauseTraceWindow() == FALSE)
				 {
					 //Should check to see if producer has produced data


					 //Grab Semaphore

					 //Threads::mySemaphore->Release();

					 //Keep looping until we have used up all the current data in the buffer.
					 while(NumBytesInMessageBuffer != 0)
					 {
						 Threads::mySemaphore->WaitOne();
						 //Grab 21 bytes (one CAN message)
						 for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++)
						 {
							 LocalMessageBuf[i] = (unsigned char)*CANMessageReadPointer++;
							 //Check for pointer wraparound
							 if(CANMessageReadPointer >= ((unsigned char*)&CANMessageBuffer[0] + CAN_MESSAGE_BUFFER_SIZE))
							 {
								 CANMessageReadPointer = (unsigned char*)&CANMessageBuffer[0] ;
							 }
							 NumBytesInMessageBuffer--;
							 if((signed int)NumBytesInMessageBuffer == -1)
							 {
								 NumBytesInMessageBuffer = 0;
							 }
						 }
						 Threads::mySemaphore->Release();

						 ////We have 1 CAN Message sitting in the LocalMessageBuf[].
						 ////Strip off the 2 leading SPI bytes
						 //for(i = 0; i < 19; i++)
						 //{
						 //	tempbyte = LocalMessageBuf[i+2];
						 //	LocalMessageBuf[i] = tempbyte;
						 //}

						 //debug code
						 //Now check the messageID byte and figure out what it is.
						 //if (LocalMessageBuf[0]!= 0xE3)
						 //{
						 //	MessageChecksum = LocalMessageBuf[0];
						 //}

						 LocalMessageBuf[0] = getCorrectMessageID(LocalMessageBuf[0]);

						 //Compute the checksum for the message.
						 //Byte 1 is the command byte.
						 //Byte 2 throught 18 is the data in the packet
						 //Byte 19 is the checksum byte - the for() loop doesn't add the checksum to compute the checksum

						 MessageChecksum = 0;
						 for(i = 1; i < dSPI_CAN_PACKET_CHECKSUM_LOCATION; i++)
						 {
							 MessageChecksum += (unsigned char)LocalMessageBuf[i];
						 }
						 //Now check if the computed checksum matches the one in the packet
						 if(MessageChecksum != LocalMessageBuf[dSPI_CAN_PACKET_CHECKSUM_LOCATION])
						 {

							 //Check to see if the message was articfact of sending a message to the FW
							 //Recall if we transmit to the CAN part... and it has nothing to send we will get 0xFFs

							 unsigned char dataByte;
							 bool isMessageAll_FFs;

							 isMessageAll_FFs = true;
							 for(i = 1; i < dSPI_CAN_PACKET_CHECKSUM_LOCATION; i++)
							 {
								 dataByte = (unsigned char)LocalMessageBuf[i];
								 if (dataByte != 0xFF)
								 {
									 isMessageAll_FFs = false;
								 }
							 }


							 if (isMessageAll_FFs == false)
							 {
								 //ERROR: Checksums don't match.  Should notify user that the data is untrustworthy
								 if (EatBadMsgLifeCounter < 25000)
								 {
									 EatBadMsgLifeCounter++;
								 }

								 badCheckSumCounter++;
								 if (badCheckSumCounter > 20)
								 {
									 //badCheckSumCounter = 0;
									 //There appears to be at least 20 bad checksums in a row request USB FW to stop transmitting
									 //This will cause the read to return early ... thus resetting the pipe
									 unsigned long timeout;
									 timeout = 500;
//									 if (WinUsb_SetPipePolicy(&MyWinUSBInterfaceHandle,0x81,PIPE_TRANSFER_TIMEOUT, sizeof(ULONG), &timeout))
//									 {
										 WinUsb_FlushPipe(MyWinUSBInterfaceHandle, 0x81);
//									 }
//									 else
//									 {
//										 WinUsb_ResetPipe(MyWinUSBInterfaceHandle, 0x81);
//									 }

								 }
							 }

						 }
						 else
						 {
							 //badCheckSumCounter = 0;

							 //GOOD: The checksums matched.  Data presumed legit and valid.

							 //Now update the GUI as appropriate for the message.
							 if(LocalMessageBuf[0] == 1000)
						     {
								 if (ReceivedCANMessageLifeCounter < 25000)
								 {
									 ReceivedCANMessageLifeCounter++;
								 }

								 if (Forms::rollingTraceForm->getPauseTraceWindow() == FALSE)
								 {
									 processMessageRollingTrace(LocalMessageBuf);
								 }

								 if (Forms::fixedTraceForm->getPauseTraceWindow() == FALSE)
								 {
									 processMessageFixedTrace(LocalMessageBuf);
								 }
								 else
								 {
									 //Still we should track the number received...
								 }
							 }
							 else if (LocalMessageBuf[0] == 2000)
							 {
								 if (TransmitCANMessageLifeCounter < 25000)
								 {
									 TransmitCANMessageLifeCounter++;
								 }
								 
								 if (Forms::rollingTraceForm->getPauseTraceWindow() == FALSE)
								 {
									 processMessageRollingTrace(LocalMessageBuf);
								 }

								 if (Forms::fixedTraceForm->getPauseTraceWindow() == FALSE)
								 {
									 processMessageFixedTrace(LocalMessageBuf);
								 }
								 else
								 {
									 //Still we should track the number received...
								 }
							 }
							 else if (LocalMessageBuf[0] == 600)
							 {
								 processIamAliveMessageFromCAN(LocalMessageBuf);
							 }
							 else if (LocalMessageBuf[0] == 700)
							 {
								 processIamAliveMessageFromUSB(LocalMessageBuf);
							 }
							 else
							 {
								 //Do nothing
							 }
							 //Clear the local buffer for next time
						 }
					 }

				 }//if (Forms::rollingTraceForm->getPauseTraceWindow() == FALSE)
			 }
			 else
			 {
				 this->toolStripLabel1->Text="Tool Disconnected";
				 this->toolStripLabel2->Text = "CAN BUS Speed";
				 this->toolStripLabel3->Text = "CAN Mode";
				 this->toolStripLabel4->Text = "Error Status";
				 this->toolStripLabel5->Text = "TX ERR: ?";
				 this->toolStripLabel6->Text = "RX ERR: ?";
				 this->toolStripLabel7->Text = "Trace Active";
				 this->toolStripLabel10->Text = "Termination: ?";
				 this->toolStripLabel11->Text="Logging Inactive";


				 this->toolStripLabel1->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel2->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel3->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel4->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel5->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel6->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel7->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel8->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel9->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel10->BackColor = System::Drawing::SystemColors::Control;
				 this->toolStripLabel11->BackColor = System::Drawing::SystemColors::Control;
			 }
		 }//private: System::Void updateGUIThread_Tick(System::Object^  sender, System::EventArgs^  e) {


void processTransmitMessages(unsigned int tempData[])
{
		 ULONG BytesWritten = 0;
		 static unsigned char counter = 0;
		 unsigned char CheckSum = 0;
		 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
		 unsigned int i;

		 //Initialize the buffer contents to all 0x00
		 while(BytesWritten < 64)
		 {
			 OutputPacketBuffer[BytesWritten] = 0;
			 BytesWritten++;
		 }

//		 OutputPacketBuffer[0] = 0x55; //header
//		 OutputPacketBuffer[1] = 0x46; //header
         OutputPacketBuffer[0] = tempData[0]; //Command like dTRANSMIT_MESSAGE_EV
		 OutputPacketBuffer[1] = tempData[1];
		 OutputPacketBuffer[2] = tempData[2];
		 OutputPacketBuffer[3] = tempData[3];
		 OutputPacketBuffer[4] = tempData[4];
		 OutputPacketBuffer[5] = tempData[5];
		 OutputPacketBuffer[6] = tempData[6];
		 OutputPacketBuffer[7] = tempData[7];
		 OutputPacketBuffer[8] = tempData[8];
		 OutputPacketBuffer[9] = tempData[9];
		 OutputPacketBuffer[10] = tempData[10];
		 OutputPacketBuffer[11] = tempData[11];
		 OutputPacketBuffer[12] = tempData[12];
		 OutputPacketBuffer[13] = tempData[13];
		 OutputPacketBuffer[14] = tempData[14];
		 OutputPacketBuffer[15] = tempData[15];
		 OutputPacketBuffer[16] = tempData[16];
		 OutputPacketBuffer[17] = tempData[17];

		 //Compute checksum byte
         for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++) //2 - Start checksum at Command, 19 last byte of timestamp, 20 is checksum byte
		 {
			 CheckSum += OutputPacketBuffer[i];
		 }
		 //Checksum byte
		 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;

		 //Send the 21 byte OUT packet to the USB device
		 WinUsb_WritePipe(MyWinUSBInterfaceHandle, 0x01, &OutputPacketBuffer[0], 19, &BytesWritten, NULL);
		 
		 if(TransmitUSBMessageLifeCounter < 25000)
		 {
		 TransmitUSBMessageLifeCounter++;
		 }
}

void processIamAliveMessageFromUSB(unsigned int tempData[])
{
//Not much comes from the USB
//Just version number and Termination
	TerminationResistanceSetting = tempData[1];
	USBFirmwareMajorVersion = tempData[2];
	USBFirmwareMinorVersion = tempData[3];	

	if(TerminationResistanceSetting == 0x01)
	{
		this->toolStripLabel10->Text = "Termination: OFF";
		Forms::hardwareSetupForm->label6->Text = "OFF";
	}
	if(TerminationResistanceSetting == 0x00)
	{
		this->toolStripLabel10->Text = "Termination: ON";
		Forms::hardwareSetupForm->label6->Text = "ON";
	}

}

void processIamAliveMessageFromCAN(unsigned int tempData[])
{
	unsigned int dummyInt;
	unsigned char dummyByte;
	unsigned char tempRXERRCnt = 0;
	unsigned char tempTXERRCnt = 0;

//Transmit Error
	tempTXERRCnt = tempData[1];
	this->toolStripLabel5->Text = "TX ERR: "+tempTXERRCnt.ToString();
//Receive Error
	tempRXERRCnt = tempData[2];
	this->toolStripLabel6->Text = "RX ERR: "+tempRXERRCnt.ToString();

//Shows if we overflowed on CAN
	if (tempData[3] == 0x01)
	{
		//Possible CAN traffic loss

//nothing now...
	}
	
	//Bus Status
	if(tempData[4] == 0x01)
	{
		this->toolStripLabel4->BackColor = System::Drawing::Color::Red;
		this->toolStripLabel4->Text = "Bus Off";
	}
	else if ((tempRXERRCnt > 127) || (tempTXERRCnt > 127))
	{
		this->toolStripLabel4->BackColor = System::Drawing::Color::Yellow;
		this->toolStripLabel4->Text = "Error Passive";
	}
	else
	{
		this->toolStripLabel4->BackColor = System::Drawing::Color::Green;
		this->toolStripLabel4->Text = "Error Normal";
	}

//Show bitrate that exists on the CAN micro
//Value comes in as two bytes


	dummyInt = tempData[5]; //Hi
	dummyInt = dummyInt << 8;
	dummyInt = dummyInt + tempData[6];

	switch (dummyInt)
{
case 20: //20 Kbps
	dummyByte = 0;
	break;

case 33: //33.3 Kbps
	dummyByte = 1;
	break;

case 50: //50.0 Kbps
	dummyByte = 2;
	break;	

case 80: //80.0 Kbps
	dummyByte = 3;
	break;

case 83: //83.3 Kbps
	dummyByte = 4;
	break;

case 100: //100 Kbps
	dummyByte = 5;
	break;

case 125: //125 Kbps
	dummyByte = 6;
	break;

case 150: //150 Kbps
	dummyByte = 7;
	break;

case 175: //175 Kbps
	dummyByte = 8;
	break;

case 200: //200 Kbps
	dummyByte = 9;
	break;

case 225: //225 Kbps
	dummyByte = 10;
	break;

case 250: //250 Kbps
	dummyByte = 11;
	break;

case 275: //275 Kbps
	dummyByte = 12;
	break;

case 300: //300 Kbps
	dummyByte = 13;
	break;

case 500: //500 Kbps
	dummyByte = 14;
	break;

case 625: //625 Kbps
	dummyByte = 15;
	break;

case 800: //800 Kbps
	dummyByte = 16;
	break;

case 1000: //1 Mbps
	dummyByte = 17;
	break;

default:
	//Shouldn't get here... 
	//if we do dump location 0
	dummyByte = 0;
	break;
}



	this->toolStripLabel2->Text = Forms::hardwareSetupForm->comboBox1->Items[dummyByte]->ToString();
	Forms::hardwareSetupForm->label2->Text = Forms::hardwareSetupForm->comboBox1->Items[dummyByte]->ToString();




//tempData[7] lost packets
//tempData[8] lost packets
	
	//Grab top three bits from CANSTAT
	dummyByte = tempData[9] & 0xE0;
	if (dummyByte == 0x00)
	{
		this->toolStripLabel3->Text = "Normal Mode";
		Forms::hardwareSetupForm->label4->Text = "Normal Mode";
		this->toolStripLabel3->BackColor = System::Drawing::Color::Green;
		
	}
	else if (dummyByte == 0x60)
	{
		this->toolStripLabel3->Text = "Listen Only Mode";
		Forms::hardwareSetupForm->label4->Text = "Listen Only Mode";
		this->toolStripLabel3->BackColor = System::Drawing::Color::Yellow;
	}
	else if (dummyByte == 0x80)
	{
		this->toolStripLabel3->Text = "Config Mode";
		Forms::hardwareSetupForm->label4->Text = "Config Mode";
		this->toolStripLabel3->BackColor = System::Drawing::Color::Red;
	}



//We should also pull the version number off of this as well

	CANFirmwareMajorVersion = tempData[10];
	CANFirmwareMinorVersion = tempData[11];


//Debug Mode is ON
	if (tempData[12] == 1)
	{
		this->toolStripLabel3->BackColor = System::Drawing::Color::Purple;
	}


	//timeStamp = tempData[17];
 //   timeStamp = timeStamp << 8;
	//timeStamp = timeStamp + tempData[16];
 //   timeStamp = timeStamp << 8;
	//timeStamp = timeStamp + tempData[15];
 //   timeStamp = timeStamp << 8;
	//timeStamp = timeStamp + tempData[14];
//	this->toolStripLabel10->Text = timeStamp
}



void processMessageFixedTrace(unsigned int tempData[])
{
static unsigned long storedIDarray[100];
static unsigned long storedIDtimeStampInLongArray[100];
static unsigned char currentNumberOfIDsOnTrace = 0;
static unsigned int storedIDCounterarray[100];
static unsigned char storedIDdirectionArray[100];
static bool storedIDExtendedFlagarray[100];


//unsigned long LocalstoredIDarray[100];
unsigned char LocalcurrentNumberOfIDsOnTrace = 0;

unsigned char tempCount;
unsigned char tempIDlocation;
bool isIDExtended;
bool tempIDfound;
unsigned char tempRowIndex = 0;
unsigned char tempDataIndex = 0;
unsigned char currentNumberOfRows = 0;
unsigned char maxNumberOfRows = 250;
unsigned char CAN_extendedHi_ID = 0;
unsigned char CAN_extendedLo_ID = 0;
unsigned char CAN_standardHi_ID = 0;
unsigned char CAN_standardLo_ID = 0;
unsigned char CAN_standardLo_ID_lo2bits = 0;
unsigned char CAN_standardLo_ID_hi3bits = 0;
unsigned char tempDLC;
unsigned char tempU8Data;
unsigned char tempU8Data1;
unsigned char tempU8Data2;
unsigned char tempU8Data3;
unsigned char tempU8Data4;
unsigned long ConvertedID = 0;
unsigned long displayData[13];
	double tempTimeStampDouble;
	double tempTimeStampDoubleDiff;

	static unsigned long tempTimeStamp;

	currentNumberOfRows = Forms::fixedTraceForm->dataGridView1->Rows->Count;
	if (currentNumberOfRows > maxNumberOfRows)
	{
		currentNumberOfRows = maxNumberOfRows;
		currentNumberOfIDsOnTrace = maxNumberOfRows;
//Should delete oldest record
		Forms::fixedTraceForm->dataGridView1->Rows->Remove(Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfRows]);
	}



//massage new data
//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

//Display Col 0
     displayData[0] = 1; //received data

//Display Col 0
if (tempData[0] == 1000)
	displayData[0] = 1; //received data
if (tempData[0] == 2000)
	displayData[0] = 2; //transmit data


	 //toss out  = tempData[tempDataIndex]; ... this equals the command byte
	 tempDataIndex++;

//Display Col 1
	 CAN_extendedHi_ID = tempData[tempDataIndex];
	 tempDataIndex++;
	 CAN_extendedLo_ID = tempData[tempDataIndex];
	 tempDataIndex++;
	 CAN_standardHi_ID = tempData[tempDataIndex];
	 tempDataIndex++;
	 CAN_standardLo_ID = tempData[tempDataIndex];
	 tempDataIndex++;

	 isIDExtended = false;
	 if ((CAN_standardLo_ID & 0x08) != 0x08) //test bit 3 is cleared 
	 {
		 isIDExtended = false;
	 }
	 else
	 {
		 isIDExtended = true;
	 }

	 if (isIDExtended == false) //test bit 3 is cleared 
	 {
		 //if standard message (11 bits)
		 //EIDH = 0 + EIDL = 0 + SIDH + upper three bits SIDL (3rd bit needs to be clear)
		 //1111 1111 111
		 ConvertedID = (CAN_standardHi_ID << 3);
		 ConvertedID = ConvertedID + (CAN_standardLo_ID >> 5);

//tempIDString = (ConvertedID.ToString)
	 }
	 else
	 {
		 //if extended messsage (29bits)
		 //SIDH + upper three bits SIDL (3rd bit needs to be set) lower two bits + EIDH + EIDL
		 //CAN_standardHi_ID + CAN_standardLo_ID + CAN_extendedHi_ID + CAN_extendedLo_ID

        
		 //ConvertedID = (CAN_standardHi_ID * 16777215)
		 //ConvertedID = ConvertedID + (CAN_standardHi_ID * 65536)
		 //ConvertedID = ConvertedID + (CAN_standardHi_ID * 256)
		 //ConvertedID = ConvertedID + (CAN_standardHi_ID * 65536)
		 CAN_standardLo_ID_lo2bits = (CAN_standardLo_ID & 0x03);
		 CAN_standardLo_ID_hi3bits = (CAN_standardLo_ID >> 5);
		 ConvertedID = (CAN_standardHi_ID << 3);
		 ConvertedID = ConvertedID + CAN_standardLo_ID_hi3bits;
		 ConvertedID = (ConvertedID << 2);
		 ConvertedID = ConvertedID + CAN_standardLo_ID_lo2bits;
		 ConvertedID = (ConvertedID << 8);
		 ConvertedID = ConvertedID + CAN_extendedHi_ID;
		 ConvertedID = (ConvertedID << 8);
		 ConvertedID = ConvertedID + CAN_extendedLo_ID;
		 // sHi       / sLo    / eHi       / eLo
		 // 1111 1111 / 111 11 / 1111 1111 / 1111 1111

//		 tempIDString = (ConvertedID.ToString + "x")
	 }
     displayData[1] = ConvertedID;

//Display DLC
	 displayData[2] = tempData[tempDataIndex];
	 tempDLC = tempData[tempDataIndex];
	 tempDataIndex++;

//Display Data
	 displayData[3] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[4] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[5] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[6] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[7] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[8] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[9] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[10] = tempData[tempDataIndex];
	 tempDataIndex++;
	
//Display Timestamp
///////////////////////////////////////////////////////////////////
//.................................................................
//Display Timestamp
//Set temperory timestamp to zero
	 fixTempTimeStamp = 0;

//Grab the four bytes of timestamp
	 tempU8Data1 = tempData[tempDataIndex]; //ram
	 tempDataIndex++;
	 tempU8Data2 = tempData[tempDataIndex]; //ram
	 tempDataIndex++;

	 tempU8Data3 = tempData[tempDataIndex]; //ram
	 tempDataIndex++;
	 tempU8Data4 = tempData[tempDataIndex]; //CCP
	 tempDataIndex++;
	 
	 fixTempTimeStamp = tempU8Data1 << 16;
	 fixTempTimeStamp += tempU8Data2 << 8;
	 fixTempTimeStamp += tempU8Data3;
	 fixTempTimeStamp = fixTempTimeStamp*1000;

	 fixTempTimeStamp += tempU8Data4;
	 
	 tempTimeStampDouble = (double)fixTempTimeStamp *(double)0.000001; //This will be displayed

//Calculate the diff later... the diff relates to the message of the same ID	 
//.................................................................
///////////////////////////////////////////////////////////////////







//First Check to see if the display was cleared... if so reset everything on this end
	 if (Forms::fixedTraceForm->ClearedDisplay==true)
	 {
		 Forms::fixedTraceForm->ClearedDisplay=false;
		 currentNumberOfIDsOnTrace = 0;
		 tempCount = 0;
		 while(tempCount < 100)
		 {
			 storedIDarray[tempCount] = 0;
			 storedIDCounterarray[tempCount] = 0;
			 storedIDExtendedFlagarray[tempCount] = false;
			 tempCount++;
		 }
	 }

//Check to see if ID already exists on Trace
	 tempIDfound = false;
	 tempCount = 0;
	 while (tempCount < currentNumberOfIDsOnTrace)
	 {
//Check ID match
		 if (storedIDarray[tempCount] == displayData[1])
		 {
//Check extended match
			 if (storedIDExtendedFlagarray[tempCount] == isIDExtended)
			 {
				 //check to see if that ID is TX or RX
				 if (storedIDdirectionArray[tempCount] == displayData[0])
				 {
					 tempIDfound = true;
					 tempIDlocation = tempCount;
					 storedIDCounterarray[tempCount]++;
					 tempCount = currentNumberOfIDsOnTrace; //Break out of loop
				 }
			 }
		 }
	 tempCount++;
	 }


	 if (tempIDfound == true)
	 {
//ID already exists... so don't add new row	 
		 //Direction

if (displayData[0] == 1)
{
		 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Value =  "RX";
}
if (displayData[0] == 2)
{
		 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Value =  "TX";
}

		 //ID
		 ConvertedID = displayData[dID_COLUMN_INDEX];
		 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dID_COLUMN_INDEX]->Value = formatIDforDisplay(ConvertedID,isIDExtended);
		 
		 //DLC
		 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDLC_COLUMN_INDEX]->Value = displayData[dDLC_COLUMN_INDEX];
		 switch(tempDLC)
		 {
		 case 0:
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;

		 case 1:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 2:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 3:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 4:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 5:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 6:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 7:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA6_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 8:
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = displayData[dDATA0_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = displayData[dDATA1_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = displayData[dDATA2_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = displayData[dDATA3_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = displayData[dDATA4_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = displayData[dDATA5_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = displayData[dDATA6_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = displayData[dDATA7_COLUMN_INDEX];

			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA6_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA7_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 break;
		 default:
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA0_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 }



		 //Time Stamp
		 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Value = tempTimeStampDouble.ToString("0.0000");

		 //Delta
		 //Calculate the diff
		 fixTempTimeStampOld = storedIDtimeStampInLongArray[tempIDlocation];
		 fixTempTimeStampdiff = (unsigned long)fixTempTimeStamp - (unsigned long)fixTempTimeStampOld;
		 tempTimeStampDoubleDiff = (double)fixTempTimeStampdiff *0.000001;
		 storedIDtimeStampInLongArray[tempIDlocation] = fixTempTimeStamp;
		 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Value = tempTimeStampDoubleDiff.ToString("0.000");

		 //Count 
		 Forms::fixedTraceForm->dataGridView1->Rows[tempIDlocation]->Cells[dBUTTON_OR_COUNT_COLUMN_INDEX]->Value = storedIDCounterarray[tempIDlocation];
	 }
	 else
	 {
		 //id doesn't exist ...  and add it to stored array
		 storedIDarray[currentNumberOfIDsOnTrace] = displayData[1];
		 storedIDExtendedFlagarray[currentNumberOfIDsOnTrace] = isIDExtended;
		 storedIDCounterarray[currentNumberOfIDsOnTrace]++;
		 storedIDdirectionArray[currentNumberOfIDsOnTrace] = displayData[0];
		 storedIDtimeStampInLongArray[currentNumberOfIDsOnTrace] = fixTempTimeStamp;


		 //id doesn't exist ... add new row on datagridview
		 Forms::fixedTraceForm->dataGridView1->Rows->Insert(currentNumberOfIDsOnTrace);
		 tempRowIndex = 0;
		 tempDataIndex = 0;
		 //Direction
if (displayData[0] == 1)
{
		 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Value = "RX";
}
if (displayData[0] == 2)
{
		 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Value = "TX";
}
		 //ID
		 ConvertedID = displayData[dID_COLUMN_INDEX];
		 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dID_COLUMN_INDEX]->Value = formatIDforDisplay(ConvertedID,isIDExtended);

		 //DLC
		 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDLC_COLUMN_INDEX]->Value = displayData[dDLC_COLUMN_INDEX];
		 switch(tempDLC)
		 {
		 case 0:
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;

		 case 1:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 2:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 3:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 4:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 5:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 6:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 7:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA6_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 8:
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value = displayData[dDATA0_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value = displayData[dDATA1_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value = displayData[dDATA2_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value = displayData[dDATA3_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value = displayData[dDATA4_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = displayData[dDATA5_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = displayData[dDATA6_COLUMN_INDEX];
			 //Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = displayData[dDATA7_COLUMN_INDEX];

			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA6_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA7_COLUMN_INDEX];
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value =  formatDataForDisplay(tempU8Data);
			 break;
		 default:
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA0_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 }

		 //Time Stamp
		 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Value = tempTimeStampDouble.ToString("0.0000");

		 //Delta
		 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Value = 0;

		 //Count 
		 Forms::fixedTraceForm->dataGridView1->Rows[currentNumberOfIDsOnTrace]->Cells[dBUTTON_OR_COUNT_COLUMN_INDEX]->Value = storedIDCounterarray[currentNumberOfIDsOnTrace];
		 
		 currentNumberOfIDsOnTrace++;
	 }
}


void processMessageRollingTrace(unsigned int tempData[])
{
	unsigned char tempRowIndex = 0;
	unsigned char tempDataIndex = 0;
	unsigned char currentNumberOfRows = 0;
	unsigned char maxNumberOfRows = 250;
	unsigned char tempDLC = 0;
	bool isIDExtended;
	unsigned char CAN_extendedHi_ID = 0;
	unsigned char CAN_extendedLo_ID = 0;
	unsigned char CAN_standardHi_ID = 0;
	unsigned char CAN_standardLo_ID = 0;
	unsigned char CAN_standardLo_ID_lo2bits = 0;
	unsigned char CAN_standardLo_ID_hi3bits = 0;
	unsigned long ConvertedID = 0;
	unsigned long displayData[13];

	unsigned char tempU8Data;
	//unsigned int tempU16Data;
	unsigned char tempU8Data1;
	unsigned char tempU8Data2;
	unsigned char tempU8Data3;
	unsigned char tempU8Data4;

	double tempTimeStampDouble;
	double tempTimeStampDoubleDiff;
//	static double tempTimeStampDoubleOld;

//	currentNumberOfRows = Forms::newMDIChild->dataGridView1->Rows->Count;
	currentNumberOfRows = Forms::rollingTraceForm->dataGridView1->Rows->Count;
	if (currentNumberOfRows > maxNumberOfRows)
	{
		currentNumberOfRows = maxNumberOfRows;
//Should delete oldest record
//		Forms::newMDIChild->dataGridView1->Rows->Remove(Forms::newMDIChild->dataGridView1->Rows[currentNumberOfRows]);
		Forms::rollingTraceForm->dataGridView1->Rows->Remove(Forms::rollingTraceForm->dataGridView1->Rows[currentNumberOfRows]);
	}



//massage new data
//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm

//Display Col 0
if (tempData[0] == 1000)
	displayData[0] = 1; //received data
if (tempData[0] == 2000)
	displayData[0] = 2; //transmit data

	 //toss out  = tempData[tempDataIndex]; ... this equals the command byte
	 tempDataIndex++;

//Display Col 1
	 CAN_extendedHi_ID = tempData[tempDataIndex];
	 tempDataIndex++;
	 CAN_extendedLo_ID = tempData[tempDataIndex];
	 tempDataIndex++;
	 CAN_standardHi_ID = tempData[tempDataIndex];
	 tempDataIndex++;
	 CAN_standardLo_ID = tempData[tempDataIndex];
	 tempDataIndex++;


	 isIDExtended = false;
	 if ((CAN_standardLo_ID & 0x08) != 0x08) //test bit 3 is cleared 
	 {
		 isIDExtended = false;
	 }
	 else
	 {
		 isIDExtended = true;
	 }
    
	 if (isIDExtended == false) //test bit 3 is cleared 
	 {
		 //if standard message (11 bits)
		 //EIDH = 0 + EIDL = 0 + SIDH + upper three bits SIDL (3rd bit needs to be clear)
		 //1111 1111 111
		 ConvertedID = (CAN_standardHi_ID << 3);
		 ConvertedID = ConvertedID + (CAN_standardLo_ID >> 5);

//tempIDString = (ConvertedID.ToString)
	 }
	 else
	 {
		 //if extended messsage (29bits)
		 //SIDH + upper three bits SIDL (3rd bit needs to be set) lower two bits + EIDH + EIDL
		 //CAN_standardHi_ID + CAN_standardLo_ID + CAN_extendedHi_ID + CAN_extendedLo_ID

        
		 //ConvertedID = (CAN_standardHi_ID * 16777215)
		 //ConvertedID = ConvertedID + (CAN_standardHi_ID * 65536)
		 //ConvertedID = ConvertedID + (CAN_standardHi_ID * 256)
		 //ConvertedID = ConvertedID + (CAN_standardHi_ID * 65536)
		 CAN_standardLo_ID_lo2bits = (CAN_standardLo_ID & 0x03);
		 CAN_standardLo_ID_hi3bits = (CAN_standardLo_ID >> 5);
		 ConvertedID = (CAN_standardHi_ID << 3);
		 ConvertedID = ConvertedID + CAN_standardLo_ID_hi3bits;
		 ConvertedID = (ConvertedID << 2);
		 ConvertedID = ConvertedID + CAN_standardLo_ID_lo2bits;
		 ConvertedID = (ConvertedID << 8);
		 ConvertedID = ConvertedID + CAN_extendedHi_ID;
		 ConvertedID = (ConvertedID << 8);
		 ConvertedID = ConvertedID + CAN_extendedLo_ID;
		 // sHi       / sLo    / eHi       / eLo
		 // 1111 1111 / 111 11 / 1111 1111 / 1111 1111

//		 tempIDString = (ConvertedID.ToString + "x")
	 }
     displayData[1] = ConvertedID;
//Display Col 2
	 displayData[2] = tempData[tempDataIndex];
     tempDLC = tempData[tempDataIndex];
	 tempDataIndex++;

//Display Data
	 displayData[3] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[4] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[5] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[6] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[7] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[8] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[9] = tempData[tempDataIndex];
	 tempDataIndex++;
	 displayData[10] = tempData[tempDataIndex];
	 tempDataIndex++;
	
//Display Timestamp
//Set temperory timestamp to zero
	 rtTempTimeStamp = 0;

//Grab the four bytes of timestamp
	 tempU8Data1 = tempData[tempDataIndex]; //ram
	 tempDataIndex++;
	 tempU8Data2 = tempData[tempDataIndex]; //ram
	 tempDataIndex++;

	 tempU8Data3 = tempData[tempDataIndex]; //ram
	 tempDataIndex++;
	 tempU8Data4 = tempData[tempDataIndex]; //CCP
	 tempDataIndex++;
	 
	 rtTempTimeStamp = tempU8Data1 << 16;
	 rtTempTimeStamp += tempU8Data2 << 8;
	 rtTempTimeStamp += tempU8Data3;
	 rtTempTimeStamp = rtTempTimeStamp*1000;

	 rtTempTimeStamp += tempU8Data4;
	 
	 rtTempTimeStampdiff = (unsigned long)rtTempTimeStamp - (unsigned long)rtTempTimeStampOld;
	 tempTimeStampDouble = (double)rtTempTimeStamp *(double)0.000001;
	 tempTimeStampDoubleDiff = (double)rtTempTimeStampdiff *0.000001;
	 rtTempTimeStampOld = rtTempTimeStamp;

//Dummy dump new massaged data
//	Forms::newMDIChild->dataGridView1->Rows->Insert(0);
    Forms::rollingTraceForm->dataGridView1->Rows->Insert(0);
	tempRowIndex = 0;
	tempDataIndex = 0;
//	while(tempDataIndex < 13)
//	{
//		Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[tempDataIndex]->Value = displayData[tempDataIndex];
//		tempDataIndex++;
//	}
//lo NicForms::newMDIChild->textBox1->Text = lifeCounter.ToString();

		 //Direction
if (displayData[0] == 1)
{
		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Value = "RX";
}
if (displayData[0] == 2)
{
		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Value = "TX";
}

		 //ID
		 ConvertedID = displayData[dID_COLUMN_INDEX];
		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dID_COLUMN_INDEX]->Value = formatIDforDisplay(ConvertedID,isIDExtended);

		 //DLC
		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDLC_COLUMN_INDEX]->Value = displayData[dDLC_COLUMN_INDEX];
		 switch(tempDLC)
		 {
		 case 0:
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;

		 case 1:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 2:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 3:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 4:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 5:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 6:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 7:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA6_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 case 8:
			 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA6_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 tempU8Data = (unsigned char) displayData[dDATA7_COLUMN_INDEX];
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = formatDataForDisplay(tempU8Data);
			 break;
		 default:
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA0_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
			 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
			 break;
		 }

		 //Time Stamp
//		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Value = displayData[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX];

//		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Value = tempTimeStampDouble.ToString("0.000") + " " + tempU8Data1.ToString()+ " " + tempU8Data2.ToString()+ " " + tempU8Data3.ToString()+ " " + tempU8Data4.ToString();
		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Value = tempTimeStampDouble.ToString("0.0000");

		 //Delta
		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Value = tempTimeStampDoubleDiff.ToString("0.000");
//		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Value = "0";
		 //Count 
//		 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dBUTTON_OR_COUNT_COLUMN_INDEX]->Value;// = storedIDCounterarray[currentNumberOfIDsOnTrace];



		 if (this->l0->getContinueLogging() == true)
		 {
			 try 
			 {
				 //Time Stamp
				 
				 Data::logFileStreamWriter->Write(rtTempTimeStamp.ToString()+";");
//				 Data::logFileStreamWriter->Write(tempTimeStampDouble.ToString("0.0000"));

				 //Direction
				 if (displayData[0] == 1)
				 {
					 Data::logFileStreamWriter->Write("RX;");
				 }
				 if (displayData[0] == 2)
				 {
					 Data::logFileStreamWriter->Write("TX;");
				 }

				 //ID
				 ConvertedID = displayData[dID_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatIDforDisplay(ConvertedID,isIDExtended)+";");

				 //DLC
				 Forms::rollingTraceForm->dataGridView1->Rows[0]->Cells[dDLC_COLUMN_INDEX]->Value = displayData[dDLC_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(displayData[dDLC_COLUMN_INDEX].ToString()+";");
				 //DATA

				 tempU8Data = (unsigned char) displayData[dDATA0_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatDataForDisplay(tempU8Data)+";");
				 tempU8Data = (unsigned char) displayData[dDATA1_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatDataForDisplay(tempU8Data)+";");
				 tempU8Data = (unsigned char) displayData[dDATA2_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatDataForDisplay(tempU8Data)+";");
				 tempU8Data = (unsigned char) displayData[dDATA3_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatDataForDisplay(tempU8Data)+";");
				 tempU8Data = (unsigned char) displayData[dDATA4_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatDataForDisplay(tempU8Data)+";");
				 tempU8Data = (unsigned char) displayData[dDATA5_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatDataForDisplay(tempU8Data)+";");
				 tempU8Data = (unsigned char) displayData[dDATA6_COLUMN_INDEX];
				 Data::logFileStreamWriter->Write(formatDataForDisplay(tempU8Data)+";");
				 tempU8Data = (unsigned char) displayData[dDATA7_COLUMN_INDEX];
				 Data::logFileStreamWriter->WriteLine(formatDataForDisplay(tempU8Data));

						 Data::logFileStreamWriter->Flush();
					 }
					 catch (Exception^) 
					 {
							 this->l0->setContinueLogging(false);
							 Data::logFileStream->Close();
							 System::Windows::Forms::MessageBox::Show("ERROR 6.00.0\nUnable to Log Data", "Error");
					 }
				 }



		 if (refreshCounter == 200)
		 {
			 refreshCounter = 0;
		 this->Refresh();
		 }
		 refreshCounter++;
}

String^ formatIDforDisplay(unsigned long passInID,bool passInExtendedFlag)
{
	String^ returnValue;
	if (passInExtendedFlag == true)
	{
		if(userSelectedIDFormat == dNUMBER_FORMAT_HEX) //hex
		{
			returnValue = "0x"+passInID.ToString("X2")+"x";
		}
		else
		{
			returnValue = passInID.ToString()+"x";
		}
	}
	else
	{
		if(userSelectedIDFormat == dNUMBER_FORMAT_HEX) //hex
		{
			returnValue = "0x"+passInID.ToString("X2");
		}
		else
		{
			returnValue = passInID.ToString();
		}
	}
	return(returnValue);
}


//////////////////////////////
String^ formatDataForDisplay(unsigned char passInData)
{
	String^ returnValue;
	{
		if(userSelectedDataFormat == dNUMBER_FORMAT_HEX) //hex
		{
			returnValue = "0x"+passInData.ToString("X2");
		}
		else
		{
			returnValue = passInData.ToString();
		}
	}
	return(returnValue);
}
//////////////////////////////

private: System::Void readWriteUSBThread_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------BEGIN CUT AND PASTE BLOCK-----------------------------------------------------------------------------------

		/*This thread does the actual USB read/write operations (but only when AttachedState == TRUE) to the USB device.
		It is generally preferrable to write applications so that read and write operations are handled in a separate
		thread from the main form.  This makes it so that the main form can remain responsive, even if the I/O operations
		take a very long time to complete.

		Since this is a separate thread, this code below executes independently from the rest of the
		code in this application.  All this thread does is read and write to the USB device.  It does not update
		the form directly with the new information it obtains (such as the ANxx/POT Voltage or pushbutton state).
		The information that this thread obtains is stored in atomic global variables.
		Form updates are handled by the FormUpdateTimer Tick event handler function.

		This application sends packets to the endpoint buffer on the USB device by using the "WriteFile()" function.
		This application receives packets from the endpoint buffer on the USB device by using the "ReadFile()" function.
		Both of these functions are documented in the MSDN library.

		All ReadFile() and WriteFile() operations in this example project are synchronous.  They are blocking function
		calls and only return when they are complete, or if they fail because of some event, such as the user unplugging
		the device.  It is possible to call these functions with "overlapped" structures, and use them as non-blocking
		asynchronous I/O function calls.  

		Note:  This code may perform differently on some machines when the USB device is plugged into the host through a
		USB 2.0 hub, as opposed to a direct connection to a root port on the PC.  In some cases the data rate may be slower
		when the device is connected through a USB 2.0 hub.  This performance difference is believed to be caused by
		the issue described in Microsoft knowledge base article 940021:
		http://support.microsoft.com/kb/940021/en-us 

		Higher effective bandwidth (up to the maximum offered by interrupt endpoints), both when connected
		directly and through a USB 2.0 hub, can generally be achieved by queuing up multiple pending read and/or
		write requests simultaneously.  This can be done when using	asynchronous I/O operations (calling ReadFile() and
		WriteFile()	with overlapped structures).  The Microchip	HID USB Bootloader application uses asynchronous I/O
		for some USB operations and the source code can be used	as an example.*/

		//----------------------------------------------
		//NEW CODE WAS ADDED HERE: LAB2 Goal 2.
		//----------------------------------------------
//		unsigned char OUTBuffer[64];	//Allocate a memory buffer equal to the OUT endpoint size + 1
//		unsigned char INBuffer[64];		//Allocate a memory buffer equal to the IN endpoint size + 1
#define USB_IN_READ_REQUEST_SIZE	(dSPI_CAN_PACKET_SIZE * 90)
		unsigned char INBuffer[USB_IN_READ_REQUEST_SIZE];		//Allocate a memory buffer equal to the IN endpoint size + 1



		DWORD BytesWritten = 0;
		DWORD BytesRead = 0;

//		unsigned char USBmessageIndex;
		unsigned char tempCount = 0;
//		unsigned int tempIntCount;
		unsigned int messageID = 0;
		bool ok2dumpMore = true;
		unsigned int i;
//		unsigned char eatBadMsg;
		bool DiscardThisMessage = false;



		//First empty the global data buffer
		CANMessageWritePointer = (unsigned char*)&CANMessageBuffer[0];
		CANMessageReadPointer = (unsigned char*)&CANMessageBuffer[0];
		memset(CANMessageWritePointer, 0x00, CAN_MESSAGE_BUFFER_SIZE);


		while(true)
		{
			Sleep(1);

			//Check if we have room in our buffer to receive more data.
			if(NumBytesInMessageBuffer >= (CAN_MESSAGE_BUFFER_SIZE - USB_IN_READ_REQUEST_SIZE))
			{
				ok2dumpMore = false;
			}
			else
			{
				ok2dumpMore = true;
			}

			if(AttachedState == TRUE)	//Do not try to use the read/write handles unless the USB device is attached and ready
			{

//////////////
//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
////Should stuff at least three messages per USB packet
//
//if (GlobalNeed2Transmit == true)// Simple CAN transmit wants to occur
//  {
//  if () //CAN message Location 0
//    {
//
//    }
//  else if () //CAN message Location 1
//    {
//
//    }
//  else if () //CAN message Location 2
//    {
//
//    }
//  else if () //CAN message Location 3
//    {
//
//    }
//  else if () //CAN message Location 4
//    {
//
//    }
//  else if () //CAN message Location 5
//    {
//
//    }
//  else if () //CAN message Location 6
//    {
//
//    }
//  else if () //CAN message Location 7
//    {
//
//    }
//  else if () //CAN message Location 8
//    {
//
//    }
//  else if () //CAN message Location 9
//    {
//
//    }
//  else
//    {
//    //Should never get here
//    }
//  }
//else if () //Group Transmit wants to occur
//  {
//  if () //From Group 1
//    {
//
//    }
//  else if () //From Group 2
//    {
//
//    }
//  else if ()  //From Group 3
//    {
//
//    }
//  else
//    {
//    //Should never get here
//    }
//  }
//else if () //Else we want to transmit from the Hardware Control
//  {
//
//  }
//else if () //Else we want to transmit from the Memory Read Control
//  {
//
//  }
//  else
//  {
//  //Should never get here
//  }
//mmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm
//////////////


				if (ok2dumpMore == true)
				{
					if(WinUsb_ReadPipe(MyWinUSBInterfaceHandle, 0x81, &INBuffer[0], USB_IN_READ_REQUEST_SIZE, &BytesRead, NULL))	//Blocking function until either 640 bytes are read, or a short packet is received, unless an "overlapped" structure is used
					{


						
						if ((BytesRead % dSPI_CAN_PACKET_SIZE) !=0)
						{
							if (EatBadMsgLifeCounter < 25000)
							{
								EatBadMsgLifeCounter++;
							}
						}




//for(i=0;i<BytesRead;i++)
//{
//	if((i % dSPI_CAN_PACKET_SIZE) == 0)
//	{
//		if(INBuffer[i] != 0x55)
//			EatBadMsgCounter++;
////		while(true);
//
//		if(INBuffer[i+1] != 0x46)
//			EatBadMsgCounter++;
//
//		if(INBuffer[i+2] != 0xE3)
//			EatBadMsgCounter++;
//	}
//}


						//this is incremented whenever we receive a packet
if (ReceivedUSBMessageLifeCounter < 25000)
{
							ReceivedUSBMessageLifeCounter = ReceivedUSBMessageLifeCounter + BytesRead/dSPI_CAN_PACKET_SIZE;
}
else
{
							ReceivedUSBMessageLifeCounter = 25000;
}





						//Grab Sempahore
						Threads::mySemaphore->WaitOne();
						
						//Copy the received USB data into global data buffer that can be read by the GUI update thread.
						if(NumBytesInMessageBuffer < (CAN_MESSAGE_BUFFER_SIZE - USB_IN_READ_REQUEST_SIZE))
						{
							for(i = 0; i < BytesRead; i++)
							{
								//if((i % dSPI_CAN_PACKET_SIZE) == 0)
								//{
								//	if(INBuffer[i] == 0xFF)
								//	{
								//	break;//	i +=dSPI_CAN_PACKET_SIZE;
								//	}
								//}
										*CANMessageWritePointer++ = INBuffer[i];
										//Check for pointer wraparound
										if(CANMessageWritePointer >= ((unsigned char*)&CANMessageBuffer[0] + CAN_MESSAGE_BUFFER_SIZE))
										{
											CANMessageWritePointer = (unsigned char*)&CANMessageBuffer[0];

								}
							}
							NumBytesInMessageBuffer += BytesRead;
						}
		
						//Release Semaphore
						Threads::mySemaphore->Release();



					}//if(WinUsb_ReadPipe(MyWinUSBInterfaceHandle, 0x81, &INBuffer[0], 64, &BytesRead, NULL))	//Blocking function, unless an "overlapped" structure is used
				}//if (ok2dumpMore == true)
			} //end of: if(AttachedState == TRUE)
			else
			{
				Sleep(1);	//Add a small delay.  Otherwise, this while(true) loop can execute very fast and cause 
							//high CPU utilization, with no particular benefit to the application.
			}
		} //end of while(true) loop
//-------------------------------------------------------END CUT AND PASTE BLOCK-------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
		 }


//#define dCHANGE_BIT_RATE_RSP 0xE1
//#define dTRANSMIT_MESSAGE_RSP 0xE2
//#define dRECEIVE_MESSAGE 0xE3
//#define dTRIGGER_EVENT 0xE4
//#define dSETUP_TRIGGER_RSP 0xE5
//#define dERROR_COUNT_STATUS 0xE6
//#define dREAD_REGISTER_DIRECTLY_RSP 0xE7
//#define dREAD_FW_VERSION_RSP 0xE8
//#define dDEBUG_MODE_RSP 0xF0
//#define dI_AM_ALIVE 0xF5

#define dDUMMY_DATA 5000

		 unsigned int getCorrectMessageID(unsigned char checkCommandByte)
{
	unsigned int returnValue;
    returnValue = dDUMMY_DATA;

	switch(checkCommandByte)
	{
//	case dCHANGE_BIT_RATE_RSP: //Rolled into the I'm alive message
//	case dREAD_FW_VERSION_RSP:

	case dI_AM_ALIVE_FROM_CAN:
		returnValue = 600;
		break;

	case dI_AM_ALIVE_FROM_USB:
		returnValue = 700;
		break;

	case dRECEIVE_MESSAGE:
		returnValue = 1000;
		break;
	
	case dTRANSMIT_MESSAGE_RSP: //CAN lets us know that last message was transmited ok
		returnValue = 2000;
		break;

	default:
		returnValue = dDUMMY_DATA;
		break;
	}
	return(returnValue);
}


private: System::Void transmitTimer_Tick(System::Object^  sender, System::EventArgs^  e) {
//do nothing
		 }


private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {

			 

		 }

private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
		 ULONG BytesWritten = 0;
		 static unsigned char counter = 0;
		 unsigned char CheckSum = 0;
		 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
		 unsigned int i;

		 //Initialize the buffer contents to all 0x00
		 while(BytesWritten < 64)
		 {
			 OutputPacketBuffer[BytesWritten] = 0;
			 BytesWritten++;
		 }

		 OutputPacketBuffer[0] = dCHANGE_BIT_RATE; //Command
		 OutputPacketBuffer[1] = dCAN_1000KBPS_40MHZ;

		 //Compute checksum byte
         for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++) //2 - Start checksum at Command, 19 last byte of timestamp, 20 is checksum byte
		 {
			 CheckSum += OutputPacketBuffer[i];
		 }
		 //Checksum byte
		 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;

		 //Send the 21 byte OUT packet to the USB device
		 WinUsb_WritePipe(MyWinUSBInterfaceHandle, 0x01, &OutputPacketBuffer[0], 19, &BytesWritten, NULL);
		 if(TransmitUSBMessageLifeCounter < 25000)
		 {
		 TransmitUSBMessageLifeCounter++;
		 }
		 }



////////////////////////////////////////////////////
//Transmit Bitrate Change to CAN
////////////////////////////////////////////////////
public: static void transmitBitrateChange(unsigned int passInBitrate){
		 ULONG BytesWritten = 0;
		 static unsigned char counter = 0;
		 unsigned char CheckSum = 0;
		 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
		 unsigned int i;
		 unsigned char hiByte;
		 unsigned char loByte;
		 
		 loByte = passInBitrate & 0x00FF;
		 hiByte = passInBitrate >> 8;



		 //Initialize the buffer contents to all 0x00
		 while(BytesWritten < 64)
		 {
			 OutputPacketBuffer[BytesWritten] = 0;
			 BytesWritten++;
		 }

		 OutputPacketBuffer[0] = dCHANGE_BIT_RATE; //Command
		 OutputPacketBuffer[1] = hiByte; //Hi byte
		 OutputPacketBuffer[2] = loByte; //Lo Byte


		 //Compute checksum byte
         for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++)
		 {
			 CheckSum += OutputPacketBuffer[i];
		 }
		 //Checksum byte
		 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;
		 WinUsb_WritePipe(MyWinUSBInterfaceHandle, 0x01, &OutputPacketBuffer[0], 19, &BytesWritten, NULL);
		 if(TransmitUSBMessageLifeCounter < 25000)
		 {
		 TransmitUSBMessageLifeCounter++;
		 }
}


////////////////////////////////////////////////////
//Transmit CANMode Change to CAN
////////////////////////////////////////////////////
public: static void transmitCANModeChange(unsigned char passInCANMode){
		 ULONG BytesWritten = 0;
		 static unsigned char counter = 0;
		 unsigned char CheckSum = 0;
		 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
		 unsigned int i;

		 //Initialize the buffer contents to all 0x00
		 while(BytesWritten < 64)
		 {
			 OutputPacketBuffer[BytesWritten] = 0;
			 BytesWritten++;
		 }

		 OutputPacketBuffer[0] = dCHANGE_CAN_MODE; //Command
		 OutputPacketBuffer[1] = passInCANMode;

		 //Compute checksum byte
         for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++)
		 {
			 CheckSum += OutputPacketBuffer[i];
		 }
		 //Checksum byte
		 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;
		 WinUsb_WritePipe(MyWinUSBInterfaceHandle, 0x01, &OutputPacketBuffer[0], 19, &BytesWritten, NULL);
		 if(TransmitUSBMessageLifeCounter < 25000)
		 {
		 TransmitUSBMessageLifeCounter++;
		 }
}






////////////////////////////////////////////////////
//Transmit Termination Change to USB
////////////////////////////////////////////////////
public: static void transmitTerminationChange(unsigned char passInTermination){
		 ULONG BytesWritten = 0;
		 static unsigned char counter = 0;
		 unsigned char CheckSum = 0;
		 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
		 unsigned int i;

		 //Initialize the buffer contents to all 0x00
		 while(BytesWritten < 64)
		 {
			 OutputPacketBuffer[BytesWritten] = 0;
			 BytesWritten++;
		 }

		 OutputPacketBuffer[0] = dSETUP_TERMINATION_RESISTANCE; //Command
		 OutputPacketBuffer[1] = passInTermination;

		 //Compute checksum byte
         for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++)
		 {
			 CheckSum += OutputPacketBuffer[i];
		 }
		 //Checksum byte
		 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;
		 WinUsb_WritePipe(MyWinUSBInterfaceHandle, 0x01, &OutputPacketBuffer[0], 19, &BytesWritten, NULL);
		 if(TransmitUSBMessageLifeCounter < 25000)
		 {
		 TransmitUSBMessageLifeCounter++;
		 }
}

//////////////////////////////////////////////////


//private: System::Void button1_Click_1(System::Object^  sender, System::EventArgs^  e) {
//String^ input;
//int  result;
//			 //Send message to request version
//			 		 ULONG BytesWritten = 0;
//		 static unsigned char counter = 0;
//		 unsigned char CheckSum = 0;
//		 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
//		 unsigned int i;
//
//		 //Initialize the buffer contents to all 0x00
//		 while(BytesWritten < 64)
//		 {
//			 OutputPacketBuffer[BytesWritten] = 0;
//			 BytesWritten++;
//		 }
//
//		 OutputPacketBuffer[0] = dTOGGLE_LED; //Command
//
////BOTH_MICROS used for ALL off
//
//		 input = this->textBox1->Text;
//		 System::Int32::TryParse(input,result);
//		 OutputPacketBuffer[1] = result;
//		 
//		 input = this->textBox2->Text;
//		 System::Int32::TryParse(input,result);
//		 OutputPacketBuffer[2] = result;
//
//		 input = this->textBox3->Text;
//		 System::Int32::TryParse(input,result);
//		 OutputPacketBuffer[3] = result;
//
//		 //Compute checksum byte
//         for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++)
//		 {
//			 CheckSum += OutputPacketBuffer[i];
//		 }
//		 //Checksum byte
//		 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;
//		 WinUsb_WritePipe(MyWinUSBInterfaceHandle, 0x01, &OutputPacketBuffer[0], 19, &BytesWritten, NULL);
//		 if(TransmitUSBMessageLifeCounter < 25000)
//		 {
//		 TransmitUSBMessageLifeCounter++;
//		 }
//		 }
//private: System::Void button2_Click_1(System::Object^  sender, System::EventArgs^  e) {
//String^ input;
//int  result;
////Send message to request version
//			 		 ULONG BytesWritten = 0;
//		 static unsigned char counter = 0;
//		 unsigned char CheckSum = 0;
//		 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
//		 unsigned int i;
//
//		 //Initialize the buffer contents to all 0x00
//		 while(BytesWritten < 64)
//		 {
//			 OutputPacketBuffer[BytesWritten] = 0;
//			 BytesWritten++;
//		 }
//
//		 OutputPacketBuffer[0] = dDEBUG_MODE; //Command
//		 
//		 input = this->textBox1->Text;
//		 System::Int32::TryParse(input,result);
//		 OutputPacketBuffer[1] = result;
//
//		 //Compute checksum byte
//         for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++)
//		 {
//			 CheckSum += OutputPacketBuffer[i];
//		 }
//		 //Checksum byte
//		 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;
//		 WinUsb_WritePipe(MyWinUSBInterfaceHandle, 0x01, &OutputPacketBuffer[0], 19, &BytesWritten, NULL);
//		 if(TransmitUSBMessageLifeCounter < 25000)
//		 {
//		 TransmitUSBMessageLifeCounter++;
//		 }
//
//		 }



private: System::Void processSlowUserRequest_Tick(System::Object^  sender, System::EventArgs^  e) {
			 //Used for working with NOW USB requests (i.e. the LOG File, bitrate requests, etc.)
			 //Quick check to see if tool is attached
			 if(AttachedState == TRUE)
			 {
				 //Check to see if the user wants to log
				 if (this->l0->getStartLogging() == true)
				 {
					 this->l0->setStartLogging(false);
					 //Open file writer...
					 Data::logFileStream = gcnew FileStream(this->l0->getlogFileName(), FileMode::Append);
					 Data::logFileStreamWriter = gcnew StreamWriter(Data::logFileStream);
					 //					 Data::logFileBinWriter = gcnew BinaryWriter(Data::logFileStream);

					 try 
					 {
						 Data::logFileStreamWriter->WriteLine("//---------------------------------");
						 Data::logFileStreamWriter->WriteLine("Microchip Technology Inc.");
						 Data::logFileStreamWriter->WriteLine("CAN BUS Analyzer");
						 Data::logFileStreamWriter->WriteLine("Released November 2nd 2011");
						 Data::logFileStreamWriter->WriteLine("");
						 Data::logFileStreamWriter->WriteLine("PC Software Information:");
						 Data::logFileStreamWriter->WriteLine("     GUI Version: {0}.{1}",GUIMajorVersion.ToString(),GUIMinorVersion.ToString());
						 Data::logFileStreamWriter->WriteLine("Firmware Information:");
						 Data::logFileStreamWriter->WriteLine("     USB Version: {0}.{1}",USBFirmwareMajorVersion.ToString(),USBFirmwareMinorVersion.ToString());
						 Data::logFileStreamWriter->WriteLine("     CAN Version: {0}.{1}",CANFirmwareMajorVersion.ToString(),CANFirmwareMinorVersion.ToString());
						 Data::logFileStreamWriter->WriteLine("");
						 Data::logFileStreamWriter->WriteLine("Logging Started: {0}", System::DateTime::Now.ToString());
						 Data::logFileStreamWriter->WriteLine("//---------------------------------");

						 Data::logFileStreamWriter->Flush();
						 //Data::logFileBinWriter->Write(System::DateTime::Now.ToString());

						 this->toolStripLabel11->Text="Logging Active";
						 this->toolStripLabel11->BackColor = System::Drawing::Color::Green;
					 }
					 catch (Exception^) 
					 {
						 //Message Box could not open file for writing
						 Data::logFileStream->Close();
					 }
				 }


				 if (this->l0->getStopLogging() == true)
				 {
					 this->l0->setStopLogging(false);

					 //					 if (logFileStream != NULL)
					 {
						 Data::logFileStream->Close();
						 this->toolStripLabel11->Text="Logging Inactive";
						 this->toolStripLabel11->BackColor = System::Drawing::SystemColors::Control;
					 }
				 }


				 //Check to see if there was a user requested change
				 if(this->b0->getBitrateFlag() == true)
				 {
					 transmitBitrateChange(b0->getBitrate());
					 this->b0->setBitrateFlag(false);
				 }

				 //Check to see if there was a user requested change
				 if(this->b0->getCANModeFlag() == true)
				 {
					 transmitCANModeChange(b0->getCANMode());
					 this->b0->setCANModeFlag(false);
				 }

				 //Check to see if there was a user requested change
				 if(this->b0->getTerminationDataFlag() == true)
				 {
					 transmitTerminationChange(b0->getTermination());
					 this->b0->setTerminationFlag(false);
				 }
			 } // Checked for attached state
		 }



private: System::Void processFastUserRequest_Tick(System::Object^  sender, System::EventArgs^  e) {
			 unsigned int tempData[dSPI_CAN_PACKET_SIZE];

			 //Quick check to see if tool is attached
			 if(AttachedState == TRUE)
			 {
				 if(this->t0->isThereCANData() == true)
				 {

					 //Now check to see if we could even transmit this across on the USB...
					 for(unsigned char i = 0; i < dSPI_CAN_PACKET_SIZE; i++)
					 {
						 tempData[i] = t0->getBuffer(i);
					 }
					 t0->setCANDataFlag(false);

					 processTransmitMessages(tempData);
				 }
			 } // Checked for attached state
		 }




private: System::Void group1ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
//Do nothing for now
		 }

private: System::Void saveToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 }





private: System::Void openToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
//String^ fileName;
//			 //Open Windows file manager to browse for the INI file
//			 this->openFileDialog1->Title = "Open File";
//			 fileName = "config.inc";
//			 this->openFileDialog1->InitialDirectory= fileName;
//			 this->openFileDialog1->FileName = fileName;
//			 this->openFileDialog1->ShowDialog();
		 }


private: System::Void openFileDialog1_FileOk(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
//			 System::IO::Stream^ ioStream;
//			 if ( (myStream = openFileDialog1->OpenFile()) != nullptr )
//			 {
//			 //Open File
//			 ioStream = OpenFileDialog1.OpenFile();
//			 fileName = OpenFileDialog1.FileName.ToString();
//
/////////////////////////////////////////////////////////////////////////////////
//        ' Read from the Text file
//        If System.IO.File.Exists(uFILE_NAME) = True Then
//
//
//
//
//
//
//
//			 			 //Hide All open windows...
//			Forms::rollingTraceForm->Hide();
//            Forms::simpleTransmitForm->Hide();
//			Forms::registerViewForm->Hide();
//			Forms::hardwareSetupForm->Hide();
//			Forms::fixedTraceForm->Hide();
//			Forms::toolStatusForm->Hide();
//			Forms::mytestForm->Hide();
//			Forms::logFileSetup->Hide();
//			 
//			 
//			 
//			 
//			 // Insert code to read the stream here.
//            myStream->Close();
//         }
//
//
//
//
//
//            While objReader.Peek <> -1
//                dummyString = objReader.ReadLine()
//
//
//                If dummyString = "<Config File Details>" Then
//                    dummystring2 = objReader.ReadLine()
//                    dummystring2 = objReader.ReadLine()
//                    dummystring2 = objReader.ReadLine()
//                    dummystring2 = objReader.ReadLine()
//                End If
//
//
//                If dummyString = "<Windows that are open>" Then
//                    'f1status = objReader.ReadLine()
//                    f2status = objReader.ReadLine()
//                    f3status = objReader.ReadLine()
//                    f4status = objReader.ReadLine()
//                    f5status = objReader.ReadLine()
//                    f6status = objReader.ReadLine()
//                    f7status = objReader.ReadLine()
//                    f8status = objReader.ReadLine()
//                    f9status = objReader.ReadLine()
//                    f10status = objReader.ReadLine()
//
//                    f13status = objReader.ReadLine()
//                    f14status = objReader.ReadLine()
//                    f15status = objReader.ReadLine()
//                    f17status = objReader.ReadLine()
//                End If
//
//                If dummyString = "<Main Window Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    Me.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    Me.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                    UserSelectedHex = objReader.ReadLine()
//
//                End If
//
//                If dummyString = "<Sub 2 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f2.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f2.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 2 Trigger Settings>" Then
//                    'nothing yet
//                End If
//
//                If dummyString = "<Sub 3 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f3.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f3.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "Group 1 Transmit Settings" Then
//                    tempCounter1 = 0
//                    tempCounter2 = 0
//
//                    While tempCounter2 < NUMBER_OF_GROUP_TRANSMIT_ROWS
//                        tempCounter1 = 0
//                        While tempCounter1 < NUMBER_OF_GROUP_TRANSMIT_COLS - 1
//                            f3.DataGridView1.Rows(tempCounter2).Cells(tempCounter1).Value() = objReader.ReadLine()
//                            tempCounter1 = tempCounter1 + 1
//                        End While
//                        tempCounter2 = tempCounter2 + 1
//                    End While
//
//                End If
//
//                If dummyString = "Group 2 Transmit Settings" Then
//                    tempCounter1 = 0
//                    tempCounter2 = 0
//
//                    While tempCounter2 < NUMBER_OF_GROUP_TRANSMIT_ROWS
//                        tempCounter1 = 0
//                        While tempCounter1 < NUMBER_OF_GROUP_TRANSMIT_COLS - 1
//                            f14.DataGridView1.Rows(tempCounter2).Cells(tempCounter1).Value() = objReader.ReadLine()
//                            tempCounter1 = tempCounter1 + 1
//                        End While
//                        tempCounter2 = tempCounter2 + 1
//                    End While
//
//                End If
//
//                If dummyString = "Group 3 Transmit Settings" Then
//                    tempCounter1 = 0
//                    tempCounter2 = 0
//
//                    While tempCounter2 < NUMBER_OF_GROUP_TRANSMIT_ROWS
//                        tempCounter1 = 0
//                        While tempCounter1 < NUMBER_OF_GROUP_TRANSMIT_COLS - 1
//                            f15.DataGridView1.Rows(tempCounter2).Cells(tempCounter1).Value() = objReader.ReadLine()
//                            tempCounter1 = tempCounter1 + 1
//                        End While
//                        tempCounter2 = tempCounter2 + 1
//                    End While
//
//                End If
//
//
//                If dummyString = "<Sub 4 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f4.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f4.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 4 BitRate Selection>" Then
//                    f4.ComboBox2.SelectedItem = objReader.ReadLine()
//                    'Try to set the bitrate
//                    f4.requestBitrateSet()
//                End If
//
//                If dummyString = "<Sub 4 Error Message Selection>" Then
//                    'Set error messages
//                    f4.Button13.Text = objReader.ReadLine()
//                    f4.Label1.Text = objReader.ReadLine()
//                    f4.requestErrorMessageONorOFF()
//                End If
//
//                If dummyString = "<Sub 4 Termination Selection>" Then
//                    'Might need to delay a little bit here (Almost a Back to back USB message)
//                    f4.Button9.Text = objReader.ReadLine()
//                    dummyString = objReader.ReadLine()
//
//                    If dummyString = "Bus Termination Status: OFF" Then
//                        ToggleTermination(0)
//                    Else
//                        ToggleTermination(1)
//                    End If
//                End If
//
//                If dummyString = "<Sub 5 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f5.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f5.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 6 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f6.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f6.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "Log File Settings" Then
//                    AllowDataLogging = Convert.ToInt32(objReader.ReadLine())
//                    If AllowDataLogging = 1 Then
//                        f6.CheckBox1.Checked = True
//                        ToolStripStatusLabel5.Text = "Logging Active"
//                        ToolStripStatusLabel5.BackColor = Color.Green
//                    End If
//
//                    If AllowDataLogging = 0 Then
//                        f6.CheckBox1.Checked = False
//                        ToolStripStatusLabel5.Text = "Logging Inactive"
//                        ToolStripStatusLabel5.BackColor = System.Drawing.SystemColors.Control
//                    End If
//
//                    UserEnteredLogFileIDInclude = Convert.ToBoolean(objReader.ReadLine())
//                    'Read include or exclude selection
//
//                    f6.RadioButton1.Checked = False
//                    f6.RadioButton2.Checked = False
//                    If UserEnteredLogFileIDInclude = True Then
//                        f6.RadioButton1.Checked = True
//                    Else
//                        f6.RadioButton2.Checked = True
//                    End If
//
//                    UserEnteredTotalNumberOfID = Convert.ToInt32(objReader.ReadLine())
//
//                    lFILE_NAME = objReader.ReadLine()
//                    f6.TextBox1.Text = lFILE_NAME
//
//                    f6.ListView1.Items.Clear()
//                    If UserEnteredTotalNumberOfID > 0 Then
//                        tempCounter2 = UserEnteredTotalNumberOfID
//
//                        tempCounter1 = 0
//                        While tempCounter1 < tempCounter2
//                            Dim tempListViewItem As System.Windows.Forms.ListViewItem = New ListViewItem()
//
//                            UserEnteredLogFileID(tempCounter1).CANID_String_Dec = objReader.ReadLine()
//                            tempListViewItem.Text = UserEnteredLogFileID(tempCounter1).CANID_String_Dec
//
//                            UserEnteredLogFileID(tempCounter1).CANID_String_Hex = objReader.ReadLine()
//                            tempListViewItem.SubItems.Add(UserEnteredLogFileID(tempCounter1).CANID_String_Hex)
//
//                            f6.ListView1.Items.Add(tempListViewItem)
//
//                            tempCounter1 = tempCounter1 + 1
//                        End While
//                    End If
//                End If
//
//
//
//
//
//
//
//                If dummyString = "<Sub 7 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f7.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f7.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 8 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f8.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f8.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "Trace Filter Settings" Then
//                    AllowTraceFilter = Convert.ToInt32(objReader.ReadLine())
//                    If AllowTraceFilter = 1 Then
//                        f8.CheckBox1.Checked = True
//                        ToolStripStatusLabel6.Text = "Trace Filter Active"
//                        ToolStripStatusLabel6.BackColor = Color.Green
//                    End If
//
//                    If AllowTraceFilter = 0 Then
//                        f8.CheckBox1.Checked = False
//                        ToolStripStatusLabel6.Text = "Trace Filter Inactive"
//                        ToolStripStatusLabel6.BackColor = System.Drawing.SystemColors.Control
//                    End If
//
//                    UserEnteredTraceFilterIDInclude = Convert.ToBoolean(objReader.ReadLine())
//                    'Read include or exclude selection
//
//                    f8.RadioButton3.Checked = False
//                    f8.RadioButton4.Checked = False
//                    If UserEnteredTraceFilterIDInclude = True Then
//                        f8.RadioButton3.Checked = True
//                    Else
//                        f8.RadioButton4.Checked = True
//                    End If
//
//                    UserEnteredTotalNumberOfIDTraceFilter = Convert.ToInt32(objReader.ReadLine())
//
//                    IsTraceSameAsLog = Convert.ToBoolean(objReader.ReadLine())
//
//                    If IsTraceSameAsLog = True Then
//                        f8.CheckBox2.Checked = True
//                    Else
//                        f8.CheckBox2.Checked = False
//                    End If
//
//                    f8.ListView1.Items.Clear()
//                    If UserEnteredTotalNumberOfIDTraceFilter > 0 Then
//                        tempCounter2 = UserEnteredTotalNumberOfIDTraceFilter
//
//                        tempCounter1 = 0
//                        While tempCounter1 < tempCounter2
//                            Dim tempListViewItem As System.Windows.Forms.ListViewItem = New ListViewItem()
//
//                            UserEnteredTraceFilterID(tempCounter1).CANID_String_Dec = objReader.ReadLine()
//                            tempListViewItem.Text = UserEnteredTraceFilterID(tempCounter1).CANID_String_Dec
//
//                            UserEnteredTraceFilterID(tempCounter1).CANID_String_Hex = objReader.ReadLine()
//                            tempListViewItem.SubItems.Add(UserEnteredTraceFilterID(tempCounter1).CANID_String_Hex)
//
//                            f8.ListView1.Items.Add(tempListViewItem)
//
//                            tempCounter1 = tempCounter1 + 1
//                        End While
//                    End If
//                End If
//
//                If dummyString = "<Sub 9 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f9.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f9.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//
//
//
//                    f9.DataGridView1.Rows.Clear()
//                    'Populate the rows in the transmit window
//                    f9.DataGridView1.Rows.Add(NUMBER_OF_TRANSMIT_ROWS)
//
//                    'tempCounter1 = 0
//                    'While tempCounter1 < NUMBER_OF_TRANSMIT_COLS
//                    '    tempCounter2 = 0
//                    '    While tempCounter2 < NUMBER_OF_TRANSMIT_ROWS
//                    '        f9.DataGridView1.Item(tempCounter1, tempCounter2).Value = objReader.ReadLine()
//                    '        tempCounter2 = tempCounter2 + 1
//                    '    End While
//                    '    tempCounter1 = tempCounter1 + 1
//                    'End While
//
//
//                    tempCounter2 = 0
//                    While tempCounter2 < NUMBER_OF_TRANSMIT_ROWS
//                        tempCounter1 = 0
//                        While tempCounter1 < NUMBER_OF_TRANSMIT_COLS
//                            f9.DataGridView1.Rows(tempCounter2).Cells(tempCounter1).Value() = objReader.ReadLine()
//                            tempCounter1 = tempCounter1 + 1
//                        End While
//                        tempCounter2 = tempCounter2 + 1
//                    End While
//
//
//                    tempCounter = 0
//                    While tempCounter < NUMBER_OF_TRANSMIT_ROWS
//                        f9.DataGridView1.Item(BUTTON_COL_INDEX, tempCounter).Value = "Send"
//                        tempCounter = tempCounter + 1
//                    End While
//
//                End If
//
//                If dummyString = "<Sub 10 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f10.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f10.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 13 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f13.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f13.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 14 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f14.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f14.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 15 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f15.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f15.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//                If dummyString = "<Sub 17 Location>" Then
//                    myNewPointX = Convert.ToInt32(objReader.ReadLine())
//                    myNewPointY = Convert.ToInt32(objReader.ReadLine())
//                    f17.Location = New System.Drawing.Point(myNewPointX, myNewPointY)
//                    myNewSizeW = Convert.ToInt32(objReader.ReadLine())
//                    myNewSizeH = Convert.ToInt32(objReader.ReadLine())
//                    f17.Size = New System.Drawing.Size(myNewSizeW, myNewSizeH)
//                End If
//
//            End While
//
//
//            If f2status = 1 Then
//                f2.Show()
//            End If
//            If f3status = 1 Then
//                f3.Show()
//            End If
//            If f4status = 1 Then
//                f4.Show()
//            End If
//            If f5status = 1 Then
//                f5.Show()
//            End If
//            If f6status = 1 Then
//                f6.Show()
//            End If
//            If f7status = 1 Then
//                f7.Show()
//            End If
//            If f8status = 1 Then
//                f8.Show()
//            End If
//            If f9status = 1 Then
//                f9.Show()
//            End If
//            If f10status = 1 Then
//                f10.Show()
//            End If
//            'If f11status = 1 Then
//            '    f11.Show()
//            'End If
//            'If f12status = 1 Then
//            '    f12.Show()
//            'End If
//            If f14status = 1 Then
//                f14.Show()
//            End If
//            If f15status = 1 Then
//                f15.Show()
//            End If
//            If f17status = 1 Then
//                f17.Show()
//            End If
//        End If
//        objReader.Close()
//        strm.Close()
/////////////////////////////////////////////////////////////////////////////////
//
//			 //Load Window positions and values

		 }
};
}