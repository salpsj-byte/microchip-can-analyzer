
public ref class Forms {
public:
static rollingTrace ^rollingTraceForm;
static simpleTransmit ^simpleTransmitForm;
static registerView ^registerViewForm;
static hardwareSetup ^hardwareSetupForm;
static fixedTrace ^fixedTraceForm;
static toolStatus ^toolStatusForm;
static logFileSetup ^logFileSetup;
static testForm ^mytestForm;
};


//



public ref class Data {

public:
//static Queue^ myQ = gcnew Queue();
//static Queue mySyncQ = Queue::Synchronized(myQ);
static FileStream^ logFileStream;
static BinaryWriter^ logFileBinWriter;
static StreamWriter^ logFileStreamWriter;
};



public ref class Threads {
public:
static Semaphore^ mySemaphore;
};

