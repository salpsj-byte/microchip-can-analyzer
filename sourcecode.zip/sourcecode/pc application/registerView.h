#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace SimpleWinUSBDemo {

	/// <summary>
	/// Summary for registerView
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class registerView : public System::Windows::Forms::Form
	{
	public:
		registerView(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~registerView()
		{
			if (components)
			{
				delete components;
			}
		}

	protected:
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::GroupBox^  groupBox5;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::Label^  label24;
	private: System::Windows::Forms::Label^  label23;
	private: System::Windows::Forms::Label^  label22;
	private: System::Windows::Forms::Label^  label21;
	private: System::Windows::Forms::Label^  label20;
	private: System::Windows::Forms::Label^  label19;
	private: System::Windows::Forms::Label^  label18;
	private: System::Windows::Forms::Label^  label17;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label28;
	private: System::Windows::Forms::Label^  label27;
	private: System::Windows::Forms::Label^  label26;
	private: System::Windows::Forms::Label^  label25;
	private: System::Windows::Forms::TextBox^  textBox11;
	private: System::Windows::Forms::TextBox^  textBox10;
	private: System::Windows::Forms::TextBox^  textBox9;
	private: System::Windows::Forms::TextBox^  textBox8;
	private: System::Windows::Forms::TextBox^  textBox7;
	private: System::Windows::Forms::TextBox^  textBox6;
	private: System::Windows::Forms::TextBox^  textBox5;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::TextBox^  textBox19;
	private: System::Windows::Forms::TextBox^  textBox18;
	private: System::Windows::Forms::TextBox^  textBox17;
	private: System::Windows::Forms::TextBox^  textBox16;
	private: System::Windows::Forms::TextBox^  textBox15;
	private: System::Windows::Forms::TextBox^  textBox14;
	private: System::Windows::Forms::TextBox^  textBox13;
	private: System::Windows::Forms::TextBox^  textBox12;
	private: System::Windows::Forms::TextBox^  textBox20;
	private: System::Windows::Forms::TextBox^  textBox28;
	private: System::Windows::Forms::TextBox^  textBox27;
	private: System::Windows::Forms::TextBox^  textBox26;
	private: System::Windows::Forms::TextBox^  textBox25;
	private: System::Windows::Forms::TextBox^  textBox24;
	private: System::Windows::Forms::TextBox^  textBox23;
	private: System::Windows::Forms::TextBox^  textBox22;
	private: System::Windows::Forms::TextBox^  textBox21;
	private: System::Windows::Forms::TextBox^  textBox39;
	private: System::Windows::Forms::TextBox^  textBox38;
	private: System::Windows::Forms::TextBox^  textBox37;
	private: System::Windows::Forms::TextBox^  textBox36;
	private: System::Windows::Forms::TextBox^  textBox35;
	private: System::Windows::Forms::TextBox^  textBox34;
	private: System::Windows::Forms::TextBox^  textBox33;
	private: System::Windows::Forms::TextBox^  textBox32;
	private: System::Windows::Forms::TextBox^  textBox31;
	private: System::Windows::Forms::TextBox^  textBox30;
	private: System::Windows::Forms::TextBox^  textBox29;
	private: System::Windows::Forms::Label^  label36;
	private: System::Windows::Forms::Label^  label35;
	private: System::Windows::Forms::Label^  label34;
	private: System::Windows::Forms::Label^  label33;
	private: System::Windows::Forms::Label^  label32;
	private: System::Windows::Forms::Label^  label31;
	private: System::Windows::Forms::Label^  label30;
	private: System::Windows::Forms::Label^  label29;
	private: System::Windows::Forms::TextBox^  textBox42;
	private: System::Windows::Forms::TextBox^  textBox41;
	private: System::Windows::Forms::TextBox^  textBox40;
private: System::Windows::Forms::Label^  label42;
private: System::Windows::Forms::Label^  label41;
private: System::Windows::Forms::Label^  label40;
private: System::Windows::Forms::Label^  label39;
private: System::Windows::Forms::Label^  label38;
private: System::Windows::Forms::Label^  label37;
private: System::Windows::Forms::TextBox^  textBox55;
private: System::Windows::Forms::TextBox^  textBox54;
private: System::Windows::Forms::TextBox^  textBox53;
private: System::Windows::Forms::TextBox^  textBox52;
private: System::Windows::Forms::TextBox^  textBox51;
private: System::Windows::Forms::TextBox^  textBox50;
private: System::Windows::Forms::TextBox^  textBox49;
private: System::Windows::Forms::TextBox^  textBox48;
private: System::Windows::Forms::TextBox^  textBox47;
private: System::Windows::Forms::TextBox^  textBox46;
private: System::Windows::Forms::TextBox^  textBox45;
private: System::Windows::Forms::TextBox^  textBox44;
private: System::Windows::Forms::TextBox^  textBox43;
private: System::Windows::Forms::Label^  label55;
private: System::Windows::Forms::Label^  label54;
private: System::Windows::Forms::Label^  label53;
private: System::Windows::Forms::Label^  label52;
private: System::Windows::Forms::Label^  label51;
private: System::Windows::Forms::Label^  label50;
private: System::Windows::Forms::Label^  label49;
private: System::Windows::Forms::Label^  label48;
private: System::Windows::Forms::Label^  label47;
private: System::Windows::Forms::Label^  label46;
private: System::Windows::Forms::Label^  label45;
private: System::Windows::Forms::Label^  label44;
private: System::Windows::Forms::Label^  label43;
private: System::Windows::Forms::TextBox^  textBox68;
private: System::Windows::Forms::TextBox^  textBox67;
private: System::Windows::Forms::TextBox^  textBox66;
private: System::Windows::Forms::TextBox^  textBox65;
private: System::Windows::Forms::TextBox^  textBox64;
private: System::Windows::Forms::TextBox^  textBox63;
private: System::Windows::Forms::TextBox^  textBox62;
private: System::Windows::Forms::TextBox^  textBox61;
private: System::Windows::Forms::TextBox^  textBox60;
private: System::Windows::Forms::TextBox^  textBox59;
private: System::Windows::Forms::TextBox^  textBox58;
private: System::Windows::Forms::TextBox^  textBox57;
private: System::Windows::Forms::Label^  label57;
private: System::Windows::Forms::Label^  label56;
private: System::Windows::Forms::TextBox^  textBox56;
private: System::Windows::Forms::Label^  label70;
private: System::Windows::Forms::Label^  label69;
private: System::Windows::Forms::Label^  label68;
private: System::Windows::Forms::Label^  label67;
private: System::Windows::Forms::Label^  label66;
private: System::Windows::Forms::Label^  label65;
private: System::Windows::Forms::Label^  label64;
private: System::Windows::Forms::Label^  label63;
private: System::Windows::Forms::Label^  label62;
private: System::Windows::Forms::Label^  label61;
private: System::Windows::Forms::Label^  label60;
private: System::Windows::Forms::Label^  label59;
private: System::Windows::Forms::Label^  label58;
private: System::Windows::Forms::TextBox^  textBox70;
private: System::Windows::Forms::TextBox^  textBox69;
private: System::Windows::Forms::TextBox^  textBox80;
private: System::Windows::Forms::TextBox^  textBox79;
private: System::Windows::Forms::TextBox^  textBox78;
private: System::Windows::Forms::TextBox^  textBox77;
private: System::Windows::Forms::TextBox^  textBox76;
private: System::Windows::Forms::TextBox^  textBox75;
private: System::Windows::Forms::TextBox^  textBox74;
private: System::Windows::Forms::TextBox^  textBox73;
private: System::Windows::Forms::TextBox^  textBox72;
private: System::Windows::Forms::Label^  label77;
private: System::Windows::Forms::Label^  label76;
private: System::Windows::Forms::Label^  label75;
private: System::Windows::Forms::Label^  label74;
private: System::Windows::Forms::Label^  label73;
private: System::Windows::Forms::Label^  label72;
private: System::Windows::Forms::Label^  label71;
private: System::Windows::Forms::TextBox^  textBox71;
private: System::Windows::Forms::Label^  label84;
private: System::Windows::Forms::Label^  label83;
private: System::Windows::Forms::Label^  label82;
private: System::Windows::Forms::Label^  label81;
private: System::Windows::Forms::Label^  label80;
private: System::Windows::Forms::Label^  label79;
private: System::Windows::Forms::Label^  label78;
private: System::Windows::Forms::TextBox^  textBox84;
private: System::Windows::Forms::TextBox^  textBox83;
private: System::Windows::Forms::TextBox^  textBox82;
private: System::Windows::Forms::TextBox^  textBox81;
private: System::Windows::Forms::TextBox^  textBox85;
private: System::Windows::Forms::Button^  button1;
private: System::Windows::Forms::Button^  button2;
private: System::Windows::Forms::Button^  button3;

private: System::Windows::Forms::Label^  label94;
private: System::Windows::Forms::Label^  label93;
private: System::Windows::Forms::Label^  label92;
private: System::Windows::Forms::Label^  label91;
private: System::Windows::Forms::Label^  label90;
private: System::Windows::Forms::Label^  label89;
private: System::Windows::Forms::Label^  label88;
private: System::Windows::Forms::Label^  label87;
private: System::Windows::Forms::Label^  label86;
private: System::Windows::Forms::Label^  label85;
private: System::Windows::Forms::TextBox^  textBox95;
private: System::Windows::Forms::TextBox^  textBox94;
private: System::Windows::Forms::TextBox^  textBox93;
private: System::Windows::Forms::TextBox^  textBox92;
private: System::Windows::Forms::TextBox^  textBox91;
private: System::Windows::Forms::TextBox^  textBox90;
private: System::Windows::Forms::TextBox^  textBox89;
private: System::Windows::Forms::TextBox^  textBox88;
private: System::Windows::Forms::TextBox^  textBox87;
private: System::Windows::Forms::TextBox^  textBox86;
private: System::Windows::Forms::Label^  label95;
private: System::Windows::Forms::TextBox^  textBox118;
private: System::Windows::Forms::TextBox^  textBox117;
private: System::Windows::Forms::TextBox^  textBox116;
private: System::Windows::Forms::TextBox^  textBox115;
private: System::Windows::Forms::TextBox^  textBox114;
private: System::Windows::Forms::TextBox^  textBox113;
private: System::Windows::Forms::TextBox^  textBox112;
private: System::Windows::Forms::TextBox^  textBox111;
private: System::Windows::Forms::TextBox^  textBox110;
private: System::Windows::Forms::TextBox^  textBox109;
private: System::Windows::Forms::TextBox^  textBox108;
private: System::Windows::Forms::TextBox^  textBox107;
private: System::Windows::Forms::TextBox^  textBox106;
private: System::Windows::Forms::TextBox^  textBox105;
private: System::Windows::Forms::TextBox^  textBox104;
private: System::Windows::Forms::TextBox^  textBox103;
private: System::Windows::Forms::TextBox^  textBox102;
private: System::Windows::Forms::TextBox^  textBox101;
private: System::Windows::Forms::TextBox^  textBox100;
private: System::Windows::Forms::TextBox^  textBox99;
private: System::Windows::Forms::TextBox^  textBox98;
private: System::Windows::Forms::TextBox^  textBox97;
private: System::Windows::Forms::TextBox^  textBox96;
private: System::Windows::Forms::Label^  label116;
private: System::Windows::Forms::Label^  label115;
private: System::Windows::Forms::Label^  label114;
private: System::Windows::Forms::Label^  label113;
private: System::Windows::Forms::Label^  label112;
private: System::Windows::Forms::Label^  label111;
private: System::Windows::Forms::Label^  label110;
private: System::Windows::Forms::Label^  label109;
private: System::Windows::Forms::Label^  label108;
private: System::Windows::Forms::Label^  label107;
private: System::Windows::Forms::Label^  label106;
private: System::Windows::Forms::Label^  label105;
private: System::Windows::Forms::Label^  label104;
private: System::Windows::Forms::Label^  label103;
private: System::Windows::Forms::Label^  label102;
private: System::Windows::Forms::Label^  label101;
private: System::Windows::Forms::Label^  label100;
private: System::Windows::Forms::Label^  label99;
private: System::Windows::Forms::Label^  label98;
private: System::Windows::Forms::Label^  label97;
private: System::Windows::Forms::Label^  label96;
private: System::Windows::Forms::Label^  label118;
private: System::Windows::Forms::Label^  label117;

	protected: 








	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox28 = (gcnew System::Windows::Forms::TextBox());
			this->textBox27 = (gcnew System::Windows::Forms::TextBox());
			this->textBox26 = (gcnew System::Windows::Forms::TextBox());
			this->textBox25 = (gcnew System::Windows::Forms::TextBox());
			this->textBox24 = (gcnew System::Windows::Forms::TextBox());
			this->textBox23 = (gcnew System::Windows::Forms::TextBox());
			this->textBox22 = (gcnew System::Windows::Forms::TextBox());
			this->textBox21 = (gcnew System::Windows::Forms::TextBox());
			this->textBox20 = (gcnew System::Windows::Forms::TextBox());
			this->textBox19 = (gcnew System::Windows::Forms::TextBox());
			this->textBox18 = (gcnew System::Windows::Forms::TextBox());
			this->textBox17 = (gcnew System::Windows::Forms::TextBox());
			this->textBox16 = (gcnew System::Windows::Forms::TextBox());
			this->textBox15 = (gcnew System::Windows::Forms::TextBox());
			this->textBox14 = (gcnew System::Windows::Forms::TextBox());
			this->textBox13 = (gcnew System::Windows::Forms::TextBox());
			this->textBox12 = (gcnew System::Windows::Forms::TextBox());
			this->textBox11 = (gcnew System::Windows::Forms::TextBox());
			this->textBox10 = (gcnew System::Windows::Forms::TextBox());
			this->textBox9 = (gcnew System::Windows::Forms::TextBox());
			this->textBox8 = (gcnew System::Windows::Forms::TextBox());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label70 = (gcnew System::Windows::Forms::Label());
			this->label69 = (gcnew System::Windows::Forms::Label());
			this->label68 = (gcnew System::Windows::Forms::Label());
			this->label67 = (gcnew System::Windows::Forms::Label());
			this->label66 = (gcnew System::Windows::Forms::Label());
			this->label65 = (gcnew System::Windows::Forms::Label());
			this->label64 = (gcnew System::Windows::Forms::Label());
			this->label63 = (gcnew System::Windows::Forms::Label());
			this->label62 = (gcnew System::Windows::Forms::Label());
			this->label61 = (gcnew System::Windows::Forms::Label());
			this->label60 = (gcnew System::Windows::Forms::Label());
			this->label59 = (gcnew System::Windows::Forms::Label());
			this->label58 = (gcnew System::Windows::Forms::Label());
			this->textBox70 = (gcnew System::Windows::Forms::TextBox());
			this->textBox69 = (gcnew System::Windows::Forms::TextBox());
			this->textBox68 = (gcnew System::Windows::Forms::TextBox());
			this->textBox67 = (gcnew System::Windows::Forms::TextBox());
			this->textBox66 = (gcnew System::Windows::Forms::TextBox());
			this->textBox65 = (gcnew System::Windows::Forms::TextBox());
			this->textBox64 = (gcnew System::Windows::Forms::TextBox());
			this->textBox63 = (gcnew System::Windows::Forms::TextBox());
			this->textBox62 = (gcnew System::Windows::Forms::TextBox());
			this->textBox61 = (gcnew System::Windows::Forms::TextBox());
			this->textBox60 = (gcnew System::Windows::Forms::TextBox());
			this->textBox59 = (gcnew System::Windows::Forms::TextBox());
			this->textBox58 = (gcnew System::Windows::Forms::TextBox());
			this->textBox57 = (gcnew System::Windows::Forms::TextBox());
			this->label57 = (gcnew System::Windows::Forms::Label());
			this->label56 = (gcnew System::Windows::Forms::Label());
			this->textBox56 = (gcnew System::Windows::Forms::TextBox());
			this->textBox55 = (gcnew System::Windows::Forms::TextBox());
			this->textBox54 = (gcnew System::Windows::Forms::TextBox());
			this->textBox53 = (gcnew System::Windows::Forms::TextBox());
			this->textBox52 = (gcnew System::Windows::Forms::TextBox());
			this->textBox51 = (gcnew System::Windows::Forms::TextBox());
			this->textBox50 = (gcnew System::Windows::Forms::TextBox());
			this->textBox49 = (gcnew System::Windows::Forms::TextBox());
			this->textBox48 = (gcnew System::Windows::Forms::TextBox());
			this->textBox47 = (gcnew System::Windows::Forms::TextBox());
			this->textBox46 = (gcnew System::Windows::Forms::TextBox());
			this->textBox45 = (gcnew System::Windows::Forms::TextBox());
			this->textBox44 = (gcnew System::Windows::Forms::TextBox());
			this->textBox43 = (gcnew System::Windows::Forms::TextBox());
			this->label55 = (gcnew System::Windows::Forms::Label());
			this->label54 = (gcnew System::Windows::Forms::Label());
			this->label53 = (gcnew System::Windows::Forms::Label());
			this->label52 = (gcnew System::Windows::Forms::Label());
			this->label51 = (gcnew System::Windows::Forms::Label());
			this->label50 = (gcnew System::Windows::Forms::Label());
			this->label49 = (gcnew System::Windows::Forms::Label());
			this->label48 = (gcnew System::Windows::Forms::Label());
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->label43 = (gcnew System::Windows::Forms::Label());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->label39 = (gcnew System::Windows::Forms::Label());
			this->label38 = (gcnew System::Windows::Forms::Label());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->textBox42 = (gcnew System::Windows::Forms::TextBox());
			this->textBox41 = (gcnew System::Windows::Forms::TextBox());
			this->textBox40 = (gcnew System::Windows::Forms::TextBox());
			this->textBox39 = (gcnew System::Windows::Forms::TextBox());
			this->textBox38 = (gcnew System::Windows::Forms::TextBox());
			this->textBox37 = (gcnew System::Windows::Forms::TextBox());
			this->textBox36 = (gcnew System::Windows::Forms::TextBox());
			this->textBox35 = (gcnew System::Windows::Forms::TextBox());
			this->textBox34 = (gcnew System::Windows::Forms::TextBox());
			this->textBox33 = (gcnew System::Windows::Forms::TextBox());
			this->textBox32 = (gcnew System::Windows::Forms::TextBox());
			this->textBox31 = (gcnew System::Windows::Forms::TextBox());
			this->textBox30 = (gcnew System::Windows::Forms::TextBox());
			this->textBox29 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->label84 = (gcnew System::Windows::Forms::Label());
			this->label83 = (gcnew System::Windows::Forms::Label());
			this->label82 = (gcnew System::Windows::Forms::Label());
			this->label81 = (gcnew System::Windows::Forms::Label());
			this->label80 = (gcnew System::Windows::Forms::Label());
			this->label79 = (gcnew System::Windows::Forms::Label());
			this->label78 = (gcnew System::Windows::Forms::Label());
			this->textBox84 = (gcnew System::Windows::Forms::TextBox());
			this->textBox83 = (gcnew System::Windows::Forms::TextBox());
			this->textBox82 = (gcnew System::Windows::Forms::TextBox());
			this->textBox81 = (gcnew System::Windows::Forms::TextBox());
			this->textBox80 = (gcnew System::Windows::Forms::TextBox());
			this->textBox79 = (gcnew System::Windows::Forms::TextBox());
			this->textBox78 = (gcnew System::Windows::Forms::TextBox());
			this->textBox77 = (gcnew System::Windows::Forms::TextBox());
			this->textBox76 = (gcnew System::Windows::Forms::TextBox());
			this->textBox75 = (gcnew System::Windows::Forms::TextBox());
			this->textBox74 = (gcnew System::Windows::Forms::TextBox());
			this->textBox73 = (gcnew System::Windows::Forms::TextBox());
			this->textBox72 = (gcnew System::Windows::Forms::TextBox());
			this->label77 = (gcnew System::Windows::Forms::Label());
			this->label76 = (gcnew System::Windows::Forms::Label());
			this->label75 = (gcnew System::Windows::Forms::Label());
			this->label74 = (gcnew System::Windows::Forms::Label());
			this->label73 = (gcnew System::Windows::Forms::Label());
			this->label72 = (gcnew System::Windows::Forms::Label());
			this->label71 = (gcnew System::Windows::Forms::Label());
			this->textBox71 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->label94 = (gcnew System::Windows::Forms::Label());
			this->label93 = (gcnew System::Windows::Forms::Label());
			this->label92 = (gcnew System::Windows::Forms::Label());
			this->label91 = (gcnew System::Windows::Forms::Label());
			this->label90 = (gcnew System::Windows::Forms::Label());
			this->label89 = (gcnew System::Windows::Forms::Label());
			this->label88 = (gcnew System::Windows::Forms::Label());
			this->label87 = (gcnew System::Windows::Forms::Label());
			this->label86 = (gcnew System::Windows::Forms::Label());
			this->label85 = (gcnew System::Windows::Forms::Label());
			this->textBox94 = (gcnew System::Windows::Forms::TextBox());
			this->textBox93 = (gcnew System::Windows::Forms::TextBox());
			this->textBox92 = (gcnew System::Windows::Forms::TextBox());
			this->textBox91 = (gcnew System::Windows::Forms::TextBox());
			this->textBox90 = (gcnew System::Windows::Forms::TextBox());
			this->textBox89 = (gcnew System::Windows::Forms::TextBox());
			this->textBox88 = (gcnew System::Windows::Forms::TextBox());
			this->textBox87 = (gcnew System::Windows::Forms::TextBox());
			this->textBox86 = (gcnew System::Windows::Forms::TextBox());
			this->textBox85 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox5 = (gcnew System::Windows::Forms::GroupBox());
			this->label118 = (gcnew System::Windows::Forms::Label());
			this->label117 = (gcnew System::Windows::Forms::Label());
			this->label116 = (gcnew System::Windows::Forms::Label());
			this->label115 = (gcnew System::Windows::Forms::Label());
			this->label114 = (gcnew System::Windows::Forms::Label());
			this->label113 = (gcnew System::Windows::Forms::Label());
			this->label112 = (gcnew System::Windows::Forms::Label());
			this->label111 = (gcnew System::Windows::Forms::Label());
			this->label110 = (gcnew System::Windows::Forms::Label());
			this->label109 = (gcnew System::Windows::Forms::Label());
			this->label108 = (gcnew System::Windows::Forms::Label());
			this->label107 = (gcnew System::Windows::Forms::Label());
			this->label106 = (gcnew System::Windows::Forms::Label());
			this->label105 = (gcnew System::Windows::Forms::Label());
			this->label104 = (gcnew System::Windows::Forms::Label());
			this->label103 = (gcnew System::Windows::Forms::Label());
			this->label102 = (gcnew System::Windows::Forms::Label());
			this->label101 = (gcnew System::Windows::Forms::Label());
			this->label100 = (gcnew System::Windows::Forms::Label());
			this->label99 = (gcnew System::Windows::Forms::Label());
			this->label98 = (gcnew System::Windows::Forms::Label());
			this->label97 = (gcnew System::Windows::Forms::Label());
			this->label96 = (gcnew System::Windows::Forms::Label());
			this->label95 = (gcnew System::Windows::Forms::Label());
			this->textBox118 = (gcnew System::Windows::Forms::TextBox());
			this->textBox117 = (gcnew System::Windows::Forms::TextBox());
			this->textBox116 = (gcnew System::Windows::Forms::TextBox());
			this->textBox115 = (gcnew System::Windows::Forms::TextBox());
			this->textBox114 = (gcnew System::Windows::Forms::TextBox());
			this->textBox113 = (gcnew System::Windows::Forms::TextBox());
			this->textBox112 = (gcnew System::Windows::Forms::TextBox());
			this->textBox111 = (gcnew System::Windows::Forms::TextBox());
			this->textBox110 = (gcnew System::Windows::Forms::TextBox());
			this->textBox109 = (gcnew System::Windows::Forms::TextBox());
			this->textBox108 = (gcnew System::Windows::Forms::TextBox());
			this->textBox107 = (gcnew System::Windows::Forms::TextBox());
			this->textBox106 = (gcnew System::Windows::Forms::TextBox());
			this->textBox105 = (gcnew System::Windows::Forms::TextBox());
			this->textBox104 = (gcnew System::Windows::Forms::TextBox());
			this->textBox103 = (gcnew System::Windows::Forms::TextBox());
			this->textBox102 = (gcnew System::Windows::Forms::TextBox());
			this->textBox101 = (gcnew System::Windows::Forms::TextBox());
			this->textBox100 = (gcnew System::Windows::Forms::TextBox());
			this->textBox99 = (gcnew System::Windows::Forms::TextBox());
			this->textBox98 = (gcnew System::Windows::Forms::TextBox());
			this->textBox97 = (gcnew System::Windows::Forms::TextBox());
			this->textBox96 = (gcnew System::Windows::Forms::TextBox());
			this->textBox95 = (gcnew System::Windows::Forms::TextBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->textBox28);
			this->groupBox1->Controls->Add(this->textBox27);
			this->groupBox1->Controls->Add(this->textBox26);
			this->groupBox1->Controls->Add(this->textBox25);
			this->groupBox1->Controls->Add(this->textBox24);
			this->groupBox1->Controls->Add(this->textBox23);
			this->groupBox1->Controls->Add(this->textBox22);
			this->groupBox1->Controls->Add(this->textBox21);
			this->groupBox1->Controls->Add(this->textBox20);
			this->groupBox1->Controls->Add(this->textBox19);
			this->groupBox1->Controls->Add(this->textBox18);
			this->groupBox1->Controls->Add(this->textBox17);
			this->groupBox1->Controls->Add(this->textBox16);
			this->groupBox1->Controls->Add(this->textBox15);
			this->groupBox1->Controls->Add(this->textBox14);
			this->groupBox1->Controls->Add(this->textBox13);
			this->groupBox1->Controls->Add(this->textBox12);
			this->groupBox1->Controls->Add(this->textBox11);
			this->groupBox1->Controls->Add(this->textBox10);
			this->groupBox1->Controls->Add(this->textBox9);
			this->groupBox1->Controls->Add(this->textBox8);
			this->groupBox1->Controls->Add(this->textBox7);
			this->groupBox1->Controls->Add(this->textBox6);
			this->groupBox1->Controls->Add(this->textBox5);
			this->groupBox1->Controls->Add(this->textBox4);
			this->groupBox1->Controls->Add(this->textBox3);
			this->groupBox1->Controls->Add(this->textBox2);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Controls->Add(this->label28);
			this->groupBox1->Controls->Add(this->label27);
			this->groupBox1->Controls->Add(this->label26);
			this->groupBox1->Controls->Add(this->label25);
			this->groupBox1->Controls->Add(this->label24);
			this->groupBox1->Controls->Add(this->label23);
			this->groupBox1->Controls->Add(this->label22);
			this->groupBox1->Controls->Add(this->label21);
			this->groupBox1->Controls->Add(this->label20);
			this->groupBox1->Controls->Add(this->label19);
			this->groupBox1->Controls->Add(this->label18);
			this->groupBox1->Controls->Add(this->label17);
			this->groupBox1->Controls->Add(this->label16);
			this->groupBox1->Controls->Add(this->label15);
			this->groupBox1->Controls->Add(this->label14);
			this->groupBox1->Controls->Add(this->label13);
			this->groupBox1->Controls->Add(this->label12);
			this->groupBox1->Controls->Add(this->label11);
			this->groupBox1->Controls->Add(this->label10);
			this->groupBox1->Controls->Add(this->label9);
			this->groupBox1->Controls->Add(this->label8);
			this->groupBox1->Controls->Add(this->label7);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Location = System::Drawing::Point(5, 5);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(225, 310);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"RX Buffers";
			// 
			// textBox28
			// 
			this->textBox28->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox28->Location = System::Drawing::Point(182, 285);
			this->textBox28->Name = L"textBox28";
			this->textBox28->ReadOnly = true;
			this->textBox28->Size = System::Drawing::Size(35, 18);
			this->textBox28->TabIndex = 55;
			// 
			// textBox27
			// 
			this->textBox27->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox27->Location = System::Drawing::Point(182, 265);
			this->textBox27->Name = L"textBox27";
			this->textBox27->ReadOnly = true;
			this->textBox27->Size = System::Drawing::Size(35, 18);
			this->textBox27->TabIndex = 54;
			// 
			// textBox26
			// 
			this->textBox26->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox26->Location = System::Drawing::Point(182, 245);
			this->textBox26->Name = L"textBox26";
			this->textBox26->ReadOnly = true;
			this->textBox26->Size = System::Drawing::Size(35, 18);
			this->textBox26->TabIndex = 53;
			// 
			// textBox25
			// 
			this->textBox25->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox25->Location = System::Drawing::Point(182, 225);
			this->textBox25->Name = L"textBox25";
			this->textBox25->ReadOnly = true;
			this->textBox25->Size = System::Drawing::Size(35, 18);
			this->textBox25->TabIndex = 52;
			// 
			// textBox24
			// 
			this->textBox24->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox24->Location = System::Drawing::Point(182, 205);
			this->textBox24->Name = L"textBox24";
			this->textBox24->ReadOnly = true;
			this->textBox24->Size = System::Drawing::Size(35, 18);
			this->textBox24->TabIndex = 51;
			// 
			// textBox23
			// 
			this->textBox23->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox23->Location = System::Drawing::Point(182, 185);
			this->textBox23->Name = L"textBox23";
			this->textBox23->ReadOnly = true;
			this->textBox23->Size = System::Drawing::Size(35, 18);
			this->textBox23->TabIndex = 50;
			// 
			// textBox22
			// 
			this->textBox22->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox22->Location = System::Drawing::Point(182, 165);
			this->textBox22->Name = L"textBox22";
			this->textBox22->ReadOnly = true;
			this->textBox22->Size = System::Drawing::Size(35, 18);
			this->textBox22->TabIndex = 49;
			// 
			// textBox21
			// 
			this->textBox21->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox21->Location = System::Drawing::Point(182, 145);
			this->textBox21->Name = L"textBox21";
			this->textBox21->ReadOnly = true;
			this->textBox21->Size = System::Drawing::Size(35, 18);
			this->textBox21->TabIndex = 48;
			// 
			// textBox20
			// 
			this->textBox20->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox20->Location = System::Drawing::Point(182, 125);
			this->textBox20->Name = L"textBox20";
			this->textBox20->ReadOnly = true;
			this->textBox20->Size = System::Drawing::Size(35, 18);
			this->textBox20->TabIndex = 47;
			// 
			// textBox19
			// 
			this->textBox19->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox19->Location = System::Drawing::Point(182, 105);
			this->textBox19->Name = L"textBox19";
			this->textBox19->ReadOnly = true;
			this->textBox19->Size = System::Drawing::Size(35, 18);
			this->textBox19->TabIndex = 46;
			// 
			// textBox18
			// 
			this->textBox18->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox18->Location = System::Drawing::Point(182, 85);
			this->textBox18->Name = L"textBox18";
			this->textBox18->ReadOnly = true;
			this->textBox18->Size = System::Drawing::Size(35, 18);
			this->textBox18->TabIndex = 45;
			// 
			// textBox17
			// 
			this->textBox17->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox17->Location = System::Drawing::Point(182, 65);
			this->textBox17->Name = L"textBox17";
			this->textBox17->ReadOnly = true;
			this->textBox17->Size = System::Drawing::Size(35, 18);
			this->textBox17->TabIndex = 44;
			// 
			// textBox16
			// 
			this->textBox16->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox16->Location = System::Drawing::Point(182, 45);
			this->textBox16->Name = L"textBox16";
			this->textBox16->ReadOnly = true;
			this->textBox16->Size = System::Drawing::Size(35, 18);
			this->textBox16->TabIndex = 43;
			// 
			// textBox15
			// 
			this->textBox15->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox15->Location = System::Drawing::Point(182, 25);
			this->textBox15->Name = L"textBox15";
			this->textBox15->ReadOnly = true;
			this->textBox15->Size = System::Drawing::Size(35, 18);
			this->textBox15->TabIndex = 42;
			// 
			// textBox14
			// 
			this->textBox14->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox14->Location = System::Drawing::Point(67, 285);
			this->textBox14->Name = L"textBox14";
			this->textBox14->ReadOnly = true;
			this->textBox14->Size = System::Drawing::Size(35, 18);
			this->textBox14->TabIndex = 41;
			// 
			// textBox13
			// 
			this->textBox13->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox13->Location = System::Drawing::Point(67, 265);
			this->textBox13->Name = L"textBox13";
			this->textBox13->ReadOnly = true;
			this->textBox13->Size = System::Drawing::Size(35, 18);
			this->textBox13->TabIndex = 40;
			// 
			// textBox12
			// 
			this->textBox12->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox12->Location = System::Drawing::Point(67, 245);
			this->textBox12->Name = L"textBox12";
			this->textBox12->ReadOnly = true;
			this->textBox12->Size = System::Drawing::Size(35, 18);
			this->textBox12->TabIndex = 39;
			// 
			// textBox11
			// 
			this->textBox11->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox11->Location = System::Drawing::Point(67, 225);
			this->textBox11->Name = L"textBox11";
			this->textBox11->ReadOnly = true;
			this->textBox11->Size = System::Drawing::Size(35, 18);
			this->textBox11->TabIndex = 38;
			// 
			// textBox10
			// 
			this->textBox10->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox10->Location = System::Drawing::Point(67, 205);
			this->textBox10->Name = L"textBox10";
			this->textBox10->ReadOnly = true;
			this->textBox10->Size = System::Drawing::Size(35, 18);
			this->textBox10->TabIndex = 37;
			// 
			// textBox9
			// 
			this->textBox9->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox9->Location = System::Drawing::Point(67, 185);
			this->textBox9->Name = L"textBox9";
			this->textBox9->ReadOnly = true;
			this->textBox9->Size = System::Drawing::Size(35, 18);
			this->textBox9->TabIndex = 36;
			// 
			// textBox8
			// 
			this->textBox8->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox8->Location = System::Drawing::Point(67, 165);
			this->textBox8->Name = L"textBox8";
			this->textBox8->ReadOnly = true;
			this->textBox8->Size = System::Drawing::Size(35, 18);
			this->textBox8->TabIndex = 35;
			// 
			// textBox7
			// 
			this->textBox7->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox7->Location = System::Drawing::Point(67, 145);
			this->textBox7->Name = L"textBox7";
			this->textBox7->ReadOnly = true;
			this->textBox7->Size = System::Drawing::Size(35, 18);
			this->textBox7->TabIndex = 34;
			// 
			// textBox6
			// 
			this->textBox6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox6->Location = System::Drawing::Point(67, 125);
			this->textBox6->Name = L"textBox6";
			this->textBox6->ReadOnly = true;
			this->textBox6->Size = System::Drawing::Size(35, 18);
			this->textBox6->TabIndex = 33;
			// 
			// textBox5
			// 
			this->textBox5->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox5->Location = System::Drawing::Point(67, 105);
			this->textBox5->Name = L"textBox5";
			this->textBox5->ReadOnly = true;
			this->textBox5->Size = System::Drawing::Size(35, 18);
			this->textBox5->TabIndex = 32;
			// 
			// textBox4
			// 
			this->textBox4->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox4->Location = System::Drawing::Point(67, 85);
			this->textBox4->Name = L"textBox4";
			this->textBox4->ReadOnly = true;
			this->textBox4->Size = System::Drawing::Size(35, 18);
			this->textBox4->TabIndex = 31;
			// 
			// textBox3
			// 
			this->textBox3->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox3->Location = System::Drawing::Point(67, 65);
			this->textBox3->Name = L"textBox3";
			this->textBox3->ReadOnly = true;
			this->textBox3->Size = System::Drawing::Size(35, 18);
			this->textBox3->TabIndex = 30;
			// 
			// textBox2
			// 
			this->textBox2->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox2->Location = System::Drawing::Point(67, 45);
			this->textBox2->Name = L"textBox2";
			this->textBox2->ReadOnly = true;
			this->textBox2->Size = System::Drawing::Size(35, 18);
			this->textBox2->TabIndex = 29;
			// 
			// textBox1
			// 
			this->textBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox1->Location = System::Drawing::Point(67, 25);
			this->textBox1->Name = L"textBox1";
			this->textBox1->ReadOnly = true;
			this->textBox1->Size = System::Drawing::Size(35, 18);
			this->textBox1->TabIndex = 28;
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(120, 287);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(49, 13);
			this->label28->TabIndex = 27;
			this->label28->Text = L"RXB1D7";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(120, 267);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(49, 13);
			this->label27->TabIndex = 26;
			this->label27->Text = L"RXB1D6";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(120, 247);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(49, 13);
			this->label26->TabIndex = 25;
			this->label26->Text = L"RXB1D5";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(120, 227);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(49, 13);
			this->label25->TabIndex = 24;
			this->label25->Text = L"RXB1D4";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(120, 207);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(49, 13);
			this->label24->TabIndex = 23;
			this->label24->Text = L"RXB1D3";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(120, 187);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(49, 13);
			this->label23->TabIndex = 22;
			this->label23->Text = L"RXB1D2";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(120, 167);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(49, 13);
			this->label22->TabIndex = 21;
			this->label22->Text = L"RXB1D1";
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(120, 147);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(49, 13);
			this->label21->TabIndex = 20;
			this->label21->Text = L"RXB1D0";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(120, 127);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(56, 13);
			this->label20->TabIndex = 19;
			this->label20->Text = L"RXB1DLC";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(120, 107);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(59, 13);
			this->label19->TabIndex = 18;
			this->label19->Text = L"RXB1EIDL";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(120, 87);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(61, 13);
			this->label18->TabIndex = 17;
			this->label18->Text = L"RXB1EIDH";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(120, 67);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(59, 13);
			this->label17->TabIndex = 16;
			this->label17->Text = L"RXB1SIDL";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(120, 47);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(61, 13);
			this->label16->TabIndex = 15;
			this->label16->Text = L"RXB1SIDH";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(120, 27);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(58, 13);
			this->label15->TabIndex = 14;
			this->label15->Text = L"RXB1CON";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(5, 287);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(49, 13);
			this->label14->TabIndex = 13;
			this->label14->Text = L"RXB0D7";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(5, 267);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(49, 13);
			this->label13->TabIndex = 12;
			this->label13->Text = L"RXB0D6";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(5, 247);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(49, 13);
			this->label12->TabIndex = 11;
			this->label12->Text = L"RXB0D5";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(5, 227);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(49, 13);
			this->label11->TabIndex = 10;
			this->label11->Text = L"RXB0D4";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(5, 207);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(49, 13);
			this->label10->TabIndex = 9;
			this->label10->Text = L"RXB0D3";
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(5, 187);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(49, 13);
			this->label9->TabIndex = 8;
			this->label9->Text = L"RXB0D2";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(5, 167);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(49, 13);
			this->label8->TabIndex = 7;
			this->label8->Text = L"RXB0D1";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(5, 147);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(49, 13);
			this->label7->TabIndex = 6;
			this->label7->Text = L"RXB0D0";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(5, 127);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(56, 13);
			this->label6->TabIndex = 5;
			this->label6->Text = L"RXB0DLC";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(5, 107);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(59, 13);
			this->label5->TabIndex = 4;
			this->label5->Text = L"RXB0EIDL";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(5, 87);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(61, 13);
			this->label4->TabIndex = 3;
			this->label4->Text = L"RXB0EIDH";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(5, 67);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(59, 13);
			this->label3->TabIndex = 2;
			this->label3->Text = L"RXB0SIDL";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(5, 47);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(61, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"RXB0SIDH";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(5, 27);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(58, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"RXB0CON";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->label70);
			this->groupBox2->Controls->Add(this->label69);
			this->groupBox2->Controls->Add(this->label68);
			this->groupBox2->Controls->Add(this->label67);
			this->groupBox2->Controls->Add(this->label66);
			this->groupBox2->Controls->Add(this->label65);
			this->groupBox2->Controls->Add(this->label64);
			this->groupBox2->Controls->Add(this->label63);
			this->groupBox2->Controls->Add(this->label62);
			this->groupBox2->Controls->Add(this->label61);
			this->groupBox2->Controls->Add(this->label60);
			this->groupBox2->Controls->Add(this->label59);
			this->groupBox2->Controls->Add(this->label58);
			this->groupBox2->Controls->Add(this->textBox70);
			this->groupBox2->Controls->Add(this->textBox69);
			this->groupBox2->Controls->Add(this->textBox68);
			this->groupBox2->Controls->Add(this->textBox67);
			this->groupBox2->Controls->Add(this->textBox66);
			this->groupBox2->Controls->Add(this->textBox65);
			this->groupBox2->Controls->Add(this->textBox64);
			this->groupBox2->Controls->Add(this->textBox63);
			this->groupBox2->Controls->Add(this->textBox62);
			this->groupBox2->Controls->Add(this->textBox61);
			this->groupBox2->Controls->Add(this->textBox60);
			this->groupBox2->Controls->Add(this->textBox59);
			this->groupBox2->Controls->Add(this->textBox58);
			this->groupBox2->Controls->Add(this->textBox57);
			this->groupBox2->Controls->Add(this->label57);
			this->groupBox2->Controls->Add(this->label56);
			this->groupBox2->Controls->Add(this->textBox56);
			this->groupBox2->Controls->Add(this->textBox55);
			this->groupBox2->Controls->Add(this->textBox54);
			this->groupBox2->Controls->Add(this->textBox53);
			this->groupBox2->Controls->Add(this->textBox52);
			this->groupBox2->Controls->Add(this->textBox51);
			this->groupBox2->Controls->Add(this->textBox50);
			this->groupBox2->Controls->Add(this->textBox49);
			this->groupBox2->Controls->Add(this->textBox48);
			this->groupBox2->Controls->Add(this->textBox47);
			this->groupBox2->Controls->Add(this->textBox46);
			this->groupBox2->Controls->Add(this->textBox45);
			this->groupBox2->Controls->Add(this->textBox44);
			this->groupBox2->Controls->Add(this->textBox43);
			this->groupBox2->Controls->Add(this->label55);
			this->groupBox2->Controls->Add(this->label54);
			this->groupBox2->Controls->Add(this->label53);
			this->groupBox2->Controls->Add(this->label52);
			this->groupBox2->Controls->Add(this->label51);
			this->groupBox2->Controls->Add(this->label50);
			this->groupBox2->Controls->Add(this->label49);
			this->groupBox2->Controls->Add(this->label48);
			this->groupBox2->Controls->Add(this->label47);
			this->groupBox2->Controls->Add(this->label46);
			this->groupBox2->Controls->Add(this->label45);
			this->groupBox2->Controls->Add(this->label44);
			this->groupBox2->Controls->Add(this->label43);
			this->groupBox2->Controls->Add(this->label42);
			this->groupBox2->Controls->Add(this->label41);
			this->groupBox2->Controls->Add(this->label40);
			this->groupBox2->Controls->Add(this->label39);
			this->groupBox2->Controls->Add(this->label38);
			this->groupBox2->Controls->Add(this->label37);
			this->groupBox2->Controls->Add(this->label36);
			this->groupBox2->Controls->Add(this->label35);
			this->groupBox2->Controls->Add(this->label34);
			this->groupBox2->Controls->Add(this->label33);
			this->groupBox2->Controls->Add(this->label32);
			this->groupBox2->Controls->Add(this->label31);
			this->groupBox2->Controls->Add(this->label30);
			this->groupBox2->Controls->Add(this->label29);
			this->groupBox2->Controls->Add(this->textBox42);
			this->groupBox2->Controls->Add(this->textBox41);
			this->groupBox2->Controls->Add(this->textBox40);
			this->groupBox2->Controls->Add(this->textBox39);
			this->groupBox2->Controls->Add(this->textBox38);
			this->groupBox2->Controls->Add(this->textBox37);
			this->groupBox2->Controls->Add(this->textBox36);
			this->groupBox2->Controls->Add(this->textBox35);
			this->groupBox2->Controls->Add(this->textBox34);
			this->groupBox2->Controls->Add(this->textBox33);
			this->groupBox2->Controls->Add(this->textBox32);
			this->groupBox2->Controls->Add(this->textBox31);
			this->groupBox2->Controls->Add(this->textBox30);
			this->groupBox2->Controls->Add(this->textBox29);
			this->groupBox2->Location = System::Drawing::Point(236, 5);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(339, 310);
			this->groupBox2->TabIndex = 1;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"TX Buffers";
			// 
			// label70
			// 
			this->label70->AutoSize = true;
			this->label70->Location = System::Drawing::Point(235, 287);
			this->label70->Name = L"label70";
			this->label70->Size = System::Drawing::Size(48, 13);
			this->label70->TabIndex = 112;
			this->label70->Text = L"TXB2D7";
			// 
			// label69
			// 
			this->label69->AutoSize = true;
			this->label69->Location = System::Drawing::Point(235, 267);
			this->label69->Name = L"label69";
			this->label69->Size = System::Drawing::Size(48, 13);
			this->label69->TabIndex = 111;
			this->label69->Text = L"TXB2D6";
			// 
			// label68
			// 
			this->label68->AutoSize = true;
			this->label68->Location = System::Drawing::Point(235, 247);
			this->label68->Name = L"label68";
			this->label68->Size = System::Drawing::Size(48, 13);
			this->label68->TabIndex = 110;
			this->label68->Text = L"TXB2D5";
			// 
			// label67
			// 
			this->label67->AutoSize = true;
			this->label67->Location = System::Drawing::Point(235, 227);
			this->label67->Name = L"label67";
			this->label67->Size = System::Drawing::Size(48, 13);
			this->label67->TabIndex = 109;
			this->label67->Text = L"TXB2D4";
			// 
			// label66
			// 
			this->label66->AutoSize = true;
			this->label66->Location = System::Drawing::Point(235, 207);
			this->label66->Name = L"label66";
			this->label66->Size = System::Drawing::Size(48, 13);
			this->label66->TabIndex = 108;
			this->label66->Text = L"TXB2D3";
			// 
			// label65
			// 
			this->label65->AutoSize = true;
			this->label65->Location = System::Drawing::Point(235, 187);
			this->label65->Name = L"label65";
			this->label65->Size = System::Drawing::Size(48, 13);
			this->label65->TabIndex = 107;
			this->label65->Text = L"TXB2D2";
			// 
			// label64
			// 
			this->label64->AutoSize = true;
			this->label64->Location = System::Drawing::Point(235, 167);
			this->label64->Name = L"label64";
			this->label64->Size = System::Drawing::Size(48, 13);
			this->label64->TabIndex = 106;
			this->label64->Text = L"TXB2D1";
			// 
			// label63
			// 
			this->label63->AutoSize = true;
			this->label63->Location = System::Drawing::Point(235, 147);
			this->label63->Name = L"label63";
			this->label63->Size = System::Drawing::Size(48, 13);
			this->label63->TabIndex = 105;
			this->label63->Text = L"TXB2D0";
			// 
			// label62
			// 
			this->label62->AutoSize = true;
			this->label62->Location = System::Drawing::Point(235, 127);
			this->label62->Name = L"label62";
			this->label62->Size = System::Drawing::Size(55, 13);
			this->label62->TabIndex = 104;
			this->label62->Text = L"TXB2DLC";
			// 
			// label61
			// 
			this->label61->AutoSize = true;
			this->label61->Location = System::Drawing::Point(235, 107);
			this->label61->Name = L"label61";
			this->label61->Size = System::Drawing::Size(58, 13);
			this->label61->TabIndex = 103;
			this->label61->Text = L"TXB2EIDL";
			// 
			// label60
			// 
			this->label60->AutoSize = true;
			this->label60->Location = System::Drawing::Point(235, 87);
			this->label60->Name = L"label60";
			this->label60->Size = System::Drawing::Size(60, 13);
			this->label60->TabIndex = 102;
			this->label60->Text = L"TXB2EIDH";
			// 
			// label59
			// 
			this->label59->AutoSize = true;
			this->label59->Location = System::Drawing::Point(235, 67);
			this->label59->Name = L"label59";
			this->label59->Size = System::Drawing::Size(58, 13);
			this->label59->TabIndex = 101;
			this->label59->Text = L"TXB2SIDL";
			// 
			// label58
			// 
			this->label58->AutoSize = true;
			this->label58->Location = System::Drawing::Point(235, 47);
			this->label58->Name = L"label58";
			this->label58->Size = System::Drawing::Size(60, 13);
			this->label58->TabIndex = 100;
			this->label58->Text = L"TXB2SIDH";
			// 
			// textBox70
			// 
			this->textBox70->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox70->Location = System::Drawing::Point(296, 285);
			this->textBox70->Name = L"textBox70";
			this->textBox70->Size = System::Drawing::Size(35, 18);
			this->textBox70->TabIndex = 99;
			// 
			// textBox69
			// 
			this->textBox69->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox69->Location = System::Drawing::Point(296, 265);
			this->textBox69->Name = L"textBox69";
			this->textBox69->Size = System::Drawing::Size(35, 18);
			this->textBox69->TabIndex = 98;
			// 
			// textBox68
			// 
			this->textBox68->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox68->Location = System::Drawing::Point(296, 245);
			this->textBox68->Name = L"textBox68";
			this->textBox68->Size = System::Drawing::Size(35, 18);
			this->textBox68->TabIndex = 97;
			// 
			// textBox67
			// 
			this->textBox67->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox67->Location = System::Drawing::Point(296, 225);
			this->textBox67->Name = L"textBox67";
			this->textBox67->Size = System::Drawing::Size(35, 18);
			this->textBox67->TabIndex = 96;
			// 
			// textBox66
			// 
			this->textBox66->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox66->Location = System::Drawing::Point(296, 205);
			this->textBox66->Name = L"textBox66";
			this->textBox66->Size = System::Drawing::Size(35, 18);
			this->textBox66->TabIndex = 95;
			// 
			// textBox65
			// 
			this->textBox65->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox65->Location = System::Drawing::Point(296, 185);
			this->textBox65->Name = L"textBox65";
			this->textBox65->Size = System::Drawing::Size(35, 18);
			this->textBox65->TabIndex = 94;
			// 
			// textBox64
			// 
			this->textBox64->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox64->Location = System::Drawing::Point(296, 165);
			this->textBox64->Name = L"textBox64";
			this->textBox64->Size = System::Drawing::Size(35, 18);
			this->textBox64->TabIndex = 93;
			// 
			// textBox63
			// 
			this->textBox63->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox63->Location = System::Drawing::Point(296, 145);
			this->textBox63->Name = L"textBox63";
			this->textBox63->Size = System::Drawing::Size(35, 18);
			this->textBox63->TabIndex = 92;
			// 
			// textBox62
			// 
			this->textBox62->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox62->Location = System::Drawing::Point(296, 125);
			this->textBox62->Name = L"textBox62";
			this->textBox62->Size = System::Drawing::Size(35, 18);
			this->textBox62->TabIndex = 91;
			// 
			// textBox61
			// 
			this->textBox61->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox61->Location = System::Drawing::Point(296, 105);
			this->textBox61->Name = L"textBox61";
			this->textBox61->Size = System::Drawing::Size(35, 18);
			this->textBox61->TabIndex = 90;
			// 
			// textBox60
			// 
			this->textBox60->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox60->Location = System::Drawing::Point(296, 85);
			this->textBox60->Name = L"textBox60";
			this->textBox60->Size = System::Drawing::Size(35, 18);
			this->textBox60->TabIndex = 89;
			// 
			// textBox59
			// 
			this->textBox59->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox59->Location = System::Drawing::Point(296, 65);
			this->textBox59->Name = L"textBox59";
			this->textBox59->Size = System::Drawing::Size(35, 18);
			this->textBox59->TabIndex = 88;
			// 
			// textBox58
			// 
			this->textBox58->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox58->Location = System::Drawing::Point(296, 45);
			this->textBox58->Name = L"textBox58";
			this->textBox58->Size = System::Drawing::Size(35, 18);
			this->textBox58->TabIndex = 87;
			// 
			// textBox57
			// 
			this->textBox57->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox57->Location = System::Drawing::Point(296, 25);
			this->textBox57->Name = L"textBox57";
			this->textBox57->Size = System::Drawing::Size(35, 18);
			this->textBox57->TabIndex = 86;
			// 
			// label57
			// 
			this->label57->AutoSize = true;
			this->label57->Location = System::Drawing::Point(235, 27);
			this->label57->Name = L"label57";
			this->label57->Size = System::Drawing::Size(57, 13);
			this->label57->TabIndex = 85;
			this->label57->Text = L"TXB2CON";
			// 
			// label56
			// 
			this->label56->AutoSize = true;
			this->label56->Location = System::Drawing::Point(122, 287);
			this->label56->Name = L"label56";
			this->label56->Size = System::Drawing::Size(48, 13);
			this->label56->TabIndex = 84;
			this->label56->Text = L"TXB1D7";
			// 
			// textBox56
			// 
			this->textBox56->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox56->Location = System::Drawing::Point(183, 285);
			this->textBox56->Name = L"textBox56";
			this->textBox56->Size = System::Drawing::Size(35, 18);
			this->textBox56->TabIndex = 83;
			// 
			// textBox55
			// 
			this->textBox55->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox55->Location = System::Drawing::Point(183, 265);
			this->textBox55->Name = L"textBox55";
			this->textBox55->Size = System::Drawing::Size(35, 18);
			this->textBox55->TabIndex = 82;
			// 
			// textBox54
			// 
			this->textBox54->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox54->Location = System::Drawing::Point(183, 245);
			this->textBox54->Name = L"textBox54";
			this->textBox54->Size = System::Drawing::Size(35, 18);
			this->textBox54->TabIndex = 81;
			// 
			// textBox53
			// 
			this->textBox53->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox53->Location = System::Drawing::Point(183, 225);
			this->textBox53->Name = L"textBox53";
			this->textBox53->Size = System::Drawing::Size(35, 18);
			this->textBox53->TabIndex = 80;
			// 
			// textBox52
			// 
			this->textBox52->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox52->Location = System::Drawing::Point(183, 205);
			this->textBox52->Name = L"textBox52";
			this->textBox52->Size = System::Drawing::Size(35, 18);
			this->textBox52->TabIndex = 79;
			// 
			// textBox51
			// 
			this->textBox51->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox51->Location = System::Drawing::Point(183, 185);
			this->textBox51->Name = L"textBox51";
			this->textBox51->Size = System::Drawing::Size(35, 18);
			this->textBox51->TabIndex = 78;
			// 
			// textBox50
			// 
			this->textBox50->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox50->Location = System::Drawing::Point(183, 165);
			this->textBox50->Name = L"textBox50";
			this->textBox50->Size = System::Drawing::Size(35, 18);
			this->textBox50->TabIndex = 77;
			// 
			// textBox49
			// 
			this->textBox49->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox49->Location = System::Drawing::Point(183, 145);
			this->textBox49->Name = L"textBox49";
			this->textBox49->Size = System::Drawing::Size(35, 18);
			this->textBox49->TabIndex = 76;
			// 
			// textBox48
			// 
			this->textBox48->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox48->Location = System::Drawing::Point(183, 125);
			this->textBox48->Name = L"textBox48";
			this->textBox48->Size = System::Drawing::Size(35, 18);
			this->textBox48->TabIndex = 75;
			// 
			// textBox47
			// 
			this->textBox47->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox47->Location = System::Drawing::Point(183, 105);
			this->textBox47->Name = L"textBox47";
			this->textBox47->Size = System::Drawing::Size(35, 18);
			this->textBox47->TabIndex = 74;
			// 
			// textBox46
			// 
			this->textBox46->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox46->Location = System::Drawing::Point(183, 85);
			this->textBox46->Name = L"textBox46";
			this->textBox46->Size = System::Drawing::Size(35, 18);
			this->textBox46->TabIndex = 73;
			// 
			// textBox45
			// 
			this->textBox45->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox45->Location = System::Drawing::Point(183, 65);
			this->textBox45->Name = L"textBox45";
			this->textBox45->Size = System::Drawing::Size(35, 18);
			this->textBox45->TabIndex = 72;
			// 
			// textBox44
			// 
			this->textBox44->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox44->Location = System::Drawing::Point(183, 45);
			this->textBox44->Name = L"textBox44";
			this->textBox44->Size = System::Drawing::Size(35, 18);
			this->textBox44->TabIndex = 71;
			// 
			// textBox43
			// 
			this->textBox43->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox43->Location = System::Drawing::Point(183, 25);
			this->textBox43->Name = L"textBox43";
			this->textBox43->Size = System::Drawing::Size(35, 18);
			this->textBox43->TabIndex = 70;
			// 
			// label55
			// 
			this->label55->AutoSize = true;
			this->label55->Location = System::Drawing::Point(122, 267);
			this->label55->Name = L"label55";
			this->label55->Size = System::Drawing::Size(48, 13);
			this->label55->TabIndex = 69;
			this->label55->Text = L"TXB1D6";
			// 
			// label54
			// 
			this->label54->AutoSize = true;
			this->label54->Location = System::Drawing::Point(122, 247);
			this->label54->Name = L"label54";
			this->label54->Size = System::Drawing::Size(48, 13);
			this->label54->TabIndex = 68;
			this->label54->Text = L"TXB1D5";
			// 
			// label53
			// 
			this->label53->AutoSize = true;
			this->label53->Location = System::Drawing::Point(122, 227);
			this->label53->Name = L"label53";
			this->label53->Size = System::Drawing::Size(48, 13);
			this->label53->TabIndex = 67;
			this->label53->Text = L"TXB1D4";
			// 
			// label52
			// 
			this->label52->AutoSize = true;
			this->label52->Location = System::Drawing::Point(122, 207);
			this->label52->Name = L"label52";
			this->label52->Size = System::Drawing::Size(48, 13);
			this->label52->TabIndex = 66;
			this->label52->Text = L"TXB1D3";
			// 
			// label51
			// 
			this->label51->AutoSize = true;
			this->label51->Location = System::Drawing::Point(122, 187);
			this->label51->Name = L"label51";
			this->label51->Size = System::Drawing::Size(48, 13);
			this->label51->TabIndex = 65;
			this->label51->Text = L"TXB1D2";
			// 
			// label50
			// 
			this->label50->AutoSize = true;
			this->label50->Location = System::Drawing::Point(122, 167);
			this->label50->Name = L"label50";
			this->label50->Size = System::Drawing::Size(48, 13);
			this->label50->TabIndex = 64;
			this->label50->Text = L"TXB1D1";
			// 
			// label49
			// 
			this->label49->AutoSize = true;
			this->label49->Location = System::Drawing::Point(122, 147);
			this->label49->Name = L"label49";
			this->label49->Size = System::Drawing::Size(48, 13);
			this->label49->TabIndex = 63;
			this->label49->Text = L"TXB1D0";
			// 
			// label48
			// 
			this->label48->AutoSize = true;
			this->label48->Location = System::Drawing::Point(122, 127);
			this->label48->Name = L"label48";
			this->label48->Size = System::Drawing::Size(55, 13);
			this->label48->TabIndex = 62;
			this->label48->Text = L"TXB1DLC";
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Location = System::Drawing::Point(122, 107);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(58, 13);
			this->label47->TabIndex = 61;
			this->label47->Text = L"TXB1EIDL";
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Location = System::Drawing::Point(122, 87);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(60, 13);
			this->label46->TabIndex = 60;
			this->label46->Text = L"TXB1EIDH";
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Location = System::Drawing::Point(122, 67);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(58, 13);
			this->label45->TabIndex = 59;
			this->label45->Text = L"TXB1SIDL";
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->Location = System::Drawing::Point(122, 47);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(60, 13);
			this->label44->TabIndex = 58;
			this->label44->Text = L"TXB1SIDH";
			// 
			// label43
			// 
			this->label43->AutoSize = true;
			this->label43->Location = System::Drawing::Point(122, 27);
			this->label43->Name = L"label43";
			this->label43->Size = System::Drawing::Size(57, 13);
			this->label43->TabIndex = 57;
			this->label43->Text = L"TXB1CON";
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->Location = System::Drawing::Point(5, 287);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(48, 13);
			this->label42->TabIndex = 56;
			this->label42->Text = L"TXB0D7";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Location = System::Drawing::Point(5, 267);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(48, 13);
			this->label41->TabIndex = 55;
			this->label41->Text = L"TXB0D6";
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Location = System::Drawing::Point(5, 247);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(48, 13);
			this->label40->TabIndex = 54;
			this->label40->Text = L"TXB0D5";
			// 
			// label39
			// 
			this->label39->AutoSize = true;
			this->label39->Location = System::Drawing::Point(5, 227);
			this->label39->Name = L"label39";
			this->label39->Size = System::Drawing::Size(48, 13);
			this->label39->TabIndex = 53;
			this->label39->Text = L"TXB0D4";
			// 
			// label38
			// 
			this->label38->AutoSize = true;
			this->label38->Location = System::Drawing::Point(5, 207);
			this->label38->Name = L"label38";
			this->label38->Size = System::Drawing::Size(48, 13);
			this->label38->TabIndex = 52;
			this->label38->Text = L"TXB0D3";
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->Location = System::Drawing::Point(5, 187);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(48, 13);
			this->label37->TabIndex = 51;
			this->label37->Text = L"TXB0D2";
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Location = System::Drawing::Point(5, 167);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(48, 13);
			this->label36->TabIndex = 50;
			this->label36->Text = L"TXB0D1";
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(5, 147);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(48, 13);
			this->label35->TabIndex = 49;
			this->label35->Text = L"TXB0D0";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(5, 127);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(55, 13);
			this->label34->TabIndex = 48;
			this->label34->Text = L"TXB0DLC";
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(5, 105);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(58, 13);
			this->label33->TabIndex = 47;
			this->label33->Text = L"TXB0EIDL";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(5, 86);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(60, 13);
			this->label32->TabIndex = 46;
			this->label32->Text = L"TXB0EIDH";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(5, 67);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(58, 13);
			this->label31->TabIndex = 45;
			this->label31->Text = L"TXB0SIDL";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(5, 47);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(60, 13);
			this->label30->TabIndex = 44;
			this->label30->Text = L"TXB0SIDH";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(5, 27);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(57, 13);
			this->label29->TabIndex = 43;
			this->label29->Text = L"TXB0CON";
			// 
			// textBox42
			// 
			this->textBox42->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox42->Location = System::Drawing::Point(66, 285);
			this->textBox42->Name = L"textBox42";
			this->textBox42->Size = System::Drawing::Size(35, 18);
			this->textBox42->TabIndex = 42;
			// 
			// textBox41
			// 
			this->textBox41->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox41->Location = System::Drawing::Point(66, 265);
			this->textBox41->Name = L"textBox41";
			this->textBox41->Size = System::Drawing::Size(35, 18);
			this->textBox41->TabIndex = 41;
			// 
			// textBox40
			// 
			this->textBox40->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox40->Location = System::Drawing::Point(66, 245);
			this->textBox40->Name = L"textBox40";
			this->textBox40->Size = System::Drawing::Size(35, 18);
			this->textBox40->TabIndex = 40;
			// 
			// textBox39
			// 
			this->textBox39->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox39->Location = System::Drawing::Point(66, 225);
			this->textBox39->Name = L"textBox39";
			this->textBox39->Size = System::Drawing::Size(35, 18);
			this->textBox39->TabIndex = 39;
			// 
			// textBox38
			// 
			this->textBox38->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox38->Location = System::Drawing::Point(66, 205);
			this->textBox38->Name = L"textBox38";
			this->textBox38->Size = System::Drawing::Size(35, 18);
			this->textBox38->TabIndex = 38;
			// 
			// textBox37
			// 
			this->textBox37->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox37->Location = System::Drawing::Point(66, 185);
			this->textBox37->Name = L"textBox37";
			this->textBox37->Size = System::Drawing::Size(35, 18);
			this->textBox37->TabIndex = 37;
			// 
			// textBox36
			// 
			this->textBox36->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox36->Location = System::Drawing::Point(66, 165);
			this->textBox36->Name = L"textBox36";
			this->textBox36->Size = System::Drawing::Size(35, 18);
			this->textBox36->TabIndex = 36;
			// 
			// textBox35
			// 
			this->textBox35->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox35->Location = System::Drawing::Point(66, 145);
			this->textBox35->Name = L"textBox35";
			this->textBox35->Size = System::Drawing::Size(35, 18);
			this->textBox35->TabIndex = 35;
			// 
			// textBox34
			// 
			this->textBox34->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox34->Location = System::Drawing::Point(66, 125);
			this->textBox34->Name = L"textBox34";
			this->textBox34->Size = System::Drawing::Size(35, 18);
			this->textBox34->TabIndex = 34;
			// 
			// textBox33
			// 
			this->textBox33->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox33->Location = System::Drawing::Point(66, 105);
			this->textBox33->Name = L"textBox33";
			this->textBox33->Size = System::Drawing::Size(35, 18);
			this->textBox33->TabIndex = 33;
			// 
			// textBox32
			// 
			this->textBox32->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox32->Location = System::Drawing::Point(66, 85);
			this->textBox32->Name = L"textBox32";
			this->textBox32->Size = System::Drawing::Size(35, 18);
			this->textBox32->TabIndex = 32;
			// 
			// textBox31
			// 
			this->textBox31->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox31->Location = System::Drawing::Point(66, 65);
			this->textBox31->Name = L"textBox31";
			this->textBox31->Size = System::Drawing::Size(35, 18);
			this->textBox31->TabIndex = 31;
			// 
			// textBox30
			// 
			this->textBox30->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox30->Location = System::Drawing::Point(66, 45);
			this->textBox30->Name = L"textBox30";
			this->textBox30->Size = System::Drawing::Size(35, 18);
			this->textBox30->TabIndex = 30;
			// 
			// textBox29
			// 
			this->textBox29->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox29->Location = System::Drawing::Point(66, 25);
			this->textBox29->Name = L"textBox29";
			this->textBox29->Size = System::Drawing::Size(35, 18);
			this->textBox29->TabIndex = 29;
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->label84);
			this->groupBox3->Controls->Add(this->label83);
			this->groupBox3->Controls->Add(this->label82);
			this->groupBox3->Controls->Add(this->label81);
			this->groupBox3->Controls->Add(this->label80);
			this->groupBox3->Controls->Add(this->label79);
			this->groupBox3->Controls->Add(this->label78);
			this->groupBox3->Controls->Add(this->textBox84);
			this->groupBox3->Controls->Add(this->textBox83);
			this->groupBox3->Controls->Add(this->textBox82);
			this->groupBox3->Controls->Add(this->textBox81);
			this->groupBox3->Controls->Add(this->textBox80);
			this->groupBox3->Controls->Add(this->textBox79);
			this->groupBox3->Controls->Add(this->textBox78);
			this->groupBox3->Controls->Add(this->textBox77);
			this->groupBox3->Controls->Add(this->textBox76);
			this->groupBox3->Controls->Add(this->textBox75);
			this->groupBox3->Controls->Add(this->textBox74);
			this->groupBox3->Controls->Add(this->textBox73);
			this->groupBox3->Controls->Add(this->textBox72);
			this->groupBox3->Controls->Add(this->label77);
			this->groupBox3->Controls->Add(this->label76);
			this->groupBox3->Controls->Add(this->label75);
			this->groupBox3->Controls->Add(this->label74);
			this->groupBox3->Controls->Add(this->label73);
			this->groupBox3->Controls->Add(this->label72);
			this->groupBox3->Controls->Add(this->label71);
			this->groupBox3->Controls->Add(this->textBox71);
			this->groupBox3->Location = System::Drawing::Point(581, 5);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(111, 310);
			this->groupBox3->TabIndex = 2;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Masks";
			// 
			// label84
			// 
			this->label84->AutoSize = true;
			this->label84->Location = System::Drawing::Point(5, 287);
			this->label84->Name = L"label84";
			this->label84->Size = System::Drawing::Size(57, 13);
			this->label84->TabIndex = 114;
			this->label84->Text = L"RXFCON1";
			// 
			// label83
			// 
			this->label83->AutoSize = true;
			this->label83->Location = System::Drawing::Point(5, 267);
			this->label83->Name = L"label83";
			this->label83->Size = System::Drawing::Size(57, 13);
			this->label83->TabIndex = 113;
			this->label83->Text = L"RXFCON0";
			// 
			// label82
			// 
			this->label82->AutoSize = true;
			this->label82->Location = System::Drawing::Point(5, 247);
			this->label82->Name = L"label82";
			this->label82->Size = System::Drawing::Size(42, 13);
			this->label82->TabIndex = 112;
			this->label82->Text = L"MSEL3";
			// 
			// label81
			// 
			this->label81->AutoSize = true;
			this->label81->Location = System::Drawing::Point(5, 227);
			this->label81->Name = L"label81";
			this->label81->Size = System::Drawing::Size(42, 13);
			this->label81->TabIndex = 111;
			this->label81->Text = L"MSEL2";
			// 
			// label80
			// 
			this->label80->AutoSize = true;
			this->label80->Location = System::Drawing::Point(5, 207);
			this->label80->Name = L"label80";
			this->label80->Size = System::Drawing::Size(42, 13);
			this->label80->TabIndex = 110;
			this->label80->Text = L"MSEL1";
			// 
			// label79
			// 
			this->label79->AutoSize = true;
			this->label79->Location = System::Drawing::Point(5, 187);
			this->label79->Name = L"label79";
			this->label79->Size = System::Drawing::Size(42, 13);
			this->label79->TabIndex = 109;
			this->label79->Text = L"MSEL0";
			// 
			// label78
			// 
			this->label78->AutoSize = true;
			this->label78->Location = System::Drawing::Point(5, 167);
			this->label78->Name = L"label78";
			this->label78->Size = System::Drawing::Size(61, 13);
			this->label78->TabIndex = 108;
			this->label78->Text = L"RXM1EIDL";
			// 
			// textBox84
			// 
			this->textBox84->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox84->Location = System::Drawing::Point(69, 285);
			this->textBox84->Name = L"textBox84";
			this->textBox84->Size = System::Drawing::Size(35, 18);
			this->textBox84->TabIndex = 107;
			// 
			// textBox83
			// 
			this->textBox83->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox83->Location = System::Drawing::Point(69, 265);
			this->textBox83->Name = L"textBox83";
			this->textBox83->Size = System::Drawing::Size(35, 18);
			this->textBox83->TabIndex = 106;
			// 
			// textBox82
			// 
			this->textBox82->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox82->Location = System::Drawing::Point(69, 245);
			this->textBox82->Name = L"textBox82";
			this->textBox82->Size = System::Drawing::Size(35, 18);
			this->textBox82->TabIndex = 105;
			// 
			// textBox81
			// 
			this->textBox81->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox81->Location = System::Drawing::Point(69, 225);
			this->textBox81->Name = L"textBox81";
			this->textBox81->Size = System::Drawing::Size(35, 18);
			this->textBox81->TabIndex = 104;
			// 
			// textBox80
			// 
			this->textBox80->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox80->Location = System::Drawing::Point(69, 205);
			this->textBox80->Name = L"textBox80";
			this->textBox80->Size = System::Drawing::Size(35, 18);
			this->textBox80->TabIndex = 103;
			// 
			// textBox79
			// 
			this->textBox79->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox79->Location = System::Drawing::Point(69, 185);
			this->textBox79->Name = L"textBox79";
			this->textBox79->Size = System::Drawing::Size(35, 18);
			this->textBox79->TabIndex = 102;
			// 
			// textBox78
			// 
			this->textBox78->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox78->Location = System::Drawing::Point(69, 165);
			this->textBox78->Name = L"textBox78";
			this->textBox78->Size = System::Drawing::Size(35, 18);
			this->textBox78->TabIndex = 101;
			// 
			// textBox77
			// 
			this->textBox77->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox77->Location = System::Drawing::Point(69, 145);
			this->textBox77->Name = L"textBox77";
			this->textBox77->Size = System::Drawing::Size(35, 18);
			this->textBox77->TabIndex = 100;
			// 
			// textBox76
			// 
			this->textBox76->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox76->Location = System::Drawing::Point(69, 125);
			this->textBox76->Name = L"textBox76";
			this->textBox76->Size = System::Drawing::Size(35, 18);
			this->textBox76->TabIndex = 99;
			// 
			// textBox75
			// 
			this->textBox75->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox75->Location = System::Drawing::Point(68, 105);
			this->textBox75->Name = L"textBox75";
			this->textBox75->Size = System::Drawing::Size(35, 18);
			this->textBox75->TabIndex = 98;
			// 
			// textBox74
			// 
			this->textBox74->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox74->Location = System::Drawing::Point(68, 85);
			this->textBox74->Name = L"textBox74";
			this->textBox74->Size = System::Drawing::Size(35, 18);
			this->textBox74->TabIndex = 97;
			// 
			// textBox73
			// 
			this->textBox73->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox73->Location = System::Drawing::Point(68, 65);
			this->textBox73->Name = L"textBox73";
			this->textBox73->Size = System::Drawing::Size(35, 18);
			this->textBox73->TabIndex = 96;
			// 
			// textBox72
			// 
			this->textBox72->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox72->Location = System::Drawing::Point(68, 45);
			this->textBox72->Name = L"textBox72";
			this->textBox72->Size = System::Drawing::Size(35, 18);
			this->textBox72->TabIndex = 95;
			// 
			// label77
			// 
			this->label77->AutoSize = true;
			this->label77->Location = System::Drawing::Point(5, 147);
			this->label77->Name = L"label77";
			this->label77->Size = System::Drawing::Size(63, 13);
			this->label77->TabIndex = 94;
			this->label77->Text = L"RXM1EIDH";
			// 
			// label76
			// 
			this->label76->AutoSize = true;
			this->label76->Location = System::Drawing::Point(5, 127);
			this->label76->Name = L"label76";
			this->label76->Size = System::Drawing::Size(61, 13);
			this->label76->TabIndex = 93;
			this->label76->Text = L"RXM1SIDL";
			// 
			// label75
			// 
			this->label75->AutoSize = true;
			this->label75->Location = System::Drawing::Point(5, 107);
			this->label75->Name = L"label75";
			this->label75->Size = System::Drawing::Size(63, 13);
			this->label75->TabIndex = 92;
			this->label75->Text = L"RXM1SIDH";
			// 
			// label74
			// 
			this->label74->AutoSize = true;
			this->label74->Location = System::Drawing::Point(5, 87);
			this->label74->Name = L"label74";
			this->label74->Size = System::Drawing::Size(61, 13);
			this->label74->TabIndex = 91;
			this->label74->Text = L"RXM0EIDL";
			// 
			// label73
			// 
			this->label73->AutoSize = true;
			this->label73->Location = System::Drawing::Point(5, 67);
			this->label73->Name = L"label73";
			this->label73->Size = System::Drawing::Size(63, 13);
			this->label73->TabIndex = 90;
			this->label73->Text = L"RXM0EIDH";
			// 
			// label72
			// 
			this->label72->AutoSize = true;
			this->label72->Location = System::Drawing::Point(5, 47);
			this->label72->Name = L"label72";
			this->label72->Size = System::Drawing::Size(61, 13);
			this->label72->TabIndex = 89;
			this->label72->Text = L"RXM0SIDL";
			// 
			// label71
			// 
			this->label71->AutoSize = true;
			this->label71->Location = System::Drawing::Point(5, 27);
			this->label71->Name = L"label71";
			this->label71->Size = System::Drawing::Size(63, 13);
			this->label71->TabIndex = 88;
			this->label71->Text = L"RXM0SIDH";
			// 
			// textBox71
			// 
			this->textBox71->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox71->Location = System::Drawing::Point(68, 25);
			this->textBox71->Name = L"textBox71";
			this->textBox71->Size = System::Drawing::Size(35, 18);
			this->textBox71->TabIndex = 87;
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->label94);
			this->groupBox4->Controls->Add(this->label93);
			this->groupBox4->Controls->Add(this->label92);
			this->groupBox4->Controls->Add(this->label91);
			this->groupBox4->Controls->Add(this->label90);
			this->groupBox4->Controls->Add(this->label89);
			this->groupBox4->Controls->Add(this->label88);
			this->groupBox4->Controls->Add(this->label87);
			this->groupBox4->Controls->Add(this->label86);
			this->groupBox4->Controls->Add(this->label85);
			this->groupBox4->Controls->Add(this->textBox94);
			this->groupBox4->Controls->Add(this->textBox93);
			this->groupBox4->Controls->Add(this->textBox92);
			this->groupBox4->Controls->Add(this->textBox91);
			this->groupBox4->Controls->Add(this->textBox90);
			this->groupBox4->Controls->Add(this->textBox89);
			this->groupBox4->Controls->Add(this->textBox88);
			this->groupBox4->Controls->Add(this->textBox87);
			this->groupBox4->Controls->Add(this->textBox86);
			this->groupBox4->Controls->Add(this->textBox85);
			this->groupBox4->Location = System::Drawing::Point(698, 5);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(119, 310);
			this->groupBox4->TabIndex = 3;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"Control";
			// 
			// label94
			// 
			this->label94->AutoSize = true;
			this->label94->Location = System::Drawing::Point(5, 207);
			this->label94->Name = L"label94";
			this->label94->Size = System::Drawing::Size(59, 13);
			this->label94->TabIndex = 108;
			this->label94->Text = L"COMSTAT";
			// 
			// label93
			// 
			this->label93->AutoSize = true;
			this->label93->Location = System::Drawing::Point(6, 187);
			this->label93->Name = L"label93";
			this->label93->Size = System::Drawing::Size(31, 13);
			this->label93->TabIndex = 107;
			this->label93->Text = L"PIR3";
			// 
			// label92
			// 
			this->label92->AutoSize = true;
			this->label92->Location = System::Drawing::Point(5, 167);
			this->label92->Name = L"label92";
			this->label92->Size = System::Drawing::Size(66, 13);
			this->label92->TabIndex = 106;
			this->label92->Text = L"TXERRCNT";
			// 
			// label91
			// 
			this->label91->AutoSize = true;
			this->label91->Location = System::Drawing::Point(4, 147);
			this->label91->Name = L"label91";
			this->label91->Size = System::Drawing::Size(67, 13);
			this->label91->TabIndex = 105;
			this->label91->Text = L"RXERRCNT";
			// 
			// label90
			// 
			this->label90->AutoSize = true;
			this->label90->Location = System::Drawing::Point(5, 127);
			this->label90->Name = L"label90";
			this->label90->Size = System::Drawing::Size(59, 13);
			this->label90->TabIndex = 104;
			this->label90->Text = L"BRGCON3";
			// 
			// label89
			// 
			this->label89->AutoSize = true;
			this->label89->Location = System::Drawing::Point(5, 107);
			this->label89->Name = L"label89";
			this->label89->Size = System::Drawing::Size(59, 13);
			this->label89->TabIndex = 103;
			this->label89->Text = L"BRGCON2";
			// 
			// label88
			// 
			this->label88->AutoSize = true;
			this->label88->Location = System::Drawing::Point(5, 87);
			this->label88->Name = L"label88";
			this->label88->Size = System::Drawing::Size(59, 13);
			this->label88->TabIndex = 102;
			this->label88->Text = L"BRGCON1";
			// 
			// label87
			// 
			this->label87->AutoSize = true;
			this->label87->Location = System::Drawing::Point(5, 67);
			this->label87->Name = L"label87";
			this->label87->Size = System::Drawing::Size(57, 13);
			this->label87->TabIndex = 101;
			this->label87->Text = L"CANSTAT";
			// 
			// label86
			// 
			this->label86->AutoSize = true;
			this->label86->Location = System::Drawing::Point(5, 47);
			this->label86->Name = L"label86";
			this->label86->Size = System::Drawing::Size(52, 13);
			this->label86->TabIndex = 100;
			this->label86->Text = L"CANCON";
			// 
			// label85
			// 
			this->label85->AutoSize = true;
			this->label85->Location = System::Drawing::Point(5, 27);
			this->label85->Name = L"label85";
			this->label85->Size = System::Drawing::Size(59, 13);
			this->label85->TabIndex = 99;
			this->label85->Text = L"ECANCON";
			// 
			// textBox94
			// 
			this->textBox94->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox94->Location = System::Drawing::Point(76, 205);
			this->textBox94->Name = L"textBox94";
			this->textBox94->Size = System::Drawing::Size(35, 18);
			this->textBox94->TabIndex = 97;
			// 
			// textBox93
			// 
			this->textBox93->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox93->Location = System::Drawing::Point(76, 185);
			this->textBox93->Name = L"textBox93";
			this->textBox93->Size = System::Drawing::Size(35, 18);
			this->textBox93->TabIndex = 96;
			// 
			// textBox92
			// 
			this->textBox92->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox92->Location = System::Drawing::Point(76, 165);
			this->textBox92->Name = L"textBox92";
			this->textBox92->Size = System::Drawing::Size(35, 18);
			this->textBox92->TabIndex = 95;
			// 
			// textBox91
			// 
			this->textBox91->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox91->Location = System::Drawing::Point(76, 145);
			this->textBox91->Name = L"textBox91";
			this->textBox91->Size = System::Drawing::Size(35, 18);
			this->textBox91->TabIndex = 94;
			// 
			// textBox90
			// 
			this->textBox90->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox90->Location = System::Drawing::Point(76, 125);
			this->textBox90->Name = L"textBox90";
			this->textBox90->Size = System::Drawing::Size(35, 18);
			this->textBox90->TabIndex = 93;
			// 
			// textBox89
			// 
			this->textBox89->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox89->Location = System::Drawing::Point(76, 105);
			this->textBox89->Name = L"textBox89";
			this->textBox89->Size = System::Drawing::Size(35, 18);
			this->textBox89->TabIndex = 92;
			// 
			// textBox88
			// 
			this->textBox88->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox88->Location = System::Drawing::Point(76, 85);
			this->textBox88->Name = L"textBox88";
			this->textBox88->Size = System::Drawing::Size(35, 18);
			this->textBox88->TabIndex = 91;
			// 
			// textBox87
			// 
			this->textBox87->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox87->Location = System::Drawing::Point(76, 65);
			this->textBox87->Name = L"textBox87";
			this->textBox87->Size = System::Drawing::Size(35, 18);
			this->textBox87->TabIndex = 90;
			// 
			// textBox86
			// 
			this->textBox86->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox86->Location = System::Drawing::Point(76, 45);
			this->textBox86->Name = L"textBox86";
			this->textBox86->Size = System::Drawing::Size(35, 18);
			this->textBox86->TabIndex = 89;
			// 
			// textBox85
			// 
			this->textBox85->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox85->Location = System::Drawing::Point(76, 25);
			this->textBox85->Name = L"textBox85";
			this->textBox85->Size = System::Drawing::Size(35, 18);
			this->textBox85->TabIndex = 88;
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->label118);
			this->groupBox5->Controls->Add(this->label117);
			this->groupBox5->Controls->Add(this->label116);
			this->groupBox5->Controls->Add(this->label115);
			this->groupBox5->Controls->Add(this->label114);
			this->groupBox5->Controls->Add(this->label113);
			this->groupBox5->Controls->Add(this->label112);
			this->groupBox5->Controls->Add(this->label111);
			this->groupBox5->Controls->Add(this->label110);
			this->groupBox5->Controls->Add(this->label109);
			this->groupBox5->Controls->Add(this->label108);
			this->groupBox5->Controls->Add(this->label107);
			this->groupBox5->Controls->Add(this->label106);
			this->groupBox5->Controls->Add(this->label105);
			this->groupBox5->Controls->Add(this->label104);
			this->groupBox5->Controls->Add(this->label103);
			this->groupBox5->Controls->Add(this->label102);
			this->groupBox5->Controls->Add(this->label101);
			this->groupBox5->Controls->Add(this->label100);
			this->groupBox5->Controls->Add(this->label99);
			this->groupBox5->Controls->Add(this->label98);
			this->groupBox5->Controls->Add(this->label97);
			this->groupBox5->Controls->Add(this->label96);
			this->groupBox5->Controls->Add(this->label95);
			this->groupBox5->Controls->Add(this->textBox118);
			this->groupBox5->Controls->Add(this->textBox117);
			this->groupBox5->Controls->Add(this->textBox116);
			this->groupBox5->Controls->Add(this->textBox115);
			this->groupBox5->Controls->Add(this->textBox114);
			this->groupBox5->Controls->Add(this->textBox113);
			this->groupBox5->Controls->Add(this->textBox112);
			this->groupBox5->Controls->Add(this->textBox111);
			this->groupBox5->Controls->Add(this->textBox110);
			this->groupBox5->Controls->Add(this->textBox109);
			this->groupBox5->Controls->Add(this->textBox108);
			this->groupBox5->Controls->Add(this->textBox107);
			this->groupBox5->Controls->Add(this->textBox106);
			this->groupBox5->Controls->Add(this->textBox105);
			this->groupBox5->Controls->Add(this->textBox104);
			this->groupBox5->Controls->Add(this->textBox103);
			this->groupBox5->Controls->Add(this->textBox102);
			this->groupBox5->Controls->Add(this->textBox101);
			this->groupBox5->Controls->Add(this->textBox100);
			this->groupBox5->Controls->Add(this->textBox99);
			this->groupBox5->Controls->Add(this->textBox98);
			this->groupBox5->Controls->Add(this->textBox97);
			this->groupBox5->Controls->Add(this->textBox96);
			this->groupBox5->Controls->Add(this->textBox95);
			this->groupBox5->Location = System::Drawing::Point(5, 317);
			this->groupBox5->Name = L"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(687, 111);
			this->groupBox5->TabIndex = 4;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = L"Filters";
			// 
			// label118
			// 
			this->label118->AutoSize = true;
			this->label118->Location = System::Drawing::Point(581, 87);
			this->label118->Name = L"label118";
			this->label118->Size = System::Drawing::Size(58, 13);
			this->label118->TabIndex = 145;
			this->label118->Text = L"RXF5EIDL";
			// 
			// label117
			// 
			this->label117->AutoSize = true;
			this->label117->Location = System::Drawing::Point(581, 67);
			this->label117->Name = L"label117";
			this->label117->Size = System::Drawing::Size(60, 13);
			this->label117->TabIndex = 144;
			this->label117->Text = L"RXF5EIDH";
			// 
			// label116
			// 
			this->label116->AutoSize = true;
			this->label116->Location = System::Drawing::Point(581, 47);
			this->label116->Name = L"label116";
			this->label116->Size = System::Drawing::Size(58, 13);
			this->label116->TabIndex = 143;
			this->label116->Text = L"RXF5SIDL";
			// 
			// label115
			// 
			this->label115->AutoSize = true;
			this->label115->Location = System::Drawing::Point(581, 27);
			this->label115->Name = L"label115";
			this->label115->Size = System::Drawing::Size(60, 13);
			this->label115->TabIndex = 142;
			this->label115->Text = L"RXF5SIDH";
			// 
			// label114
			// 
			this->label114->AutoSize = true;
			this->label114->Location = System::Drawing::Point(466, 87);
			this->label114->Name = L"label114";
			this->label114->Size = System::Drawing::Size(58, 13);
			this->label114->TabIndex = 141;
			this->label114->Text = L"RXF4EIDL";
			// 
			// label113
			// 
			this->label113->AutoSize = true;
			this->label113->Location = System::Drawing::Point(466, 67);
			this->label113->Name = L"label113";
			this->label113->Size = System::Drawing::Size(60, 13);
			this->label113->TabIndex = 140;
			this->label113->Text = L"RXF4EIDH";
			// 
			// label112
			// 
			this->label112->AutoSize = true;
			this->label112->Location = System::Drawing::Point(466, 47);
			this->label112->Name = L"label112";
			this->label112->Size = System::Drawing::Size(58, 13);
			this->label112->TabIndex = 139;
			this->label112->Text = L"RXF4SIDL";
			// 
			// label111
			// 
			this->label111->AutoSize = true;
			this->label111->Location = System::Drawing::Point(466, 27);
			this->label111->Name = L"label111";
			this->label111->Size = System::Drawing::Size(60, 13);
			this->label111->TabIndex = 138;
			this->label111->Text = L"RXF4SIDH";
			// 
			// label110
			// 
			this->label110->AutoSize = true;
			this->label110->Location = System::Drawing::Point(353, 87);
			this->label110->Name = L"label110";
			this->label110->Size = System::Drawing::Size(58, 13);
			this->label110->TabIndex = 137;
			this->label110->Text = L"RXF3EIDL";
			// 
			// label109
			// 
			this->label109->AutoSize = true;
			this->label109->Location = System::Drawing::Point(353, 67);
			this->label109->Name = L"label109";
			this->label109->Size = System::Drawing::Size(60, 13);
			this->label109->TabIndex = 136;
			this->label109->Text = L"RXF3EIDH";
			// 
			// label108
			// 
			this->label108->AutoSize = true;
			this->label108->Location = System::Drawing::Point(353, 47);
			this->label108->Name = L"label108";
			this->label108->Size = System::Drawing::Size(58, 13);
			this->label108->TabIndex = 135;
			this->label108->Text = L"RXF3SIDL";
			// 
			// label107
			// 
			this->label107->AutoSize = true;
			this->label107->Location = System::Drawing::Point(353, 27);
			this->label107->Name = L"label107";
			this->label107->Size = System::Drawing::Size(60, 13);
			this->label107->TabIndex = 134;
			this->label107->Text = L"RXF3SIDH";
			// 
			// label106
			// 
			this->label106->AutoSize = true;
			this->label106->Location = System::Drawing::Point(235, 87);
			this->label106->Name = L"label106";
			this->label106->Size = System::Drawing::Size(58, 13);
			this->label106->TabIndex = 133;
			this->label106->Text = L"RXF2EIDL";
			// 
			// label105
			// 
			this->label105->AutoSize = true;
			this->label105->Location = System::Drawing::Point(235, 67);
			this->label105->Name = L"label105";
			this->label105->Size = System::Drawing::Size(60, 13);
			this->label105->TabIndex = 132;
			this->label105->Text = L"RXF2EIDH";
			// 
			// label104
			// 
			this->label104->AutoSize = true;
			this->label104->Location = System::Drawing::Point(235, 47);
			this->label104->Name = L"label104";
			this->label104->Size = System::Drawing::Size(58, 13);
			this->label104->TabIndex = 131;
			this->label104->Text = L"RXF2SIDL";
			// 
			// label103
			// 
			this->label103->AutoSize = true;
			this->label103->Location = System::Drawing::Point(235, 27);
			this->label103->Name = L"label103";
			this->label103->Size = System::Drawing::Size(60, 13);
			this->label103->TabIndex = 130;
			this->label103->Text = L"RXF2SIDH";
			// 
			// label102
			// 
			this->label102->AutoSize = true;
			this->label102->Location = System::Drawing::Point(120, 87);
			this->label102->Name = L"label102";
			this->label102->Size = System::Drawing::Size(58, 13);
			this->label102->TabIndex = 129;
			this->label102->Text = L"RXF1EIDL";
			// 
			// label101
			// 
			this->label101->AutoSize = true;
			this->label101->Location = System::Drawing::Point(120, 67);
			this->label101->Name = L"label101";
			this->label101->Size = System::Drawing::Size(60, 13);
			this->label101->TabIndex = 128;
			this->label101->Text = L"RXF1EIDH";
			// 
			// label100
			// 
			this->label100->AutoSize = true;
			this->label100->Location = System::Drawing::Point(120, 47);
			this->label100->Name = L"label100";
			this->label100->Size = System::Drawing::Size(58, 13);
			this->label100->TabIndex = 127;
			this->label100->Text = L"RXF1SIDL";
			// 
			// label99
			// 
			this->label99->AutoSize = true;
			this->label99->Location = System::Drawing::Point(120, 27);
			this->label99->Name = L"label99";
			this->label99->Size = System::Drawing::Size(60, 13);
			this->label99->TabIndex = 126;
			this->label99->Text = L"RXF1SIDH";
			// 
			// label98
			// 
			this->label98->AutoSize = true;
			this->label98->Location = System::Drawing::Point(8, 87);
			this->label98->Name = L"label98";
			this->label98->Size = System::Drawing::Size(58, 13);
			this->label98->TabIndex = 125;
			this->label98->Text = L"RXF0EIDL";
			// 
			// label97
			// 
			this->label97->AutoSize = true;
			this->label97->Location = System::Drawing::Point(8, 67);
			this->label97->Name = L"label97";
			this->label97->Size = System::Drawing::Size(60, 13);
			this->label97->TabIndex = 124;
			this->label97->Text = L"RXF0EIDH";
			// 
			// label96
			// 
			this->label96->AutoSize = true;
			this->label96->Location = System::Drawing::Point(7, 47);
			this->label96->Name = L"label96";
			this->label96->Size = System::Drawing::Size(58, 13);
			this->label96->TabIndex = 123;
			this->label96->Text = L"RXF0SIDL";
			// 
			// label95
			// 
			this->label95->AutoSize = true;
			this->label95->Location = System::Drawing::Point(8, 27);
			this->label95->Name = L"label95";
			this->label95->Size = System::Drawing::Size(60, 13);
			this->label95->TabIndex = 122;
			this->label95->Text = L"RXF0SIDH";
			// 
			// textBox118
			// 
			this->textBox118->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox118->Location = System::Drawing::Point(645, 85);
			this->textBox118->Name = L"textBox118";
			this->textBox118->Size = System::Drawing::Size(35, 18);
			this->textBox118->TabIndex = 121;
			// 
			// textBox117
			// 
			this->textBox117->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox117->Location = System::Drawing::Point(645, 65);
			this->textBox117->Name = L"textBox117";
			this->textBox117->Size = System::Drawing::Size(35, 18);
			this->textBox117->TabIndex = 120;
			// 
			// textBox116
			// 
			this->textBox116->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox116->Location = System::Drawing::Point(645, 45);
			this->textBox116->Name = L"textBox116";
			this->textBox116->Size = System::Drawing::Size(35, 18);
			this->textBox116->TabIndex = 119;
			// 
			// textBox115
			// 
			this->textBox115->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox115->Location = System::Drawing::Point(645, 25);
			this->textBox115->Name = L"textBox115";
			this->textBox115->Size = System::Drawing::Size(35, 18);
			this->textBox115->TabIndex = 118;
			// 
			// textBox114
			// 
			this->textBox114->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox114->Location = System::Drawing::Point(527, 85);
			this->textBox114->Name = L"textBox114";
			this->textBox114->Size = System::Drawing::Size(35, 18);
			this->textBox114->TabIndex = 117;
			// 
			// textBox113
			// 
			this->textBox113->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox113->Location = System::Drawing::Point(527, 65);
			this->textBox113->Name = L"textBox113";
			this->textBox113->Size = System::Drawing::Size(35, 18);
			this->textBox113->TabIndex = 116;
			// 
			// textBox112
			// 
			this->textBox112->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox112->Location = System::Drawing::Point(527, 45);
			this->textBox112->Name = L"textBox112";
			this->textBox112->Size = System::Drawing::Size(35, 18);
			this->textBox112->TabIndex = 115;
			// 
			// textBox111
			// 
			this->textBox111->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox111->Location = System::Drawing::Point(527, 25);
			this->textBox111->Name = L"textBox111";
			this->textBox111->Size = System::Drawing::Size(35, 18);
			this->textBox111->TabIndex = 114;
			// 
			// textBox110
			// 
			this->textBox110->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox110->Location = System::Drawing::Point(414, 85);
			this->textBox110->Name = L"textBox110";
			this->textBox110->Size = System::Drawing::Size(35, 18);
			this->textBox110->TabIndex = 113;
			// 
			// textBox109
			// 
			this->textBox109->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox109->Location = System::Drawing::Point(414, 65);
			this->textBox109->Name = L"textBox109";
			this->textBox109->Size = System::Drawing::Size(35, 18);
			this->textBox109->TabIndex = 112;
			// 
			// textBox108
			// 
			this->textBox108->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox108->Location = System::Drawing::Point(414, 45);
			this->textBox108->Name = L"textBox108";
			this->textBox108->Size = System::Drawing::Size(35, 18);
			this->textBox108->TabIndex = 111;
			// 
			// textBox107
			// 
			this->textBox107->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox107->Location = System::Drawing::Point(414, 25);
			this->textBox107->Name = L"textBox107";
			this->textBox107->Size = System::Drawing::Size(35, 18);
			this->textBox107->TabIndex = 110;
			// 
			// textBox106
			// 
			this->textBox106->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox106->Location = System::Drawing::Point(297, 85);
			this->textBox106->Name = L"textBox106";
			this->textBox106->Size = System::Drawing::Size(35, 18);
			this->textBox106->TabIndex = 109;
			// 
			// textBox105
			// 
			this->textBox105->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox105->Location = System::Drawing::Point(297, 65);
			this->textBox105->Name = L"textBox105";
			this->textBox105->Size = System::Drawing::Size(35, 18);
			this->textBox105->TabIndex = 108;
			// 
			// textBox104
			// 
			this->textBox104->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox104->Location = System::Drawing::Point(297, 45);
			this->textBox104->Name = L"textBox104";
			this->textBox104->Size = System::Drawing::Size(35, 18);
			this->textBox104->TabIndex = 107;
			// 
			// textBox103
			// 
			this->textBox103->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox103->Location = System::Drawing::Point(297, 25);
			this->textBox103->Name = L"textBox103";
			this->textBox103->Size = System::Drawing::Size(35, 18);
			this->textBox103->TabIndex = 106;
			// 
			// textBox102
			// 
			this->textBox102->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox102->Location = System::Drawing::Point(182, 85);
			this->textBox102->Name = L"textBox102";
			this->textBox102->Size = System::Drawing::Size(35, 18);
			this->textBox102->TabIndex = 105;
			// 
			// textBox101
			// 
			this->textBox101->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox101->Location = System::Drawing::Point(182, 65);
			this->textBox101->Name = L"textBox101";
			this->textBox101->Size = System::Drawing::Size(35, 18);
			this->textBox101->TabIndex = 104;
			// 
			// textBox100
			// 
			this->textBox100->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox100->Location = System::Drawing::Point(182, 45);
			this->textBox100->Name = L"textBox100";
			this->textBox100->Size = System::Drawing::Size(35, 18);
			this->textBox100->TabIndex = 103;
			// 
			// textBox99
			// 
			this->textBox99->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox99->Location = System::Drawing::Point(182, 25);
			this->textBox99->Name = L"textBox99";
			this->textBox99->Size = System::Drawing::Size(35, 18);
			this->textBox99->TabIndex = 102;
			// 
			// textBox98
			// 
			this->textBox98->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox98->Location = System::Drawing::Point(67, 85);
			this->textBox98->Name = L"textBox98";
			this->textBox98->Size = System::Drawing::Size(35, 18);
			this->textBox98->TabIndex = 101;
			// 
			// textBox97
			// 
			this->textBox97->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox97->Location = System::Drawing::Point(67, 65);
			this->textBox97->Name = L"textBox97";
			this->textBox97->Size = System::Drawing::Size(35, 18);
			this->textBox97->TabIndex = 100;
			// 
			// textBox96
			// 
			this->textBox96->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox96->Location = System::Drawing::Point(67, 45);
			this->textBox96->Name = L"textBox96";
			this->textBox96->Size = System::Drawing::Size(35, 18);
			this->textBox96->TabIndex = 99;
			// 
			// textBox95
			// 
			this->textBox95->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 7, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(0)));
			this->textBox95->Location = System::Drawing::Point(67, 25);
			this->textBox95->Name = L"textBox95";
			this->textBox95->Size = System::Drawing::Size(35, 18);
			this->textBox95->TabIndex = 98;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(707, 322);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(102, 23);
			this->button1->TabIndex = 5;
			this->button1->Text = L"READ";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &registerView::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(705, 361);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(102, 23);
			this->button2->TabIndex = 6;
			this->button2->Text = L"WRITE";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(707, 399);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(102, 23);
			this->button3->TabIndex = 7;
			this->button3->Text = L"CLEAR";
			this->button3->UseVisualStyleBackColor = true;
			// 
			// registerView
			// 
			this->ClientSize = System::Drawing::Size(821, 430);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->groupBox5);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Name = L"registerView";
			this->Text = L"Register View";			
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &registerView::registerView_FormClosing);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->groupBox5->ResumeLayout(false);
			this->groupBox5->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
private: System::Void registerView_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
			 e->Cancel=true;
			 this->Hide();
		 }

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
//			 unsigned int temp;
//			 temp = SimpleWinUSBDemo::Form1::callForm1(5);
//			 this->MdiParent->ParentForm->ParentForm->par

//			 temp = SimpleWinUSBDemo::Form1::callForm1(4);
		 }
};
}