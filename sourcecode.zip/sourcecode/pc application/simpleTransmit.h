#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace SimpleWinUSBDemo {


	//// A simple class
	public ref class transmitCANMsgDataClass
	{
		bool newCANDataFlag;

		unsigned char tempData0;
		unsigned char tempData1;
		unsigned char tempData2;
		unsigned char tempData3;
		unsigned char tempData4;
		unsigned char tempData5;
		unsigned char tempData6;
		unsigned char tempData7;
		unsigned char tempData8;
		unsigned char tempData9;
		unsigned char tempData10;
		unsigned char tempData11;
		unsigned char tempData12;
		unsigned char tempData13;
		unsigned char tempData14;
		unsigned char tempData15;
		unsigned char tempData16;
		unsigned char tempData17;
		unsigned char tempData18;
	public:
		transmitCANMsgDataClass(void)
		{
		}

		//Transmitted CAN
		bool isThereCANData(void)
		{
			return(newCANDataFlag);
		}

		void setCANDataFlag(bool passedInBool)
		{
			newCANDataFlag = passedInBool;
		}

		void setBuffer(unsigned char data, unsigned char index)
		{
			switch(index)
			{
			case 0:
				tempData0 = data;
				break;
			case 1:
				tempData1 = data;
				break;
			case 2:
				tempData2 = data;
				break;
			case 3:
				tempData3 = data;
				break;
			case 4:
				tempData4 = data;
				break;
			case 5:
				tempData5 = data;
				break;
			case 6:
				tempData6 = data;
				break;
			case 7:
				tempData7 = data;
				break;
			case 8:
				tempData8 = data;
				break;
			case 9:
				tempData9 = data;
				break;
			case 10:
				tempData10 = data;
				break;
			case 11:
				tempData11 = data;
				break;
			case 12:
				tempData12 = data;
				break;
			case 13:
				tempData13 = data;
				break;
			case 14:
				tempData14 = data;
				break;
			case 15:
				tempData15 = data;
				break;
			case 16:
				tempData16 = data;
				break;
			case 17:
				tempData17 = data;
				break;
			case 18:
				tempData18 = data;
				break;
			default:
				break;
			}
		}


		unsigned char getBuffer(unsigned char index)
		{
			unsigned char returnValue;
			switch(index)
			{
			case 0:
				returnValue = tempData0;
				break;
			case 1:
				returnValue = tempData1;
				break;
			case 2:
				returnValue = tempData2;
				break;
			case 3:
				returnValue = tempData3;
				break;
			case 4:
				returnValue = tempData4;
				break;
			case 5:
				returnValue = tempData5;
				break;
			case 6:
				returnValue = tempData6;
				break;
			case 7:
				returnValue = tempData7;
				break;
			case 8:
				returnValue = tempData8;
				break;
			case 9:
				returnValue = tempData9;
				break;
			case 10:
				returnValue = tempData10;
				break;
			case 11:
				returnValue = tempData11;
				break;
			case 12:
				returnValue = tempData12;
				break;
			case 13:
				returnValue = tempData13;
				break;
			case 14:
				returnValue = tempData14;
				break;
			case 15:
				returnValue = tempData15;
				break;
			case 16:
				returnValue = tempData16;
				break;
			case 17:
				returnValue = tempData17;
				break;
			case 18:
				returnValue = tempData18;
				break;
			default:
				break;
			}
			return(returnValue);
		}

	}; //class transmitCANMsgDataClass




	extern unsigned char userSelectedIDFormat;
	extern unsigned char userSelectedDataFormat;
#include "Globals.h"
	/// <summary>
	/// Summary for simpleTransmit
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class simpleTransmit : public System::Windows::Forms::Form
	{
	public:
		transmitCANMsgDataClass ^t1;
		array<unsigned int, 2 >^ periodicRepeatTransmitTracker;




	private: System::Windows::Forms::DataGridViewComboBoxColumn^  Column2;
	public: 
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column5;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column6;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column7;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column8;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column9;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column10;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column11;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column12;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column13;
	private: System::Windows::Forms::DataGridViewButtonColumn^  Column14;
	private: System::Windows::Forms::Timer^  PeriodicMessage;

			 static unsigned char userEnteredTotalFormat;
	public:		
		simpleTransmit(transmitCANMsgDataClass^ passedt)
		{
			t1 = passedt;

			periodicRepeatTransmitTracker = gcnew array< unsigned int, 2 >(dNUMBER_OF_PERIODIC_MSGS,dNUMBER_OF_PERIODIC_REPEAT_VARS);
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			//Add the option of "HEX" or "DEC" to the transmit format column
			unsigned char rowIndex;
			this->dataGridView1->Rows->Add(dNUMBER_OF_PERIODIC_MSGS);
			rowIndex = 0;
			while(rowIndex < dNUMBER_OF_PERIODIC_MSGS)
			{
				////dataGridViewComboBoxCell
				//				 tempComboBox->Items->Add("HEX");
				//				 tempComboBox->Items->Add("DEC");
				//				 this->dataGridView1->Rows[rowIndex]->Cells[0] = tempComboBox;

				this->dataGridView1->Rows[rowIndex]->Cells[0]->Value="HEX";
				this->dataGridView1->Rows[rowIndex]->Cells[11]->Value="0";
				this->dataGridView1->Rows[rowIndex]->Cells[12]->Value="0";
				this->dataGridView1->Rows[rowIndex]->Cells[13]->Value="Send";
				rowIndex++;
			}
			PeriodicMessage->Start();
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~simpleTransmit()
		{
			if (components)
			{
				delete components;
			}
		}
	public: System::Windows::Forms::DataGridView^  dataGridView1;
	protected: 


	private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  clearWindowToolStripMenuItem;


	private: System::ComponentModel::IContainer^  components;


	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>

		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewComboBoxColumn());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column5 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column6 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column7 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column8 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column9 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column10 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column11 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column12 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column13 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column14 = (gcnew System::Windows::Forms::DataGridViewButtonColumn());
			this->contextMenuStrip1 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->clearWindowToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->PeriodicMessage = (gcnew System::Windows::Forms::Timer(this->components));
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->contextMenuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->AllowUserToResizeColumns = false;
			this->dataGridView1->AllowUserToResizeRows = false;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::DisableResizing;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(14) {this->Column2, 
				this->Column1, this->Column3, this->Column4, this->Column5, this->Column6, this->Column7, this->Column8, this->Column9, this->Column10, 
				this->Column11, this->Column12, this->Column13, this->Column14});
			this->dataGridView1->ContextMenuStrip = this->contextMenuStrip1;
			this->dataGridView1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->dataGridView1->Location = System::Drawing::Point(0, 0);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersVisible = false;
			this->dataGridView1->RowHeadersWidthSizeMode = System::Windows::Forms::DataGridViewRowHeadersWidthSizeMode::DisableResizing;
			this->dataGridView1->Size = System::Drawing::Size(919, 224);
			this->dataGridView1->TabIndex = 0;
			this->dataGridView1->CellClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &simpleTransmit::dataGridView1_CellClick);
			this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &simpleTransmit::dataGridView1_CellContentClick);
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"FORMAT";
			this->Column2->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"HEX", L"DEC"});
			this->Column2->Name = L"Column2";
			this->Column2->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column2->Width = 65;
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"ID";
			this->Column1->Name = L"Column1";
			this->Column1->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column1->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"DLC";
			this->Column3->Name = L"Column3";
			this->Column3->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column3->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column3->Width = 55;
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"DATA 0";
			this->Column4->Name = L"Column4";
			this->Column4->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column4->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column4->Width = 55;
			// 
			// Column5
			// 
			this->Column5->HeaderText = L"DATA 1";
			this->Column5->Name = L"Column5";
			this->Column5->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column5->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column5->Width = 55;
			// 
			// Column6
			// 
			this->Column6->HeaderText = L"DATA 2";
			this->Column6->Name = L"Column6";
			this->Column6->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column6->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column6->Width = 55;
			// 
			// Column7
			// 
			this->Column7->HeaderText = L"DATA 3";
			this->Column7->Name = L"Column7";
			this->Column7->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column7->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column7->Width = 55;
			// 
			// Column8
			// 
			this->Column8->HeaderText = L"DATA 4";
			this->Column8->Name = L"Column8";
			this->Column8->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column8->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column8->Width = 55;
			// 
			// Column9
			// 
			this->Column9->HeaderText = L"DATA 5";
			this->Column9->Name = L"Column9";
			this->Column9->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column9->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column9->Width = 55;
			// 
			// Column10
			// 
			this->Column10->HeaderText = L"DATA 6";
			this->Column10->Name = L"Column10";
			this->Column10->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column10->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column10->Width = 55;
			// 
			// Column11
			// 
			this->Column11->HeaderText = L"DATA 7";
			this->Column11->Name = L"Column11";
			this->Column11->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column11->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column11->Width = 55;
			// 
			// Column12
			// 
			this->Column12->HeaderText = L"PERIOD (msec)";
			this->Column12->Name = L"Column12";
			this->Column12->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column12->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			// 
			// Column13
			// 
			this->Column13->HeaderText = L"REPEAT";
			this->Column13->Name = L"Column13";
			this->Column13->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column13->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column13->Width = 55;
			// 
			// Column14
			// 
			this->Column14->HeaderText = L"TRANSMIT";
			this->Column14->Name = L"Column14";
			this->Column14->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			// 
			// contextMenuStrip1
			// 
			this->contextMenuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->clearWindowToolStripMenuItem});
			this->contextMenuStrip1->Name = L"contextMenuStrip1";
			this->contextMenuStrip1->Size = System::Drawing::Size(179, 26);
			// 
			// clearWindowToolStripMenuItem
			// 
			this->clearWindowToolStripMenuItem->Name = L"clearWindowToolStripMenuItem";
			this->clearWindowToolStripMenuItem->Size = System::Drawing::Size(178, 22);
			this->clearWindowToolStripMenuItem->Text = L"Clear Window";
			this->clearWindowToolStripMenuItem->Click += gcnew System::EventHandler(this, &simpleTransmit::clearWindowToolStripMenuItem_Click);
			// 
			// PeriodicMessage
			// 
			this->PeriodicMessage->Interval = 10;
			this->PeriodicMessage->Tick += gcnew System::EventHandler(this, &simpleTransmit::PeriodicMessage_Tick);
			// 
			// simpleTransmit
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(919, 224);
			this->Controls->Add(this->dataGridView1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"simpleTransmit";
			this->Text = L"Transmit";
			this->Load += gcnew System::EventHandler(this, &simpleTransmit::simpleTransmit_Load);
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &simpleTransmit::simpleTransmit_FormClosing);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->contextMenuStrip1->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void simpleTransmit_Load(System::Object^  sender, System::EventArgs^  e) {
			 }
	private: System::Void clearWindowToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 unsigned char rowIndex;
				 this->dataGridView1->Rows->Clear();
				 this->dataGridView1->Rows->Add(dNUMBER_OF_PERIODIC_MSGS);
				 rowIndex = 0;
				 while(rowIndex < dNUMBER_OF_PERIODIC_MSGS)
				 {
					 this->dataGridView1->Rows[rowIndex]->Cells[0]->Value="HEX";
					 this->dataGridView1->Rows[rowIndex]->Cells[11]->Value="0";
					 this->dataGridView1->Rows[rowIndex]->Cells[12]->Value="0";
					 this->dataGridView1->Rows[rowIndex]->Cells[13]->Value="Send";
					 periodicRepeatTransmitTracker[rowIndex,dPERIODIC_FLAG] = 0;
					 this->dataGridView1->Rows[rowIndex]->ReadOnly=false;
					 rowIndex++;
				 }
			 }
	private: System::Void simpleTransmit_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
				 e->Cancel=true;
				 this->Hide();
			 }
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
				 String^ MyString;
				 int result;
				 String^ resultString;
				 bool nullCheckPassed;
				 bool dataCheckPassed;
				 bool extendedFlag;
				 unsigned int eventColumnIndex;
				 unsigned int eventRowIndex;

				 unsigned char CheckSum = 0;
				 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
				 unsigned int counter;

				 unsigned long tempID;
				 unsigned char tempSIDH;
				 unsigned char tempSIDL;
				 unsigned char tempEIDH;
				 unsigned char tempEIDL;
				 unsigned char tempDLC;
				 unsigned char tempDATA0;
				 unsigned char tempDATA1;
				 unsigned char tempDATA2;
				 unsigned char tempDATA3;
				 unsigned char tempDATA4;
				 unsigned char tempDATA5;
				 unsigned char tempDATA6;
				 unsigned char tempDATA7;
				 unsigned char tempSentFromButtonX;
				 unsigned int tempData[dSPI_CAN_PACKET_SIZE];
				 unsigned char tempPeriodHigh;
				 unsigned char tempPeriodLow;
				 unsigned char tempRepeat;
				 unsigned int tempPeriod;

				 eventColumnIndex = e->ColumnIndex;
				 eventRowIndex = e->RowIndex;

				 //Check if the user clicked on the "button" cell and if clicked
				 //Check the rows contents against view type (Hex/Dec) and Rangeso check the row contect
				 if(eventColumnIndex == dBUTTON_OR_COUNT_COLUMN_INDEX)
				 {

					 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dBUTTON_OR_COUNT_COLUMN_INDEX]->Value == "Stop")
					 {
						 this->dataGridView1->Rows[eventRowIndex]->Cells[dBUTTON_OR_COUNT_COLUMN_INDEX]->Value = "Send";
						 periodicRepeatTransmitTracker[eventRowIndex,dPERIODIC_FLAG] = 0;
						 this->dataGridView1->Rows[eventRowIndex]->ReadOnly=false;
					 }
					 else
					 {

						 nullCheckPassed = false;
						 //Quick check to see if items are Null
						 if(this->dataGridView1->Rows[eventRowIndex]->Cells[dID_COLUMN_INDEX]->Value != nullptr)
						 {
							 if(this->dataGridView1->Rows[eventRowIndex]->Cells[dDLC_COLUMN_INDEX]->Value != nullptr)
							 {
								 //DLC is NOT NULL...
								 if(this->dataGridView1->Rows[eventRowIndex]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Value != nullptr)
								 {
									 if(this->dataGridView1->Rows[eventRowIndex]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Value != nullptr)
									 {
										 //read out the DLC
										 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDLC_COLUMN_INDEX]->Value->ToString();
										 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DLC,userEnteredTotalFormat))
										 {
											 //SaveOffthe DLC result and clear backcolor
											 //							 this->dataGridView1->Rows[eventRowIndex]->Cells[dDLC_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 tempDLC = result;
											 //Then check data
											 switch(tempDLC)
											 {
											 case 0:
												 //There is no data to test
												 nullCheckPassed = true;
												 break;
											 case 1: //Data 0
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 nullCheckPassed = true;
												 }
												 break;

											 case 2: //Data 1
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
													 {
														 nullCheckPassed = true;
													 }
												 }
												 break;

											 case 3: //Data 2
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value != nullptr)
													 {
														 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value != nullptr)
														 {
															 nullCheckPassed = true;
														 }
													 }
												 }
											 case 4: //Data 3
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value != nullptr)
													 {
														 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value != nullptr)
														 {
															 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value != nullptr)
															 {
																 nullCheckPassed = true;
															 }
														 }
													 }
												 }
												 break;

											 case 5: //Data 4
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value != nullptr)
													 {
														 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value != nullptr)
														 {
															 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value != nullptr)
															 {
																 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value != nullptr)
																 {
																	 nullCheckPassed = true;
																 }
															 }
														 }
													 }
												 }
												 break;


											 case 6: //Data 5
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value != nullptr)
													 {
														 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value != nullptr)
														 {
															 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value != nullptr)
															 {
																 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value != nullptr)
																 {
																	 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value != nullptr)
																	 {
																		 nullCheckPassed = true;
																	 }
																 }
															 }
														 }
													 }
												 }
												 break;

											 case 7: //Data 6
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value != nullptr)
													 {
														 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value != nullptr)
														 {
															 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value != nullptr)
															 {
																 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value != nullptr)
																 {
																	 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value != nullptr)
																	 {
																		 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value != nullptr)
																		 {
																			 nullCheckPassed = true;
																		 }
																	 }
																 }
															 }
														 }
													 }
												 }
												 break;

											 case 8: //Data 7
												 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value != nullptr)
												 {
													 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value != nullptr)
													 {
														 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value != nullptr)
														 {
															 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value != nullptr)
															 {
																 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value != nullptr)
																 {
																	 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value != nullptr)
																	 {
																		 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value != nullptr)
																		 {
																			 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value != nullptr)
																			 {
																				 nullCheckPassed = true;
																			 }
																		 }
																	 }
																 }
															 }
														 }
													 }
												 }
												 break;
											 default:
												 nullCheckPassed = false;
												 break;
											 } //switch

											 if (nullCheckPassed == false)
											 {
												 System::Windows::Forms::MessageBox::Show("ERROR 3.20.0\nDATA field is empty", "Input Error");
											 }

										 }
										 else
										 {
											 //Don't check the data until the DLC is valid
										 }
									 }//repeat
									 else
									 {
										 System::Windows::Forms::MessageBox::Show("ERROR 3.40.0\nREPEAT field is empty", "Input Error");
									 }

								 }//period
								 else
								 {
									 //Notify user that DLC can not be null
									 System::Windows::Forms::MessageBox::Show("ERROR 3.30.0\nPERIOD field is empty", "Input Error");
								 }
							 }
							 else
							 {
								 //Notify user that DLC can not be null
								 System::Windows::Forms::MessageBox::Show("ERROR 3.10.0\nDLC field is empty", "Input Error");
							 }
						 }
						 else
						 {
							 //Notify user that ID can not be null
							 System::Windows::Forms::MessageBox::Show("ERROR 3.00.0\nID field is empty", "Input Error");
						 }



						 ///////////////////////////////////////////////////
						 ///////////////////////////////////////////////////
						 //End Null Check








						 if(nullCheckPassed == true)
						 {
							 for(unsigned char cellIndex = 0;cellIndex < dBUTTON_OR_COUNT_COLUMN_INDEX; cellIndex++)
							 {
								 this->dataGridView1->Rows[eventRowIndex]->Cells[cellIndex]->Style->BackColor = System::Drawing::Color::White;
							 }


							 //					 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Selected==0)
							 if (this->dataGridView1->Rows[eventRowIndex]->Cells[dFORMAT_OR_DIRECTION_COLUMN_INDEX]->Value=="HEX")
							 {
								 userEnteredTotalFormat = dNUMBER_FORMAT_HEX;
							 }
							 else
							 {
								 userEnteredTotalFormat = dNUMBER_FORMAT_DECIMAL;
							 }

							 //read out the ID
							 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dID_COLUMN_INDEX]->Value->ToString();
							 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_ID,userEnteredTotalFormat))
							 {
								 extendedFlag = isIdExtended(MyString);
								 //SaveOffthe ID result and clear backcolor
								 tempID = result;
								 //						 this->dataGridView1->Rows[eventRowIndex]->Cells[dID_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;

								 //read out the DLC
								 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDLC_COLUMN_INDEX]->Value->ToString();
								 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DLC,userEnteredTotalFormat))
								 {
									 //SaveOffthe DLC result and clear backcolor
									 //							 this->dataGridView1->Rows[eventRowIndex]->Cells[dDLC_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
									 tempDLC = result;


									 //read out the Period
									 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Value->ToString();
									 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_PERIOD,userEnteredTotalFormat))
									 {
										 //							 this->dataGridView1->Rows[eventRowIndex]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
										 tempPeriod = result;

										 //read out the Repeat
										 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Value->ToString();
										 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_REPEAT,userEnteredTotalFormat))
										 {
											 //							 this->dataGridView1->Rows[eventRowIndex]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 tempRepeat = result;


											 dataCheckPassed = false;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
											 tempDATA0 = 0;
											 tempDATA1 = 0;
											 tempDATA2 = 0;
											 tempDATA3 = 0;
											 tempDATA4 = 0;
											 tempDATA5 = 0;
											 tempDATA6 = 0;
											 tempDATA7 = 0;

											 switch(tempDLC)
											 {
											 case 0:
												 //There is no data to test
												 dataCheckPassed = true;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value = "";
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
												 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
												 break;
											 case 1: //Data 0
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 dataCheckPassed = true;

													 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value = "";
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
												 }
												 else
												 {
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;

											 case 2: //Data 1
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value->ToString();
													 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
													 {
														 tempDATA1 = result;
														 dataCheckPassed = true;

														 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
														 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value = "";
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
													 }
													 else
													 {
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
													 }

												 }
												 else
												 {
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;

											 case 3: //Data 2
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value->ToString();
													 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
													 {
														 tempDATA1 = result;
														 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value->ToString();
														 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
														 {
															 tempDATA2 = result;
															 dataCheckPassed = true;

															 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
															 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
															 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value = "";
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
														 }
														 else
														 {
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
														 }
													 }
													 else
													 {
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
													 }
												 }
												 else
												 {
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;

											 case 4: //Data 3
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value->ToString();
													 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
													 {
														 tempDATA1 = result;
														 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value->ToString();
														 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
														 {
															 tempDATA2 = result;
															 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value->ToString();
															 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
															 {
																 tempDATA3 = result;
																 dataCheckPassed = true;

																 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value = "";
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
															 }
															 else
															 {
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
															 }
														 }
														 else
														 {
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
														 }
													 }
													 else
													 {
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
													 }
												 }
												 else
												 {
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;

											 case 5: //Data 4
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value->ToString();
													 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
													 {
														 tempDATA1 = result;
														 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value->ToString();
														 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
														 {
															 tempDATA2 = result;
															 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value->ToString();
															 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
															 {
																 tempDATA3 = result;
																 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value->ToString();
																 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																 {
																	 tempDATA4 = result;
																	 dataCheckPassed = true;

																	 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																	 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																	 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																	 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																	 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value = "";
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";
																 }
																 else
																 {
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																 }
															 }
															 else
															 {
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
															 }
														 }
														 else
														 {
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
														 }
													 }
													 else
													 {
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
													 }
												 }
												 else
												 {
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;


											 case 6: //Data 5
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value->ToString();
													 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
													 {
														 tempDATA1 = result;
														 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value->ToString();
														 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
														 {
															 tempDATA2 = result;
															 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value->ToString();
															 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
															 {
																 tempDATA3 = result;
																 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value->ToString();
																 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																 {
																	 tempDATA4 = result;
																	 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value->ToString();
																	 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																	 {
																		 tempDATA5 = result;
																		 dataCheckPassed = true;
																		 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																		 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																		 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																		 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																		 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																		 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;														 
																		 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																		 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																		 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value = "";
																		 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";

																	 }
																	 else
																	 {

																		 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																	 }
																 }
																 else
																 {
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																 }
															 }
															 else
															 {
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
															 }
														 }
														 else
														 {
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
														 }
													 }
													 else
													 {
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
													 }
												 }
												 else
												 {
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;

											 case 7: //Data 6
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value->ToString();
													 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
													 {
														 tempDATA1 = result;
														 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value->ToString();
														 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
														 {
															 tempDATA2 = result;
															 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value->ToString();
															 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
															 {
																 tempDATA3 = result;
																 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value->ToString();
																 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																 {
																	 tempDATA4 = result;
																	 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value->ToString();
																	 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																	 {
																		 tempDATA5 = result;
																		 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value->ToString();
																		 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																		 {
																			 tempDATA6 = result;
																			 dataCheckPassed = true;

																			 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																			 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																			 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																			 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																			 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																			 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																			 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																			 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Gray;
																			 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value = "";

																		 }
																		 else
																		 {
																			 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																		 }
																	 }
																	 else
																	 {
																		 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																	 }
																 }
																 else
																 {
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																 }
															 }
															 else
															 {
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
															 }
														 }
														 else
														 {
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
														 }
													 }
													 else
													 {
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
													 }
												 }
												 else
												 {
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;

											 case 8: //Data 7
												 //read out the DATA
												 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Value->ToString();
												 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
												 {
													 tempDATA0 = result;
													 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Value->ToString();
													 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
													 {
														 tempDATA1 = result;
														 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Value->ToString();
														 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
														 {
															 tempDATA2 = result;
															 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Value->ToString();
															 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
															 {
																 tempDATA3 = result;
																 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Value->ToString();
																 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																 {
																	 tempDATA4 = result;
																	 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Value->ToString();
																	 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																	 {
																		 tempDATA5 = result;
																		 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Value->ToString();
																		 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																		 {
																			 tempDATA6 = result;
																			 MyString = this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Value->ToString();
																			 if (isInputValid(MyString,result,resultString,dINPUT_TYPE_DATA,userEnteredTotalFormat))
																			 {
																				 tempDATA7 = result;
																				 dataCheckPassed = true;

																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;
																				 //this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::White;

																			 }
																			 else
																			 {
																				 //Dirty the ID Cell
																				 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA7_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																			 }
																		 }
																		 else
																		 {
																			 //Dirty the ID Cell
																			 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA6_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																		 }
																	 }
																	 else
																	 {
																		 //Dirty the ID Cell
																		 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA5_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																	 }
																 }
																 else
																 {
																	 //Dirty the ID Cell
																	 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA4_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
																 }
															 }
															 else
															 {
																 //Dirty the ID Cell
																 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA3_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
															 }
														 }
														 else
														 {
															 //Dirty the ID Cell
															 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA2_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
														 }
													 }
													 else
													 {
														 //Dirty the ID Cell
														 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA1_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
													 }
												 }
												 else
												 {
													 //Dirty the ID Cell
													 this->dataGridView1->Rows[eventRowIndex]->Cells[dDATA0_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
												 }
												 break;
											 default:
												 dataCheckPassed = false;
												 break;
											 } //switch


										 }//
										 else
										 {
											 //Dirty the REPEAT Cell
											 this->dataGridView1->Rows[eventRowIndex]->Cells[dREPEAT_OR_DELTA_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
										 }

									 }//
									 else
									 {
										 //Dirty the PERIOD Cell
										 this->dataGridView1->Rows[eventRowIndex]->Cells[dPERIOD_OR_TIMESTAMP_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
									 }

								 }
								 else
								 {
									 //Dirty the DLC Cell
									 this->dataGridView1->Rows[eventRowIndex]->Cells[dDLC_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
								 }
							 }
							 else
							 {
								 //Dirty the ID Cell
								 this->dataGridView1->Rows[eventRowIndex]->Cells[dID_COLUMN_INDEX]->Style->BackColor = System::Drawing::Color::Yellow;
								 //clear all out others
							 }
						 }



						 //If everything Checks out...
						 //lock the row if it is a periodic message
						 //Update the Format column (this should be ReadOnly
						 //Change the text on the button to "Stop"

						 //#define dFORMAT_COLUMN_INDEX 1

						 if (dataCheckPassed == true)
						 {
							 if (tempPeriod != 0)
							 {
								 //						 Lock eventRowIndex Row
								 this->dataGridView1->Rows[eventRowIndex]->ReadOnly=true;
								 this->dataGridView1->Rows[eventRowIndex]->Cells[13]->Value="Stop";

								 periodicRepeatTransmitTracker[eventRowIndex,dPERIODIC_VALUE]=tempPeriod;
								 periodicRepeatTransmitTracker[eventRowIndex,dCOUNTDOWN_COUNTER] = periodicRepeatTransmitTracker[eventRowIndex,dPERIODIC_VALUE];

								 tempSIDH = 0;
								 tempSIDL = 0;
								 tempEIDH = 0;
								 tempEIDL = 0;

								 //break out tempID into SIDH / SIDL / EIDH / EIDL
								 breakOutIDintoHex(extendedFlag,tempID,tempSIDH,tempSIDL,tempEIDH,tempEIDL);


								 //Setup message for either a periodic or a periodic-repeat
								 periodicRepeatTransmitTracker[eventRowIndex,dCOMMAND] = dTRANSMIT_MESSAGE_EV; //Command
								 periodicRepeatTransmitTracker[eventRowIndex,dEIDH] = tempEIDH;                //EIDH
								 periodicRepeatTransmitTracker[eventRowIndex,dEIDL] = tempEIDL;//EIDL
								 periodicRepeatTransmitTracker[eventRowIndex,dSIDH] = tempSIDH;//SIDH
								 periodicRepeatTransmitTracker[eventRowIndex,dSIDL] = tempSIDL;//SIDL
								 periodicRepeatTransmitTracker[eventRowIndex,dDLC] = tempDLC;//DLC
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA0] = tempDATA0;
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA1] = tempDATA1;
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA2] = tempDATA2;
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA3] = tempDATA3;
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA4] = tempDATA4;
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA5] = tempDATA5;
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA6] = tempDATA6;
								 periodicRepeatTransmitTracker[eventRowIndex,dDATA7] = tempDATA7;

								 if (tempRepeat != 0)
								 {
									 periodicRepeatTransmitTracker[eventRowIndex,dREPEAT_VALUE] = tempRepeat;
									 periodicRepeatTransmitTracker[eventRowIndex,dPERIODIC_FLAG] = 2;
								 }
								 else
								 {
									 periodicRepeatTransmitTracker[eventRowIndex,dPERIODIC_FLAG] = 1;
								 }
							 }
							 else
							 {
								 //Transmit single message
								 //////////////////////////////////////////////////////////////////
								 tempSIDH = 0;
								 tempSIDL = 0;
								 tempEIDH = 0;
								 tempEIDL = 0;

								 //break out tempID into SIDH / SIDL / EIDH / EIDL
								 breakOutIDintoHex(extendedFlag,tempID,tempSIDH,tempSIDL,tempEIDH,tempEIDL);

								 //Hard code the command for now... may need set this along with the period and repeat later
								 tempData[0] = dTRANSMIT_MESSAGE_EV; //Command
								 tempData[1] = tempEIDH;//0x01; //EIDH
								 tempData[2] = tempEIDL;//0x00; //EIDL
								 tempData[3] = tempSIDH;//0x00; //SIDH
								 tempData[4] = tempSIDL;//0x00; //SIDL
								 tempData[5] = tempDLC;//0x08; //tempDLC

								 tempData[6] = tempDATA0;
								 tempData[7] = tempDATA1;
								 tempData[8] = tempDATA2;
								 tempData[9] = tempDATA3;
								 tempData[10] = tempDATA4;
								 tempData[11] = tempDATA5;
								 tempData[12] = tempDATA6;
								 tempData[13] = tempDATA7;

								 tempSentFromButtonX = eventRowIndex;
								 tempData[14] = tempSentFromButtonX;
								 tempData[15] = 0;//tempPeriodHigh;	Not used for a single shot
								 tempData[16] = 0;//tempPeriodLow;	Not used for a single shot
								 tempData[17] = 0;//tempRepeat;		Not used for a single shot
								 processTransmitMessages(tempData);
								 //////////////////////////////////////////////////////////////////
							 }
						 }
						 else
						 {
							 //dataCheckPassed didn't pass
						 }
					 }
				 }
				 else
				 {
					 //On a cell click event... set the cell to white
				 }
			 }








			 ////Compute checksum byte
			 //for(counter = 2; counter < 20; counter++) //2 - Start checksum at Command, 19 last byte of timestamp, 20 is checksum byte
			 //{
			 // CheckSum += OutputPacketBuffer[counter];
			 //}
			 ////Checksum byte
			 //OutputPacketBuffer[18] = CheckSum;


			 ///////////////////////////////////////////////////////////////////////////////////
			 bool processTransmitMessages(unsigned int passedInTempData[])
			 {
				 unsigned int BytesWritten = 0;
				 static unsigned char counter = 0;
				 unsigned char CheckSum = 0;
				 unsigned char OutputPacketBuffer[64];	//Allocate a memory buffer which will contain data to send to the USB device
				 unsigned int i;
				 bool returnValue;

				 returnValue = false;

				 //Initialize the buffer contents to all 0x00
				 while(BytesWritten < 64)
				 {
					 OutputPacketBuffer[BytesWritten] = 0;
					 BytesWritten++;
				 }

				 //		 OutputPacketBuffer[0] = 0x55; //header
				 //		 OutputPacketBuffer[1] = 0x46; //header
				 OutputPacketBuffer[0] = passedInTempData[0]; //Command like dTRANSMIT_MESSAGE_EV
				 OutputPacketBuffer[1] = passedInTempData[1];
				 OutputPacketBuffer[2] = passedInTempData[2];
				 OutputPacketBuffer[3] = passedInTempData[3];
				 OutputPacketBuffer[4] = passedInTempData[4];
				 OutputPacketBuffer[5] = passedInTempData[5];
				 OutputPacketBuffer[6] = passedInTempData[6];
				 OutputPacketBuffer[7] = passedInTempData[7];
				 OutputPacketBuffer[8] = passedInTempData[8];
				 OutputPacketBuffer[9] = passedInTempData[9];
				 OutputPacketBuffer[10] = passedInTempData[10];
				 OutputPacketBuffer[11] = passedInTempData[11];
				 OutputPacketBuffer[12] = passedInTempData[12];
				 OutputPacketBuffer[13] = passedInTempData[13];
				 OutputPacketBuffer[14] = passedInTempData[14];
				 OutputPacketBuffer[15] = passedInTempData[15];
				 OutputPacketBuffer[16] = passedInTempData[16];
				 OutputPacketBuffer[17] = passedInTempData[17];

				 //Compute checksum byte
				 for(i = 0; i < dSPI_CAN_PACKET_SIZE; i++) //2 - Start checksum at Command, 19 last byte of timestamp, 20 is checksum byte
				 {
					 CheckSum += OutputPacketBuffer[i];
				 }
				 //Checksum byte
				 OutputPacketBuffer[dSPI_CAN_PACKET_CHECKSUM_LOCATION] = CheckSum;

				 //Copy all of this over to the transmitCANMsgDataClass
				 if (t1->isThereCANData() != true)
				 {
					 //currently the buffer is empty
					 for(counter = 0; counter < dSPI_CAN_PACKET_SIZE; counter++)
					 {
						 t1->setBuffer(OutputPacketBuffer[counter],counter);
					 }
					 t1->setCANDataFlag(true);
					 returnValue = true;
				 }
				 return(returnValue);
			 }
			 ///////////////////////////////////////////////////////////////////////////////////



			 void breakOutIDintoHex(bool passedInExtendedFlag,unsigned int passedInID, unsigned char % passedInSIDH,unsigned char % passedInSIDL,unsigned char % passedInEIDH,unsigned char % passedInEIDL)
			 {
				 unsigned int tempPassedInID;
				 unsigned char wipSIDL;

				 tempPassedInID = passedInID;

				 if (passedInExtendedFlag == true)
				 {
					 ////Extended messsage (29bits)
					 ////SIDH + upper three bits SIDL (3rd bit needs to be set) lower two bits + EIDH + EIDL
					 ////CAN_standardHi_ID + CAN_standardLo_ID + CAN_extendedHi_ID + CAN_extendedLo_ID
					 ////Set the SIDL bit and convert as if a extended message
					 //		   // sHi       / sLo    / eHi       / eLo
					 //		   // 1111 1111 / 111 11 / 1111 1111 / 1111 1111
					 //            00001111 222x3x33 44445555 66667777
					 //            sidh       sidl      eidh      eidl


					 //EIDL
					 passedInEIDL = 0xFF & tempPassedInID; //CAN_extendedLo_ID_TX1 = &HFF And CAN_UserEnter_ID_TX1
					 tempPassedInID = tempPassedInID >>8; //CAN_UserEnter_ID_TX1 = CAN_UserEnter_ID_TX1 >> 8

					 //EIDH
					 passedInEIDH = 0xFF &  tempPassedInID; //CAN_extendedHi_ID_TX1 = &HFF And CAN_UserEnter_ID_TX1
					 tempPassedInID = tempPassedInID >> 8;  //CAN_UserEnter_ID_TX1 = CAN_UserEnter_ID_TX1 >> 8

					 //SIDL
					 //push back 5 and or it
					 wipSIDL = 0x03 & tempPassedInID;
					 tempPassedInID = tempPassedInID << 3; //CAN_UserEnter_ID_TX1 = CAN_UserEnter_ID_TX1 << 3
					 wipSIDL = (0xE0 & tempPassedInID) + wipSIDL;
					 wipSIDL = wipSIDL + 0x08; // TEMP_CAN_standardLo_ID_TX1 = TEMP_CAN_standardLo_ID_TX1 + &H8
					 passedInSIDL = 0xEB & wipSIDL; //CAN_standardLo_ID_TX1 = &HEB And TEMP_CAN_standardLo_ID_TX1

					 //SIDH
					 tempPassedInID = tempPassedInID >> 8;
					 passedInSIDH = 0xFF & tempPassedInID;
				 }
				 else
				 {
					 ////Standard message (11 bits)
					 ////EIDH = 0 + EIDL = 0 + SIDH + upper three bits SIDL (3rd bit needs to be clear)
					 ////1111 1111 111
					 passedInEIDH = 0;
					 passedInEIDL = 0;
					 tempPassedInID = tempPassedInID << 5;
					 passedInSIDL = 0xFF & tempPassedInID;
					 tempPassedInID = tempPassedInID >> 8;
					 passedInSIDH = 0xFF & tempPassedInID;
				 }
			 }


			 bool isIdExtended(String^ input)
			 {
				 bool returnValue;
				 if((input->EndsWith("x")) || (input->EndsWith("X")))
				 {//Extended
					 returnValue = true;
				 }
				 else
				 {
					 returnValue = false;
				 }
				 return(returnValue);
			 }







			 bool isInputValid(String^ input, int % result,String^ % resultString, unsigned char inputType, unsigned char passInuserEnteredTotalFormat)
			 {
				 bool returnValue;
				 returnValue = false;
				 array<Char>^ myTrimChar = {'x','X',' '};
				 System::IFormatProvider^ tempFormatProvider;

				 if (input == "")
				 {
					 System::Windows::Forms::MessageBox::Show("ERROR 4.75.0\nRequired input for CAN Message is empty" , "Input Error");
				 }
				 else if (input == nullptr)
				 {
					 System::Windows::Forms::MessageBox::Show("ERROR 4.75.1\nRequired input for CAN Message is empty" , "Input Error");
				 }
				 //First Check: Is the input empty
				 else
				 {



					 switch(inputType)
					 {
						 /////////////////////////////////
						 /////////////////////////////////
						 /////////////////////////////////
					 case dINPUT_TYPE_ID: //ID
						 //Second Check: Check to see if it is an extended or standard ID
						 if((input->EndsWith("x")) ||
							 (input->EndsWith("X")) ||
							 (input->EndsWith(" ")))
						 {//Extended
							 //Third Check: Check to see if it is a valid extended ID
							 input = input->TrimEnd(myTrimChar);
							 if(passInuserEnteredTotalFormat == dNUMBER_FORMAT_HEX) //hex
							 {
								 //					if(System::Int32::TryParse(input,System::Globalization::NumberStyles::HexNumber, Globalization::CultureInfo("en-US"),result))
								 if(System::Int32::TryParse(input,System::Globalization::NumberStyles::HexNumber,tempFormatProvider,result))
								 {
									 //Forth Check: Check the range of the ID
									 if ((result < 536870912) && (result >= 0))
									 {
										 resultString = "0x"+result.ToString("X2")+"x";
										 returnValue = true;
									 }
									 else
									 {
										 System::Windows::Forms::MessageBox::Show("ERROR 4.00.0\nEnter the Extended ID within the following range\n(0x - 1FFFFFFFx)", "Input Error");
									 }
								 }
								 else
								 {
									 System::Windows::Forms::MessageBox::Show("ERROR 4.00.1\nEnter the Extended ID within the following range\n(0x - 1FFFFFFFx)", "Input Error");
								 }
							 }
							 else //Decimal
							 {
								 if(System::Int32::TryParse(input,result)) //Parses for decimal
								 {
									 //Forth Check: Check the range of the ID
									 if ((result < 536870912) && (result >= 0))
									 {
										 resultString = result.ToString()+"x";
										 returnValue = true;
									 }
									 else
									 {
										 System::Windows::Forms::MessageBox::Show("ERROR 4.02.0\nEnter the Extended ID within the following range\n(0x - 536870911x)", "Input Error");
									 }
								 }
								 else
								 {
									 System::Windows::Forms::MessageBox::Show("ERROR 4.02.1\nEnter the Extended ID within the following range\n(0x - 536870911x)", "Input Error");
								 }
							 }
						 }
						 else
						 {//standard
							 //Third Check: Check to see if it is a valid standard ID
							 if(passInuserEnteredTotalFormat == dNUMBER_FORMAT_HEX) //hex
							 {
								 //					if(System::Int32::TryParse(input,System::Globalization::NumberStyles::HexNumber, Globalization::CultureInfo("en-US"),result))
								 //					if(System::Int32::TryParse(input,System::Globalization::NumberStyles::HexNumber, Globalization::CultureInfo("en-US"),result))
								 if(System::Int32::TryParse(input,System::Globalization::NumberStyles::HexNumber,tempFormatProvider,result))
									 //					if(System::Int32::TryParse(input,result))
								 {
									 //Forth Check: Check the range of the ID
									 if ((result < 2048) && (result >= 0))
									 {
										 resultString = "0x"+result.ToString("X2");
										 returnValue = true;
									 }
									 else
									 {
										 System::Windows::Forms::MessageBox::Show("ERROR 4.04.0\nEnter the Standard ID within the following range\n(0 - 7FF)", "Input Error");
									 }
								 }
								 else
								 {
									 System::Windows::Forms::MessageBox::Show("ERROR 4.04.1\nEnter the Standard ID within the following range\n(0 - 7FF)", "Input Error");
								 }
							 }
							 else //Decimal
							 {
								 if(System::Int32::TryParse(input,result))
								 {
									 //Forth Check: Check the range of the ID
									 if ((result < 2048) && (result >= 0))
									 {
										 resultString = result.ToString();
										 returnValue = true;
									 }
									 else
									 {
										 System::Windows::Forms::MessageBox::Show("ERROR 4.06.0\nEnter the Standard ID within the following range\n(0 - 2047)", "Input Error");
									 }
								 }
								 else
								 {
									 System::Windows::Forms::MessageBox::Show("ERROR 4.06.1\nEnter the Standard ID within the following range\n(0 - 2047)", "Input Error");
								 }
							 }
						 }
						 break;



						 /////////////////////////////////
						 /////////////////////////////////
						 /////////////////////////////////
					 case dINPUT_TYPE_DLC: //DLC
						 if(System::Int32::TryParse(input,System::Globalization::NumberStyles::HexNumber,tempFormatProvider,result))
						 {
							 if ((result < 9) && (result >= 0))
							 {
								 resultString = result.ToString();
								 returnValue = true;
							 }
							 else
							 {
								 System::Windows::Forms::MessageBox::Show("ERROR 4.10.0\nEnter the DLC within the following range\n(0 - 8)", "Input Error");

							 }
						 }
						 else
						 {
							 System::Windows::Forms::MessageBox::Show("ERROR 4.10.1\nEnter the DLC within the following range\n(0 - 8)", "Input Error");
						 }
						 break;




						 /////////////////////////////////
						 /////////////////////////////////
						 /////////////////////////////////
					 case dINPUT_TYPE_DATA: //DATA
						 if(passInuserEnteredTotalFormat == dNUMBER_FORMAT_HEX) //hex
						 {
							 if(System::Int32::TryParse(input,System::Globalization::NumberStyles::HexNumber,tempFormatProvider,result))
							 {
								 if ((result < 256) && (result >= 0))
								 {
									 resultString = "0x"+result.ToString("X2");
									 returnValue = true;
								 }
								 else
								 {

									 System::Windows::Forms::MessageBox::Show("ERROR 4.20.0\nEnter DATA within the following range\n(0 - FF)", "Input Error");
								 }
							 }
							 else
							 {
								 System::Windows::Forms::MessageBox::Show("ERROR 4.20.1\nEnter DATA within the following range\n(0 - FF)", "Input Error");
							 }
						 }
						 else //Decimal
						 {
							 if(System::Int32::TryParse(input,result))
							 {
								 if ((result < 256) && (result >= 0))
								 {
									 resultString = result.ToString();
									 returnValue = true;
								 }
								 else
								 {
									 System::Windows::Forms::MessageBox::Show("ERROR 4.25.0\nEnter DATA within the following range\n(0 - 255)", "Input Error");
								 }
							 }
							 else
							 {
								 System::Windows::Forms::MessageBox::Show("ERROR 4.25.1\nEnter DATA within the following range\n(0 - 255)", "Input Error");
							 }
						 }
						 break;
						 /////////////////////////////////

						 /////////////////////////////////
					 case dINPUT_TYPE_PERIOD: //Period
						 if(System::Int32::TryParse(input,result))
						 {
							 if (((result < 5000) && (result >= 100)) ||(result == 0))
							 {
								 result = result/10; //Need to scale this number because timer is set for 10 msecs
								 resultString = result.ToString();
								 returnValue = true;
							 }
							 else
							 {
								 System::Windows::Forms::MessageBox::Show("ERROR 4.30.0\nEnter a PERIOD within the following range\n(100 - 5000) for a Periodic message\nOr (0) for one shot message", "Input Error");
							 }
						 }
						 else
						 {
							 System::Windows::Forms::MessageBox::Show("ERROR 4.30.1\nEnter a PERIOD within the following range\n(100 - 5000) for a Periodic message\nOr (0) for one shot message", "Input Error");
						 }
						 break;
						 /////////////////////////////////

						 /////////////////////////////////
					 case dINPUT_TYPE_REPEAT: //repeat
						 if(System::Int32::TryParse(input,result))
						 {
							 if (((result < 100) && (result >= 0)) ||(result == 0))
							 {
								 resultString = result.ToString();
								 returnValue = true;
							 }
							 else
							 {
								 System::Windows::Forms::MessageBox::Show("ERROR 4.40.0\nEnter a REPEAT value within the following range\n(1 - 99)\nOr (0) for a one shot message", "Input Error");
							 }
						 }
						 else
						 {
							 System::Windows::Forms::MessageBox::Show("ERROR 4.40.1\nEnter a REPEAT value within the following range\n(1 - 99)\nOr (0) for a one shot message", "Input Error");
						 }
						 break;
						 /////////////////////////////////

						 /////////////////////////////////
					 default:
						 System::Windows::Forms::MessageBox::Show("ERROR 4.70.0\nUnknown error caused by user input" , "Input Error");
						 break;
						 /////////////////////////////////
					 }

				 }

////Check ID
//    returnValue = false;
//	if (input != "")
//	{
//		this->label1->Text="empty";
//	}
//	else
//	{
//		this->label1->Text=this->textBox1->Text;
//	}

	return (returnValue);
}

private: System::Void dataGridView1_CellClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 unsigned int eventColumnIndex;
			 unsigned int eventRowIndex;
			 eventColumnIndex = e->ColumnIndex;
			 eventRowIndex = e->RowIndex;
			 System::Object^ tempObject;
			 if ((eventRowIndex >= 0 ) && (eventRowIndex <= 9))
			 {
				 if ((eventColumnIndex >= 0 ) && (eventColumnIndex <= 13))
				 {

					 if (this->dataGridView1->Rows[eventRowIndex]->Cells[eventColumnIndex]->Value != nullptr)
					 {
						 if (this->dataGridView1->Rows[eventRowIndex]->Cells[eventColumnIndex]->Value != "")
						 {
							 tempObject = this->dataGridView1->Rows[eventRowIndex]->Cells[eventColumnIndex]->Value;
							 this->dataGridView1->Rows[eventRowIndex]->Cells[eventColumnIndex]->Style->BackColor = System::Drawing::Color::White;
						 }
					 }
				 }
			 }
		 }
private: System::Void PeriodicMessage_Tick(System::Object^  sender, System::EventArgs^  e) {
			 unsigned int tempData[dSPI_CAN_PACKET_SIZE];

			 for(unsigned char trasmitIndex = 0; trasmitIndex < dNUMBER_OF_PERIODIC_MSGS; trasmitIndex++)
			 {
				 if (periodicRepeatTransmitTracker[trasmitIndex,dPERIODIC_FLAG] > 0)
				 {
					 //Now Check to see if we have counted down to zero... thus requiring a transmit
					 periodicRepeatTransmitTracker[trasmitIndex,dCOUNTDOWN_COUNTER]--;
					 if (periodicRepeatTransmitTracker[trasmitIndex,dCOUNTDOWN_COUNTER] == 0)
					 {
						 //Transmit out message
						 tempData[0] = periodicRepeatTransmitTracker[trasmitIndex,dCOMMAND]; //Command
						 tempData[1] = periodicRepeatTransmitTracker[trasmitIndex,dEIDH];
						 tempData[2] = periodicRepeatTransmitTracker[trasmitIndex,dEIDL];
						 tempData[3] = periodicRepeatTransmitTracker[trasmitIndex,dSIDH];
						 tempData[4] = periodicRepeatTransmitTracker[trasmitIndex,dSIDL];
						 tempData[5] = periodicRepeatTransmitTracker[trasmitIndex,dDLC];
						 tempData[6] = periodicRepeatTransmitTracker[trasmitIndex,dDATA0];
						 tempData[7] = periodicRepeatTransmitTracker[trasmitIndex,dDATA1];
						 tempData[8] = periodicRepeatTransmitTracker[trasmitIndex,dDATA2];
						 tempData[9] = periodicRepeatTransmitTracker[trasmitIndex,dDATA3];
						 tempData[10] = periodicRepeatTransmitTracker[trasmitIndex,dDATA4];
						 tempData[11] = periodicRepeatTransmitTracker[trasmitIndex,dDATA5];
						 tempData[12] = periodicRepeatTransmitTracker[trasmitIndex,dDATA6];
						 tempData[13] = periodicRepeatTransmitTracker[trasmitIndex,dDATA7];
						 tempData[14] = trasmitIndex;
						 tempData[15] = 0;
						 tempData[16] = 0;
						 tempData[17] = 0;
						 if (processTransmitMessages(tempData))
						 {
						 //We successfully handed off the message...
					     //Reset the count down timer
							 periodicRepeatTransmitTracker[trasmitIndex,dCOUNTDOWN_COUNTER] = periodicRepeatTransmitTracker[trasmitIndex,dPERIODIC_VALUE];
						 }
						 else
						 {
							 periodicRepeatTransmitTracker[trasmitIndex,dCOUNTDOWN_COUNTER] = 1;
						 }
						 




						 if (periodicRepeatTransmitTracker[trasmitIndex,dPERIODIC_FLAG] == 2)
						 {


							 //Now check if we are suppose to be repeat
							 periodicRepeatTransmitTracker[trasmitIndex,dREPEAT_VALUE]--;
							 if (periodicRepeatTransmitTracker[trasmitIndex,dREPEAT_VALUE] == 0)
							 {
								 //Stop the message from the Repeat Ending
								 periodicRepeatTransmitTracker[trasmitIndex,dPERIODIC_FLAG] = 0;
								 this->dataGridView1->Rows[trasmitIndex]->Cells[dBUTTON_OR_COUNT_COLUMN_INDEX]->Value="Send";
								 this->dataGridView1->Rows[trasmitIndex]->ReadOnly=false;
//								 Unlock Row
							 }
						 }
					 }
				 }
			 }
		 } //End of function
};
}