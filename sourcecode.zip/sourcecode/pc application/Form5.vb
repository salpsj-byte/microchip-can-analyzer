﻿Public Class Form5

    Dim Address2ChangeHigh(120) As Byte
    Dim Address2ChangeLow(120) As Byte
    Dim Data2Write(120) As Byte
    Dim AmountOfData2write As Byte
    Dim AmountOfData2AlmostWrite As Byte
    Dim AmountOfDataWrote As Byte


    Dim sendReadRequest As Boolean
    Dim timeOutCounter As Byte

    Dim TurnOnBackgroundWorker1 As Byte
    Public ReadFlag As Byte
    Public ReadOutMemory As Byte

    'Read Register
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ReadOutMemory = 1 'first state
        sendReadRequest = True
        timeOutCounter = 0
        Timer2.Enabled = True
        Timer2.Start()
    End Sub

    'Write Register
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        AmountOfData2AlmostWrite = 0
        'AmountOfDataWrote = 0
        'AmountOfData2write = 0

        'Change All Yellows to Greys


        'F77h(ECANCON)
        If TextBox78.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox78.Text) Then
                TextBox78.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H77
                Data2Write(AmountOfData2write) = Form1.getData(TextBox78.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F6Fh(CANCON)
        If TextBox77.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox77.Text) Then
                TextBox77.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H6F
                Data2Write(AmountOfData2write) = Form1.getData(TextBox77.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F6Eh(CANSTAT)
        If TextBox76.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox76.Text) Then
                TextBox76.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H6E
                Data2Write(AmountOfData2write) = Form1.getData(TextBox76.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F70h(BRGCON1)
        If TextBox75.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox75.Text) Then
                TextBox75.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H70
                Data2Write(AmountOfData2write) = Form1.getData(TextBox75.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F71h(BRGCON2)
        If TextBox74.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox74.Text) Then
                TextBox74.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H71
                Data2Write(AmountOfData2write) = Form1.getData(TextBox74.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F72h(BRGCON3)
        If TextBox73.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox73.Text) Then
                TextBox73.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H72
                Data2Write(AmountOfData2write) = Form1.getData(TextBox73.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F75h(RXERRCNT)
        If TextBox72.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox72.Text) Then
                TextBox72.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H75
                Data2Write(AmountOfData2write) = Form1.getData(TextBox72.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F76h(TXERRCNT)
        If TextBox71.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox71.Text) Then
                TextBox71.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H76
                Data2Write(AmountOfData2write) = Form1.getData(TextBox71.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F60h(RXB0CON)
        If TextBox1.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox1.Text) Then
                TextBox1.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H60
                Data2Write(AmountOfData2write) = Form1.getData(TextBox1.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F50h(RXB1CON)
        If TextBox26.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox26.Text) Then
                TextBox26.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H60
                Data2Write(AmountOfData2write) = Form1.getData(TextBox26.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F40h(TXB0CON)
        If TextBox39.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox39.Text) Then
                TextBox39.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H40
                Data2Write(AmountOfData2write) = Form1.getData(TextBox39.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F41h(TXB0SIDH)
        If TextBox38.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox38.Text) Then
                TextBox38.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H41
                Data2Write(AmountOfData2write) = Form1.getData(TextBox38.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F42h(TXB0SIDL)
        If TextBox37.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox37.Text) Then
                TextBox37.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H42
                Data2Write(AmountOfData2write) = Form1.getData(TextBox37.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F43h(TXB0EIDH)
        If TextBox36.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox36.Text) Then
                TextBox36.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H43
                Data2Write(AmountOfData2write) = Form1.getData(TextBox36.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F44h(TXB0EIDL)
        If TextBox68.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox68.Text) Then
                TextBox68.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H44
                Data2Write(AmountOfData2write) = Form1.getData(TextBox68.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F45h(TXB0DLC)
        If TextBox35.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox35.Text) Then
                TextBox35.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H45
                Data2Write(AmountOfData2write) = Form1.getData(TextBox35.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F46h(TXB0D0)
        If TextBox34.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox34.Text) Then
                TextBox34.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H46
                Data2Write(AmountOfData2write) = Form1.getData(TextBox34.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F47h(TXB0D1)
        If TextBox33.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox33.Text) Then
                TextBox33.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H47
                Data2Write(AmountOfData2write) = Form1.getData(TextBox33.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F48h(TXB0D2)
        If TextBox32.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox32.Text) Then
                TextBox32.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H48
                Data2Write(AmountOfData2write) = Form1.getData(TextBox32.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F49h(TXB0D3)
        If TextBox31.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox31.Text) Then
                TextBox31.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H49
                Data2Write(AmountOfData2write) = Form1.getData(TextBox31.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F4Ah(TXB0D4)
        If TextBox30.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox30.Text) Then
                TextBox30.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H4A
                Data2Write(AmountOfData2write) = Form1.getData(TextBox30.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F4Bh(TXB0D5)
        If TextBox29.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox29.Text) Then
                TextBox29.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H4B
                Data2Write(AmountOfData2write) = Form1.getData(TextBox29.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F4Ch(TXB0D6)
        If TextBox28.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox28.Text) Then
                TextBox28.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H4C
                Data2Write(AmountOfData2write) = Form1.getData(TextBox28.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F4DH(TXB0D7)
        If TextBox27.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox27.Text) Then
                TextBox27.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H4D
                Data2Write(AmountOfData2write) = Form1.getData(TextBox27.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F30h(TXB1CON)
        If TextBox52.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox52.Text) Then
                TextBox52.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H30
                Data2Write(AmountOfData2write) = Form1.getData(TextBox52.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F31h(TXB1SIDH)
        If TextBox51.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox51.Text) Then
                TextBox51.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H31
                Data2Write(AmountOfData2write) = Form1.getData(TextBox51.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F32h(TXB1SIDL)
        If TextBox50.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox50.Text) Then
                TextBox50.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H32
                Data2Write(AmountOfData2write) = Form1.getData(TextBox50.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F33h(TXB1EIDH)
        If TextBox49.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox49.Text) Then
                TextBox49.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H33
                Data2Write(AmountOfData2write) = Form1.getData(TextBox49.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F34h(TXB1EIDL)
        If TextBox67.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox67.Text) Then
                TextBox67.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H34
                Data2Write(AmountOfData2write) = Form1.getData(TextBox67.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F35h(TXB1DLC)
        If TextBox48.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox48.Text) Then
                TextBox48.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H35
                Data2Write(AmountOfData2write) = Form1.getData(TextBox48.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F36h(TXB1D0)
        If TextBox47.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox47.Text) Then
                TextBox47.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H36
                Data2Write(AmountOfData2write) = Form1.getData(TextBox47.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F37h(TXB1D1)
        If TextBox46.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox46.Text) Then
                TextBox46.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H37
                Data2Write(AmountOfData2write) = Form1.getData(TextBox46.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F38h(TXB1D2)
        If TextBox45.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox45.Text) Then
                TextBox45.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H38
                Data2Write(AmountOfData2write) = Form1.getData(TextBox45.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F39h(TXB1D3)
        If TextBox44.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox44.Text) Then
                TextBox44.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H39
                Data2Write(AmountOfData2write) = Form1.getData(TextBox44.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F3Ah(TXB1D4)
        If TextBox43.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox43.Text) Then
                TextBox43.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H3A
                Data2Write(AmountOfData2write) = Form1.getData(TextBox43.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F3Bh(TXB1D5)
        If TextBox42.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox42.Text) Then
                TextBox42.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H3B
                Data2Write(AmountOfData2write) = Form1.getData(TextBox42.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F3Ch(TXB1D6)
        If TextBox41.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox41.Text) Then
                TextBox41.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H3C
                Data2Write(AmountOfData2write) = Form1.getData(TextBox41.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F3Dh(TXB1D7)
        If TextBox40.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox40.Text) Then
                TextBox40.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H3D
                Data2Write(AmountOfData2write) = Form1.getData(TextBox40.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F20h(TXB2CON)
        If TextBox65.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox65.Text) Then
                TextBox65.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H20
                Data2Write(AmountOfData2write) = Form1.getData(TextBox65.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F21h(TXB2SIDH)
        If TextBox64.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox64.Text) Then
                TextBox64.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H21
                Data2Write(AmountOfData2write) = Form1.getData(TextBox64.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F22h(TXB2SIDL)
        If TextBox63.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox63.Text) Then
                TextBox63.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H22
                Data2Write(AmountOfData2write) = Form1.getData(TextBox63.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F23h(TXB2EIDH)
        If TextBox62.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox62.Text) Then
                TextBox62.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H23
                Data2Write(AmountOfData2write) = Form1.getData(TextBox62.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F24h(TXB2EIDL)
        If TextBox66.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox66.Text) Then
                TextBox66.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H24
                Data2Write(AmountOfData2write) = Form1.getData(TextBox66.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F25h(TXB2DLC)
        If TextBox61.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox61.Text) Then
                TextBox61.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H25
                Data2Write(AmountOfData2write) = Form1.getData(TextBox61.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F26h(TXB2D0)
        If TextBox60.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox60.Text) Then
                TextBox60.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H26
                Data2Write(AmountOfData2write) = Form1.getData(TextBox60.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F27h(TXB2D1)
        If TextBox59.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox59.Text) Then
                TextBox59.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H27
                Data2Write(AmountOfData2write) = Form1.getData(TextBox59.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F28h(TXB2D2)
        If TextBox58.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox58.Text) Then
                TextBox58.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H28
                Data2Write(AmountOfData2write) = Form1.getData(TextBox58.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F29h(TXB2D3)
        If TextBox57.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox57.Text) Then
                TextBox57.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H29
                Data2Write(AmountOfData2write) = Form1.getData(TextBox57.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F2Ah(TXB2D4)
        If TextBox56.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox56.Text) Then
                TextBox56.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H2A
                Data2Write(AmountOfData2write) = Form1.getData(TextBox56.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F2Bh(TXB2D5)
        If TextBox55.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox55.Text) Then
                TextBox55.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H2B
                Data2Write(AmountOfData2write) = Form1.getData(TextBox55.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F2Ch(TXB2D6)
        If TextBox54.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox54.Text) Then
                TextBox54.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H2C
                Data2Write(AmountOfData2write) = Form1.getData(TextBox54.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F2Dh(TXB2D7)
        If TextBox53.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox53.Text) Then
                TextBox53.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H2D
                Data2Write(AmountOfData2write) = Form1.getData(TextBox53.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F18h RXM0SIDH 82
        If TextBox82.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox82.Text) Then
                TextBox82.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H18
                Data2Write(AmountOfData2write) = Form1.getData(TextBox82.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If


        'F19h RXM0SIDL 81
        If TextBox81.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox81.Text) Then
                TextBox81.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H19
                Data2Write(AmountOfData2write) = Form1.getData(TextBox81.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F1Ah RXM0EIDH 80
        If TextBox80.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox80.Text) Then
                TextBox80.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H1A
                Data2Write(AmountOfData2write) = Form1.getData(TextBox80.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F1Bh RXM0EIDL 79
        If TextBox79.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox79.Text) Then
                TextBox79.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H1B
                Data2Write(AmountOfData2write) = Form1.getData(TextBox79.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F1Ch RXM1SIDH 86
        If TextBox86.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox86.Text) Then
                TextBox86.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H1C
                Data2Write(AmountOfData2write) = Form1.getData(TextBox86.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F1Dh RXM1SIDL 85
        If TextBox85.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox85.Text) Then
                TextBox85.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H1D
                Data2Write(AmountOfData2write) = Form1.getData(TextBox85.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F1Eh RXM1EIDH 84
        If TextBox84.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox84.Text) Then
                TextBox84.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H1E
                Data2Write(AmountOfData2write) = Form1.getData(TextBox84.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F1Fh RXM1EIDL 83
        If TextBox83.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox83.Text) Then
                TextBox83.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H1F
                Data2Write(AmountOfData2write) = Form1.getData(TextBox83.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F00h RXF0SIDH 92
        If TextBox92.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox92.Text) Then
                TextBox92.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H0
                Data2Write(AmountOfData2write) = Form1.getData(TextBox92.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F01h RXF0SIDL 93
        If TextBox93.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox93.Text) Then
                TextBox93.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H1
                Data2Write(AmountOfData2write) = Form1.getData(TextBox93.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F02h RXF0EIDH 94
        If TextBox94.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox94.Text) Then
                TextBox94.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H2
                Data2Write(AmountOfData2write) = Form1.getData(TextBox94.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F03h RXF0EIDL 91
        If TextBox91.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox91.Text) Then
                TextBox91.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H3
                Data2Write(AmountOfData2write) = Form1.getData(TextBox91.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F04h RXF1SIDH 90
        If TextBox90.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox90.Text) Then
                TextBox90.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H4
                Data2Write(AmountOfData2write) = Form1.getData(TextBox90.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F05h RXF1SIDL 89
        If TextBox89.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox89.Text) Then
                TextBox89.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H5
                Data2Write(AmountOfData2write) = Form1.getData(TextBox89.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F06h RXF1EIDH 88
        If TextBox88.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox88.Text) Then
                TextBox88.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H6
                Data2Write(AmountOfData2write) = Form1.getData(TextBox88.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F07h RXF1EIDL 87
        If TextBox87.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox87.Text) Then
                TextBox87.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H7
                Data2Write(AmountOfData2write) = Form1.getData(TextBox87.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F08h RXF2SIDH 98
        If TextBox98.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox98.Text) Then
                TextBox98.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H8
                Data2Write(AmountOfData2write) = Form1.getData(TextBox98.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F09h RXF2SIDL 97
        If TextBox97.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox97.Text) Then
                TextBox97.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H9
                Data2Write(AmountOfData2write) = Form1.getData(TextBox97.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F0Ah RXF2EIDH 96
        If TextBox96.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox96.Text) Then
                TextBox96.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &HA
                Data2Write(AmountOfData2write) = Form1.getData(TextBox96.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F0Bh RXF2EIDL 95
        If TextBox95.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox95.Text) Then
                TextBox95.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &HB
                Data2Write(AmountOfData2write) = Form1.getData(TextBox95.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F0Ch RXF3SIDH 102
        If TextBox102.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox102.Text) Then
                TextBox102.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &HC
                Data2Write(AmountOfData2write) = Form1.getData(TextBox102.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F0Dh RXF3SIDL 101
        If TextBox101.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox101.Text) Then
                TextBox101.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &HD
                Data2Write(AmountOfData2write) = Form1.getData(TextBox101.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F0Eh RXF3EIDH 100
        If TextBox100.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox100.Text) Then
                TextBox100.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &HE
                Data2Write(AmountOfData2write) = Form1.getData(TextBox100.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F0Fh RXF3EIDL 99
        If TextBox99.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox99.Text) Then
                TextBox99.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &HF
                Data2Write(AmountOfData2write) = Form1.getData(TextBox99.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F10h RXF4SIDH 106
        If TextBox106.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox106.Text) Then
                TextBox106.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H10
                Data2Write(AmountOfData2write) = Form1.getData(TextBox106.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F11h RXF4SIDL 105
        If TextBox105.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox105.Text) Then
                TextBox105.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H11
                Data2Write(AmountOfData2write) = Form1.getData(TextBox105.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F12h RXF4EIDH 104
        If TextBox104.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox104.Text) Then
                TextBox104.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H12
                Data2Write(AmountOfData2write) = Form1.getData(TextBox104.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F13h RXF4EIDL 103
        If TextBox103.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox103.Text) Then
                TextBox103.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H13
                Data2Write(AmountOfData2write) = Form1.getData(TextBox103.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F14h RXF5SIDH 110
        If TextBox110.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox110.Text) Then
                TextBox110.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H14
                Data2Write(AmountOfData2write) = Form1.getData(TextBox110.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F15h RXF5SIDL 109
        If TextBox109.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox109.Text) Then
                TextBox109.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H15
                Data2Write(AmountOfData2write) = Form1.getData(TextBox109.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F16h RXF5EIDH 108
        If TextBox108.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox108.Text) Then
                TextBox108.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H16
                Data2Write(AmountOfData2write) = Form1.getData(TextBox108.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F17h RXF5EIDL 107
        If TextBox107.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox107.Text) Then
                TextBox107.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H17
                Data2Write(AmountOfData2write) = Form1.getData(TextBox107.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'FA4h 
        If TextBox111.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox111.Text) Then
                TextBox111.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &HA4
                Data2Write(AmountOfData2write) = Form1.getData(TextBox111.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'F74h 
        If TextBox112.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox112.Text) Then
                TextBox112.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HF
                Address2ChangeLow(AmountOfData2write) = &H74
                Data2Write(AmountOfData2write) = Form1.getData(TextBox112.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'DF0h 
        If TextBox116.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox116.Text) Then
                TextBox116.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HD
                Address2ChangeLow(AmountOfData2write) = &HF0
                Data2Write(AmountOfData2write) = Form1.getData(TextBox116.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'DF1h 
        If TextBox115.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox115.Text) Then
                TextBox115.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HD
                Address2ChangeLow(AmountOfData2write) = &HF1
                Data2Write(AmountOfData2write) = Form1.getData(TextBox115.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'DF2h 
        If TextBox114.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox114.Text) Then
                TextBox114.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HD
                Address2ChangeLow(AmountOfData2write) = &HF2
                Data2Write(AmountOfData2write) = Form1.getData(TextBox114.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'DF3h 
        If TextBox113.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox113.Text) Then
                TextBox113.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HD
                Address2ChangeLow(AmountOfData2write) = &HF3
                Data2Write(AmountOfData2write) = Form1.getData(TextBox113.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'DD4h 
        If TextBox118.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox118.Text) Then
                TextBox118.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HD
                Address2ChangeLow(AmountOfData2write) = &HD4
                Data2Write(AmountOfData2write) = Form1.getData(TextBox118.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        'DD5h 
        If TextBox117.BackColor = Color.Yellow Then
            If Form1.isValidData(TextBox117.Text) Then
                TextBox117.BackColor = Color.Gray
                Address2ChangeHigh(AmountOfData2write) = &HD
                Address2ChangeLow(AmountOfData2write) = &HD5
                Data2Write(AmountOfData2write) = Form1.getData(TextBox117.Text).ToString
                AmountOfData2write = AmountOfData2write + 1
            End If
        End If

        If AmountOfData2write > 0 Then
            Button1.Enabled = False
            Button2.Enabled = False
            Button3.Enabled = False
            AmountOfDataWrote = 0
            AmountOfData2AlmostWrite = 0
            Timer1.Enabled = True
        End If
    End Sub




    'Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
    '    TextBox1.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
    '    TextBox2.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged
    '    TextBox3.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
    '    TextBox4.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged
    '    TextBox5.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged
    '    TextBox6.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged
    '    TextBox7.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged
    '    TextBox8.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox9_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox9.TextChanged
    '    TextBox9.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox10_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox10.TextChanged
    '    TextBox10.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox11_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox11.TextChanged
    '    TextBox11.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox12_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox12.TextChanged
    '    TextBox12.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox13_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox13.TextChanged
    '    TextBox13.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox14_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox14.TextChanged
    '    TextBox14.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox15_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox15.TextChanged
    '    TextBox15.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox16_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox16.TextChanged
    '    TextBox16.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox17_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox17.TextChanged
    '    TextBox17.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox18_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox18.TextChanged
    '    TextBox18.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox19_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox19.TextChanged
    '    TextBox19.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox20_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox20.TextChanged
    '    TextBox20.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox21_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox21.TextChanged
    '    TextBox21.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox22_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox22.TextChanged
    '    TextBox22.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox23_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox23.TextChanged
    '    TextBox23.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox24_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox24.TextChanged
    '    TextBox24.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox25_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox25.TextChanged
    '    TextBox25.BackColor = Color.Yellow
    'End Sub
    'Private Sub TextBox26_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox26.TextChanged
    '    TextBox26.BackColor = Color.Yellow
    'End Sub
    Private Sub TextBox27_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox27.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox27.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox28_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox28.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox28.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox29_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox29.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox29.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox30_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox30.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox30.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox31_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox31.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox31.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox32_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox32.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox32.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox33_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox33.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox33.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox34_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox34.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox34.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox35_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox35.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox35.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox36_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox36.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox36.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox37_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox37.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox37.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox38_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox38.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox38.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox39_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox39.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox39.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox40_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox40.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox40.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox41_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox41.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox41.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox42_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox42.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox42.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox43_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox43.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox43.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox44_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox44.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox44.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox45_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox45.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox45.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox46_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox46.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
            showWriteError()
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox46.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox47_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox47.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox47.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox48_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox48.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox48.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox49_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox49.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox49.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox50_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox50.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox50.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox51_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox51.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox51.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox52_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox52.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox52.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox53_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox53.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox53.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox54_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox54.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox54.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox55_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox55.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox55.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox56_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox56.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox56.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox57_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox57.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox57.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox58_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox58.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox58.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox59_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox59.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox59.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox60_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox60.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox60.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox61_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox61.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox61.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox62_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox62.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox62.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox63_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox63.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox63.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox64_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox64.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox64.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox65_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox65.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox65.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox66_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox66.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox66.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox67_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox67.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox67.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox68_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox68.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox68.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox71_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox71.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox71.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox72_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox72.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox72.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox73_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox73.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox73.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox74_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox74.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox74.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox75_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox75.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox75.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox76_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox76.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox76.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox77_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox77.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox77.BackColor = Color.Yellow
        End If
    End Sub
    Private Sub TextBox78_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox78.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox78.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox82_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox82.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox82.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox81_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox81.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox81.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox80_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox80.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox80.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox79_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox79.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox79.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox86_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox86.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox86.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox85_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox85.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox85.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox84_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox84.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox84.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox83_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox83.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox83.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox92_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox92.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox92.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox93_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox93.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox93.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox94_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox94.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox94.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox91_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox91.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox91.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox90_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox90.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox90.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox89_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox89.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox89.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox88_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox88.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox88.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox87_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox87.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox87.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox98_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox98.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox98.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox97_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox97.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox97.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox96_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox96.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox96.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox95_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox95.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox95.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox102_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox102.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox102.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox101_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox101.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox101.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox100_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox100.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox100.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox99_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox99.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox99.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox106_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox106.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox106.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox105_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox105.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox105.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox104_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox104.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox104.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox103_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox103.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox103.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox110_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox110.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox110.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox109_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox109.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox109.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox108_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox108.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox108.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox107_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox107.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox107.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox111_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox111.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox111.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox112_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox112.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox112.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox113_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox113.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox113.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox114_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox114.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox114.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox115_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox115.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox115.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox116_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox116.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox116.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox117_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox117.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox117.BackColor = Color.Yellow
        End If
    End Sub

    Private Sub TextBox118_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox118.TextChanged
        If (AmountOfData2AlmostWrite > 120) Then
            showWriteError()
        ElseIf (ReadFlag = 1) Then
            'currently do nothing
        Else
            AmountOfData2AlmostWrite = AmountOfData2AlmostWrite + 1
            TextBox118.BackColor = Color.Yellow
        End If
    End Sub


    Function clearTextFields()
        'Me.TextBox1.BackColor = Color.White
        'Me.TextBox2.BackColor = Color.White
        'Me.TextBox3.BackColor = Color.White
        'Me.TextBox4.BackColor = Color.White
        'Me.TextBox5.BackColor = Color.White
        'Me.TextBox6.BackColor = Color.White
        'Me.TextBox7.BackColor = Color.White
        'Me.TextBox8.BackColor = Color.White
        'Me.TextBox9.BackColor = Color.White
        'Me.TextBox10.BackColor = Color.White
        'Me.TextBox11.BackColor = Color.White
        'Me.TextBox12.BackColor = Color.White
        'Me.TextBox13.BackColor = Color.White
        'Me.TextBox14.BackColor = Color.White
        'Me.TextBox15.BackColor = Color.White
        'Me.TextBox16.BackColor = Color.White
        'Me.TextBox17.BackColor = Color.White
        'Me.TextBox18.BackColor = Color.White
        'Me.TextBox19.BackColor = Color.White
        'Me.TextBox20.BackColor = Color.White
        'Me.TextBox21.BackColor = Color.White
        'Me.TextBox22.BackColor = Color.White
        'Me.TextBox23.BackColor = Color.White
        'Me.TextBox24.BackColor = Color.White
        'Me.TextBox25.BackColor = Color.White
        'Me.TextBox26.BackColor = Color.White
        Me.TextBox27.BackColor = Color.White
        Me.TextBox28.BackColor = Color.White
        Me.TextBox29.BackColor = Color.White
        Me.TextBox30.BackColor = Color.White
        Me.TextBox31.BackColor = Color.White
        Me.TextBox32.BackColor = Color.White
        Me.TextBox33.BackColor = Color.White
        Me.TextBox34.BackColor = Color.White
        Me.TextBox35.BackColor = Color.White
        Me.TextBox36.BackColor = Color.White
        Me.TextBox37.BackColor = Color.White
        Me.TextBox38.BackColor = Color.White
        Me.TextBox39.BackColor = Color.White
        Me.TextBox40.BackColor = Color.White
        Me.TextBox41.BackColor = Color.White
        Me.TextBox42.BackColor = Color.White
        Me.TextBox43.BackColor = Color.White
        Me.TextBox44.BackColor = Color.White
        Me.TextBox45.BackColor = Color.White
        Me.TextBox46.BackColor = Color.White
        Me.TextBox47.BackColor = Color.White
        Me.TextBox48.BackColor = Color.White
        Me.TextBox49.BackColor = Color.White
        Me.TextBox50.BackColor = Color.White
        Me.TextBox51.BackColor = Color.White
        Me.TextBox52.BackColor = Color.White
        Me.TextBox53.BackColor = Color.White
        Me.TextBox54.BackColor = Color.White
        Me.TextBox55.BackColor = Color.White
        Me.TextBox56.BackColor = Color.White
        Me.TextBox57.BackColor = Color.White
        Me.TextBox58.BackColor = Color.White
        Me.TextBox59.BackColor = Color.White
        Me.TextBox60.BackColor = Color.White
        Me.TextBox61.BackColor = Color.White
        Me.TextBox62.BackColor = Color.White
        Me.TextBox63.BackColor = Color.White
        Me.TextBox64.BackColor = Color.White
        Me.TextBox65.BackColor = Color.White
        Me.TextBox66.BackColor = Color.White
        Me.TextBox67.BackColor = Color.White
        Me.TextBox68.BackColor = Color.White
        Me.TextBox71.BackColor = Color.White
        Me.TextBox72.BackColor = Color.White
        Me.TextBox73.BackColor = Color.White
        Me.TextBox74.BackColor = Color.White
        Me.TextBox75.BackColor = Color.White
        Me.TextBox76.BackColor = Color.White
        Me.TextBox77.BackColor = Color.White
        Me.TextBox78.BackColor = Color.White
        Me.TextBox83.BackColor = Color.White
        Me.TextBox84.BackColor = Color.White
        Me.TextBox85.BackColor = Color.White
        Me.TextBox86.BackColor = Color.White
        Me.TextBox79.BackColor = Color.White
        Me.TextBox80.BackColor = Color.White
        Me.TextBox81.BackColor = Color.White
        Me.TextBox82.BackColor = Color.White
        Me.TextBox107.BackColor = Color.White
        Me.TextBox108.BackColor = Color.White
        Me.TextBox109.BackColor = Color.White
        Me.TextBox110.BackColor = Color.White
        Me.TextBox103.BackColor = Color.White
        Me.TextBox104.BackColor = Color.White
        Me.TextBox105.BackColor = Color.White
        Me.TextBox106.BackColor = Color.White
        Me.TextBox99.BackColor = Color.White
        Me.TextBox100.BackColor = Color.White
        Me.TextBox101.BackColor = Color.White
        Me.TextBox102.BackColor = Color.White
        Me.TextBox95.BackColor = Color.White
        Me.TextBox96.BackColor = Color.White
        Me.TextBox97.BackColor = Color.White
        Me.TextBox98.BackColor = Color.White
        Me.TextBox87.BackColor = Color.White
        Me.TextBox88.BackColor = Color.White
        Me.TextBox89.BackColor = Color.White
        Me.TextBox90.BackColor = Color.White
        Me.TextBox91.BackColor = Color.White
        Me.TextBox94.BackColor = Color.White
        Me.TextBox93.BackColor = Color.White
        Me.TextBox92.BackColor = Color.White
        Me.TextBox111.BackColor = Color.White
        Me.TextBox112.BackColor = Color.White
        Me.TextBox113.BackColor = Color.White
        Me.TextBox114.BackColor = Color.White
        Me.TextBox115.BackColor = Color.White
        Me.TextBox116.BackColor = Color.White
        Me.TextBox117.BackColor = Color.White
        Me.TextBox118.BackColor = Color.White
        Return 1
    End Function

    Function emptyTextFields()
        Me.TextBox1.Text = ""
        Me.TextBox2.Text = ""
        Me.TextBox3.Text = ""
        Me.TextBox4.Text = ""
        Me.TextBox5.Text = ""
        Me.TextBox6.Text = ""
        Me.TextBox7.Text = ""
        Me.TextBox8.Text = ""
        Me.TextBox9.Text = ""
        Me.TextBox10.Text = ""
        Me.TextBox11.Text = ""
        Me.TextBox12.Text = ""
        Me.TextBox13.Text = ""
        Me.TextBox14.Text = ""
        Me.TextBox15.Text = ""
        Me.TextBox16.Text = ""
        Me.TextBox17.Text = ""
        Me.TextBox18.Text = ""
        Me.TextBox19.Text = ""
        Me.TextBox20.Text = ""
        Me.TextBox21.Text = ""
        Me.TextBox22.Text = ""
        Me.TextBox23.Text = ""
        Me.TextBox24.Text = ""
        Me.TextBox25.Text = ""
        Me.TextBox26.Text = ""
        Me.TextBox27.Text = ""
        Me.TextBox28.Text = ""
        Me.TextBox29.Text = ""
        Me.TextBox30.Text = ""
        Me.TextBox31.Text = ""
        Me.TextBox32.Text = ""
        Me.TextBox33.Text = ""
        Me.TextBox34.Text = ""
        Me.TextBox35.Text = ""
        Me.TextBox36.Text = ""
        Me.TextBox37.Text = ""
        Me.TextBox38.Text = ""
        Me.TextBox39.Text = ""
        Me.TextBox40.Text = ""
        Me.TextBox41.Text = ""
        Me.TextBox42.Text = ""
        Me.TextBox43.Text = ""
        Me.TextBox44.Text = ""
        Me.TextBox45.Text = ""
        Me.TextBox46.Text = ""
        Me.TextBox47.Text = ""
        Me.TextBox48.Text = ""
        Me.TextBox49.Text = ""
        Me.TextBox50.Text = ""
        Me.TextBox51.Text = ""
        Me.TextBox52.Text = ""
        Me.TextBox53.Text = ""
        Me.TextBox54.Text = ""
        Me.TextBox55.Text = ""
        Me.TextBox56.Text = ""
        Me.TextBox57.Text = ""
        Me.TextBox58.Text = ""
        Me.TextBox59.Text = ""
        Me.TextBox60.Text = ""
        Me.TextBox61.Text = ""
        Me.TextBox62.Text = ""
        Me.TextBox63.Text = ""
        Me.TextBox64.Text = ""
        Me.TextBox65.Text = ""
        Me.TextBox66.Text = ""
        Me.TextBox67.Text = ""
        Me.TextBox68.Text = ""
        Me.TextBox69.Text = ""
        Me.TextBox70.Text = ""
        Me.TextBox71.Text = ""
        Me.TextBox72.Text = ""
        Me.TextBox73.Text = ""
        Me.TextBox74.Text = ""
        Me.TextBox75.Text = ""
        Me.TextBox76.Text = ""
        Me.TextBox77.Text = ""
        Me.TextBox78.Text = ""
        Me.TextBox83.Text = ""
        Me.TextBox84.Text = ""
        Me.TextBox85.Text = ""
        Me.TextBox86.Text = ""
        Me.TextBox79.Text = ""
        Me.TextBox80.Text = ""
        Me.TextBox81.Text = ""
        Me.TextBox82.Text = ""
        Me.TextBox107.Text = ""
        Me.TextBox108.Text = ""
        Me.TextBox109.Text = ""
        Me.TextBox110.Text = ""
        Me.TextBox103.Text = ""
        Me.TextBox104.Text = ""
        Me.TextBox105.Text = ""
        Me.TextBox106.Text = ""
        Me.TextBox99.Text = ""
        Me.TextBox100.Text = ""
        Me.TextBox101.Text = ""
        Me.TextBox102.Text = ""
        Me.TextBox95.Text = ""
        Me.TextBox96.Text = ""
        Me.TextBox97.Text = ""
        Me.TextBox98.Text = ""
        Me.TextBox87.Text = ""
        Me.TextBox88.Text = ""
        Me.TextBox89.Text = ""
        Me.TextBox90.Text = ""
        Me.TextBox91.Text = ""
        Me.TextBox94.Text = ""
        Me.TextBox93.Text = ""
        Me.TextBox92.Text = ""
        Me.TextBox111.Text = ""
        Me.TextBox112.Text = ""
        Me.TextBox113.Text = ""
        Me.TextBox114.Text = ""
        Me.TextBox115.Text = ""
        Me.TextBox116.Text = ""
        Me.TextBox117.Text = ""
        Me.TextBox118.Text = ""
        Return 1
    End Function

    Private Sub Form5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Click
        Me.BringToFront()
    End Sub

    Private Sub Form5_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        Timer1.Dispose()
        Timer2.Dispose()
    End Sub


    'Private Function Hex2Dec(ByVal MyInteger As Object, ByVal MyWidth As Integer) As String
    '    Dim TempWork As String
    '    Dim TempWidth As Integer
    '    Dim TempInt As Integer

    '    TempWidth = CInt(MyWidth)
    '    TempInt = CInt(MyInteger)

    '    TempWork = Hex(TempInt)

    '    If Len(TempWork) > TempWidth Then
    '        Dec2Hex = Mid(TempWork, Len(TempWork) - TempWidth, TempWidth)
    '        Exit Function
    '    End If

    '    Do Until Len(TempWork) = TempWidth
    '        TempWork = "0" & TempWork
    '    Loop

    '    Dec2Hex = TempWork
    'End Function

    'Private Function Dec2Hex(ByVal MyInteger As Object, ByVal MyWidth As Integer) As String
    '    Dim TempWork As String
    '    Dim TempWidth As Integer
    '    Dim TempInt As Integer

    '    TempWidth = CInt(MyWidth)
    '    TempInt = CInt(MyInteger)

    '    TempWork = Hex(TempInt)

    '    If Len(TempWork) > TempWidth Then
    '        Dec2Hex = Mid(TempWork, Len(TempWork) - TempWidth, TempWidth)
    '        Exit Function
    '    End If

    '    Do Until Len(TempWork) = TempWidth
    '        TempWork = "0" & TempWork
    '    Loop

    '    Dec2Hex = TempWork
    'End Function



    Private Sub Form5_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        e.Cancel = True
        Form1.f5status = 2 'This means that the form is hidden
        Me.Hide()
        Me.Location = New System.Drawing.Point(0, 0)
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        'WES        If (Form1.isUSBBusy() = 0) Then
        'wait until next USB packet is ready...
        If AmountOfData2write > 0 Then
            If AmountOfDataWrote < AmountOfData2write Then
                Form1.WriteRegister(Address2ChangeHigh(AmountOfDataWrote), Address2ChangeLow(AmountOfDataWrote), Data2Write(AmountOfDataWrote))
                AmountOfDataWrote = AmountOfDataWrote + 1
            Else
                AmountOfData2write = 0
                Timer1.Enabled = False
                'unlock buttons
                Button1.Enabled = True
                Button2.Enabled = True
                Button3.Enabled = True
                MessageBox.Show("Write should be complete")
            End If
        Else
            AmountOfData2write = 0
            Timer1.Enabled = False
            Timer1.Stop()
            'unlock buttons
            Button1.Enabled = True
            Button2.Enabled = True
            Button3.Enabled = True
        End If
    End Sub


    Sub enableButtons()
        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
    End Sub

    Private Sub showWriteError()
        'MessageBox.Show("Maximum amount of writes reached")
    End Sub

    Private Sub Form5_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub





    Private Sub Form5_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDown
        Me.BringToFront()
    End Sub



    Private Sub Panel2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Panel2.MouseDown
        Me.BringToFront()
    End Sub


    Private Sub GroupBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GroupBox1.MouseDown
        Me.BringToFront()
    End Sub

    Private Sub GroupBox2_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GroupBox2.MouseDown
        Me.BringToFront()
    End Sub

    Private Sub GroupBox3_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GroupBox3.MouseDown
        Me.BringToFront()
    End Sub

    Private Sub GroupBox4_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GroupBox4.MouseDown
        Me.BringToFront()
    End Sub

    Private Sub GroupBox5_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles GroupBox5.MouseDown
        Me.BringToFront()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Button2.Enabled = False
        emptyTextFields()
        clearTextFields()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick

        If timeOutCounter > 3 Then
            sendReadRequest = True
        Else
            timeOutCounter = timeOutCounter + 1
        End If




        Select Case ReadOutMemory
            Case 1
                Me.clearTextFields() 'Clears the color 'Change All Yellows or Greys to White
                Button2.Enabled = False
                Button3.Enabled = False
                ReadFlag = True
                ReadOutMemory = 2
            Case 2
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(1, 5, 5)
                End If
            Case 3
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(2, 5, 5)
                End If
            Case 4
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(3, 5, 5)
                End If
            Case 5
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(4, 5, 5)
                End If
            Case 6
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(5, 5, 5)
                End If
            Case 7
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(6, 5, 5)
                End If
            Case 8
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(7, 5, 5)
                End If
            Case 9
                If (sendReadRequest = True) Then
                    sendReadRequest = False
                    timeOutCounter = 0
                    Form1.ReadRegister(8, 5, 5)
                End If
            Case 10
                'should have received everything
                'cancel timer
                Button2.Enabled = True
                Button3.Enabled = True
                ReadFlag = 0
                Timer2.Stop()
            Case Else
                'shouldn't get here
                ReadOutMemory = 10
        End Select
    End Sub
End Class