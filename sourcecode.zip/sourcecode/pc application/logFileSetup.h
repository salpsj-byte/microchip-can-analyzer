#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace SimpleWinUSBDemo {

#include "Globals.h"

// A simple class
	public ref class logFileDataClass
	{
		bool startLogging;
		bool stopLogging;
		bool continueLogging;
		String^ logFileName;

	public:
		logFileDataClass(void)
		{
		}

		String^ getlogFileName(void)
		{
			return(logFileName);
		}

		void setlogFile(String^ passedInName)
		{
			logFileName = passedInName;
		}



//Start Logging
		bool getStartLogging(void)
		{
			return(startLogging);
		}

		void setStartLogging(bool passedInStartLogging)
		{
			startLogging = passedInStartLogging;
		}

//Stop Logging
		bool getStopLogging(void)
		{
			return(stopLogging);
		}

		void setStopLogging(bool passedInStopLogging)
		{
			stopLogging = passedInStopLogging;
		}

//Continue Logging
		bool getContinueLogging(void)
		{
			return(continueLogging);
		}

		void setContinueLogging(bool passedInContinueLogging)
		{
			continueLogging = passedInContinueLogging;
		}
	};

	/// <summary>
	/// Summary for LogFileSetup
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class logFileSetup : public System::Windows::Forms::Form
	{
	public:
		logFileDataClass ^l1;
//		logFileSetup(void)
		logFileSetup(logFileDataClass^ passedl)
		{
			l1 = passedl;
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~logFileSetup()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::CheckBox^  checkBox1;
	private: System::Windows::Forms::SaveFileDialog^  saveFileDialog1;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(logFileSetup::typeid));
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Location = System::Drawing::Point(12, 12);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(523, 82);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Log File Path";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(442, 46);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 1;
			this->button1->Text = L"Browse";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &logFileSetup::button1_Click);
			// 
			// textBox1
			// 
			this->textBox1->Enabled = false;
			this->textBox1->Location = System::Drawing::Point(7, 20);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(510, 20);
			this->textBox1->TabIndex = 0;
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Enabled = false;
			this->checkBox1->Location = System::Drawing::Point(430, 114);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(99, 17);
			this->checkBox1->TabIndex = 1;
			this->checkBox1->Text = L"Enable Log File";
			this->checkBox1->UseVisualStyleBackColor = true;
			this->checkBox1->CheckedChanged += gcnew System::EventHandler(this, &logFileSetup::checkBox1_CheckedChanged);
			// 
			// saveFileDialog1
			// 
			this->saveFileDialog1->Title = L"Select Log File";
			// 
			// logFileSetup
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoValidate = System::Windows::Forms::AutoValidate::Disable;
			this->CausesValidation = false;
			this->ClientSize = System::Drawing::Size(547, 145);
			this->Controls->Add(this->checkBox1);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->ImeMode = System::Windows::Forms::ImeMode::Disable;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"logFileSetup";
			this->ShowInTaskbar = false;
			this->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Hide;
			this->StartPosition = System::Windows::Forms::FormStartPosition::Manual;
			this->Text = L"Log File Setup";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &logFileSetup::logFileSetup_FormClosing);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {


				 this->saveFileDialog1->FileName = "logFile.CAN"; //Initial File Name
				 this->saveFileDialog1->InitialDirectory=".";
				 this->saveFileDialog1->Filter = "Log Files (*.CAN)|*.CAN";

				 if (this->saveFileDialog1->ShowDialog() == ::DialogResult::OK)
				 {
					 if(saveFileDialog1->FileName != "")
					 {
						 l1->setlogFile(saveFileDialog1->FileName);
						 //Show file name in the TextField
						 this->textBox1->Text=saveFileDialog1->FileName;
						 this->checkBox1->Enabled=true;
					 }
				 }
				 else
				 {
					 //The user cancelled
					 this->checkBox1->Enabled=false;
					 this->textBox1->Text="";
				 }
			 }
private: System::Void logFileSetup_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
        e->Cancel=true;
        this->Hide();
		 }
private: System::Void checkBox1_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(this->checkBox1->Checked==true)
			 {
				 //Turn Logging On
				 l1->setStopLogging(false);
				 l1->setContinueLogging(true);
				 l1->setStartLogging(true);
			 }
			 else
			 {
				 //Turn Logging Off
				 l1->setContinueLogging(false);
				 l1->setStartLogging(false);
				 l1->setStopLogging(true);
			 }
		 }
};
}
