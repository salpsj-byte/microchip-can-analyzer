#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace SimpleWinUSBDemo {
#include "Globals.h"

// A simple class
	public ref class bitrateDataClass
	{
		bool newBitrateDataFlag;
		unsigned int selectedBitrate;
		unsigned char selectedCANMode;
		bool newCANModeDataFlag;
		unsigned char selectedTermination;
		bool newTerminationDataFlag;

	public:
		bitrateDataClass(void)
		{
		}

//Bitrate
		bool getBitrateFlag(void)
		{
			bool returnValue;
			returnValue = newBitrateDataFlag;
			return(returnValue);
		}

		void setBitrateFlag(bool passedInBitrate)
		{
			newBitrateDataFlag = passedInBitrate;
		}

		void setBitrate(unsigned int passedInBitrate)
		{
			selectedBitrate = passedInBitrate;
			newBitrateDataFlag = true;
		}

		unsigned int getBitrate(void)
		{
			return(selectedBitrate);
		}
		



//CAN Mode
		bool getCANModeFlag(void)
		{
			bool returnValue;
			returnValue = newCANModeDataFlag;
			return(returnValue);
		}

		void setCANModeFlag(bool passedInCANModeFlag)
		{
			newCANModeDataFlag = passedInCANModeFlag;
		}

		void setCANMode(unsigned char passedInCANMode)
		{
			selectedCANMode = passedInCANMode;
			newCANModeDataFlag = true;
		}

		unsigned char getCANMode(void)
		{
			return(selectedCANMode);
		}







//Termination
		bool getTerminationDataFlag(void)
		{
			bool returnValue;
			returnValue = newTerminationDataFlag;
			return(returnValue);
		}

		void setTerminationFlag(bool passedInTermination)
		{
			newTerminationDataFlag = passedInTermination;
		}

		void setTermination(unsigned char passedInTermination)
		{
			selectedTermination = passedInTermination;
			newTerminationDataFlag = true;
		}

		unsigned char getTermination(void)
		{
			return(selectedTermination);
		}
	};












/////////////////////////////////////////////
//This Doesn't Work
//ref class Form1;
//
//public ref class hardwareSetup : public System::Windows::Forms::Form
//{
//public: Form1^ parentForm;
//	
//public:
//	hardwareSetup(Form1^ passedForm)
//	{
//		InitializeComponent();
//		parentForm = passedForm;
//		parentForm->callsimpleForm1(1);
/////////////////////////////////////////////			



/////////////////////////////////////////////			
//This Doesn't Work
//ref class Form1;
//
//public ref class hardwareSetup : public System::Windows::Forms::Form
//{
//public: Form1^ parentFrm;
//public: Form1^ myParentForm = & parentFrm;
//
//public:
//	hardwareSetup(Form1^ passedForm)
//	{
//		InitializeComponent();
//		myParentForm = passedForm;
//		myParentForm->callsimpleForm1(1);
/////////////////////////////////////////////			

//    ref class Form1;

	/// <summary>
	/// Summary for hardwareSetup
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>


	public ref class hardwareSetup : public System::Windows::Forms::Form
	{
//	public: Form1^ parentFrm;
		
	public:
		bitrateDataClass ^b1;
//	hardwareSetup(void)
		hardwareSetup(bitrateDataClass^ passedb)
		{
			 b1 = passedb;
			InitializeComponent();

//		parentFrm->callsimpleForm1(1);
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~hardwareSetup()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::GroupBox^  groupBox1;
	protected: 
	private: System::Windows::Forms::Label^  label1;
	public: System::Windows::Forms::ComboBox^  comboBox1;
	private: 

	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::ComboBox^  comboBox2;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::ComboBox^  comboBox3;
	private: System::Windows::Forms::Button^  button3;
	public: System::Windows::Forms::Label^  label2;
	private: 
	public: System::Windows::Forms::Label^  label4;


	private: System::Windows::Forms::Label^  label3;
	public: System::Windows::Forms::Label^  label6;
	private: 

	private: System::Windows::Forms::Label^  label5;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->comboBox1 = (gcnew System::Windows::Forms::ComboBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->comboBox2 = (gcnew System::Windows::Forms::ComboBox());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->comboBox3 = (gcnew System::Windows::Forms::ComboBox());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->comboBox1);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Location = System::Drawing::Point(5, 5);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(146, 98);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"CAN Bitrate Control";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(55, 16);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(22, 13);
			this->label2->TabIndex = 3;
			this->label2->Text = L"NA";
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(5, 16);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(53, 13);
			this->label1->TabIndex = 2;
			this->label1->Text = L"STATUS:";
			// 
			// comboBox1
			// 
			this->comboBox1->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox1->FormattingEnabled = true;
			this->comboBox1->Items->AddRange(gcnew cli::array< System::Object^  >(18) {L"20 Kbps", L"33.3 Kbps", L"50.0 Kbps", L"80.0 Kbps", 
				L"83.3 Kbps", L"100 Kbps", L"125 Kbps", L"150 Kbps", L"175 Kbps", L"200 Kbps", L"225 Kbps", L"250 Kbps", L"275 Kbps", L"300 Kbps", 
				L"500 Kbps", L"625 Kbps", L"800 Kbps", L"1 Mbps"});
			this->comboBox1->Location = System::Drawing::Point(5, 32);
			this->comboBox1->Name = L"comboBox1";
			this->comboBox1->Size = System::Drawing::Size(135, 21);
			this->comboBox1->TabIndex = 1;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(91, 59);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(49, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Set";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &hardwareSetup::button1_Click);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->label4);
			this->groupBox2->Controls->Add(this->label3);
			this->groupBox2->Controls->Add(this->comboBox2);
			this->groupBox2->Controls->Add(this->button2);
			this->groupBox2->Location = System::Drawing::Point(4, 103);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(147, 96);
			this->groupBox2->TabIndex = 1;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"CAN Mode Control";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(55, 16);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(22, 13);
			this->label4->TabIndex = 4;
			this->label4->Text = L"NA";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(5, 16);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(53, 13);
			this->label3->TabIndex = 3;
			this->label3->Text = L"STATUS:";
			// 
			// comboBox2
			// 
			this->comboBox2->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox2->FormattingEnabled = true;
			this->comboBox2->Items->AddRange(gcnew cli::array< System::Object^  >(3) {L"Config Mode", L"Normal Mode", L"Listen Only Mode"});
			this->comboBox2->Location = System::Drawing::Point(6, 32);
			this->comboBox2->Name = L"comboBox2";
			this->comboBox2->Size = System::Drawing::Size(135, 21);
			this->comboBox2->TabIndex = 2;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(92, 59);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(49, 23);
			this->button2->TabIndex = 1;
			this->button2->Text = L"Set";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &hardwareSetup::button2_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->label6);
			this->groupBox3->Controls->Add(this->label5);
			this->groupBox3->Controls->Add(this->comboBox3);
			this->groupBox3->Controls->Add(this->button3);
			this->groupBox3->Location = System::Drawing::Point(4, 206);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(147, 96);
			this->groupBox3->TabIndex = 2;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Bus Termination Control";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(55, 16);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(22, 13);
			this->label6->TabIndex = 5;
			this->label6->Text = L"NA";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(5, 16);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(53, 13);
			this->label5->TabIndex = 4;
			this->label5->Text = L"STATUS:";
			// 
			// comboBox3
			// 
			this->comboBox3->DropDownStyle = System::Windows::Forms::ComboBoxStyle::DropDownList;
			this->comboBox3->FormattingEnabled = true;
			this->comboBox3->Items->AddRange(gcnew cli::array< System::Object^  >(2) {L"ON", L"OFF"});
			this->comboBox3->Location = System::Drawing::Point(6, 32);
			this->comboBox3->Name = L"comboBox3";
			this->comboBox3->Size = System::Drawing::Size(135, 21);
			this->comboBox3->TabIndex = 3;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(92, 59);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(49, 23);
			this->button3->TabIndex = 2;
			this->button3->Text = L"Set";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &hardwareSetup::button3_Click);
			// 
			// hardwareSetup
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(156, 310);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"hardwareSetup";
			this->ShowInTaskbar = false;
			this->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Hide;
			this->Text = L"Hardware Setup";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &hardwareSetup::hardwareSetup_FormClosing);
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void hardwareSetup_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
				 e->Cancel=true;
				 this->Hide();
			 }

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
unsigned char tempSelectedIndex = 0;
tempSelectedIndex = this->comboBox1->SelectedIndex;

switch(tempSelectedIndex)
{
case 0: //20 Kbps
	b1->setBitrate(20);
	break;

case 1: //33.3 Kbps
	b1->setBitrate(33);
	break;

case 2: //50.0 Kbps
	b1->setBitrate(50);
	break;	

case 3: //80.0 Kbps
	b1->setBitrate(80);
	break;

case 4: //83.3 Kbps
	b1->setBitrate(83);
	break;

case 5: //100 Kbps
	b1->setBitrate(100);
	break;

case 6: //125 Kbps
	b1->setBitrate(125);
	break;

case 7: //150 Kbps
	b1->setBitrate(150);
	break;

case 8: //175 Kbps
	b1->setBitrate(175);
	break;

case 9: //200 Kbps
	b1->setBitrate(200);
	break;

case 10: //225 Kbps
	b1->setBitrate(225);
	break;

case 11: //250 Kbps
	b1->setBitrate(250);
	break;

case 12: //275 Kbps
	b1->setBitrate(275);
	break;

case 13: //300 Kbps
	b1->setBitrate(300);
	break;

case 14: //500 Kbps
	b1->setBitrate(500);
	break;

case 15: //625 Kbps
	b1->setBitrate(625);
	break;

case 16: //800 Kbps
	b1->setBitrate(800);
	break;

case 17: //1 Mbps
	b1->setBitrate(1000);
	break;

case 18: //400 kbs
	b1->setBitrate(400);
	break;

default:
	b1->setBitrate(0);
	break;
}

		 }
private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
unsigned char tempSelectedIndex = 0;
tempSelectedIndex = this->comboBox2->SelectedIndex;
tempSelectedIndex = tempSelectedIndex+1; //one count offset
b1->setCANMode(tempSelectedIndex);
		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
unsigned char tempSelectedIndex = 0;
tempSelectedIndex = this->comboBox3->SelectedIndex;
tempSelectedIndex = tempSelectedIndex;//+1; //one count offset
b1->setTermination(tempSelectedIndex);
		 }
};
}