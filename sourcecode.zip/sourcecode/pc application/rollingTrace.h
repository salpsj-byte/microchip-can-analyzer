#pragma once

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace SimpleWinUSBDemo {

	/// <summary>
	/// Summary for rollingTrace
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class rollingTrace : public System::Windows::Forms::Form
	{
	private:
//		Form1 mparent;

	public:
bool pauseTraceWindow;

		rollingTrace(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~rollingTrace()
		{
			if (components)
			{
				delete components;
			}
		}
	public: System::Windows::Forms::DataGridView^  dataGridView1;
	protected: 

	private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip1;
	private: System::Windows::Forms::ToolStripMenuItem^  pauseTraceToolStripMenuItem;
	private: System::Windows::Forms::ToolStripMenuItem^  clearTraceToolStripMenuItem;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column2;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column3;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column4;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column5;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column6;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column7;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column8;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column9;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column10;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column11;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column12;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Column13;


























	private: System::ComponentModel::IContainer^  components;
	protected: 

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(rollingTrace::typeid));
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->contextMenuStrip1 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->pauseTraceToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->clearTraceToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->Column1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column2 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column4 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column5 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column6 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column7 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column8 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column9 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column10 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column11 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column12 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Column13 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->contextMenuStrip1->SuspendLayout();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->AllowUserToResizeColumns = false;
			this->dataGridView1->AllowUserToResizeRows = false;
			this->dataGridView1->BackgroundColor = System::Drawing::Color::White;
			this->dataGridView1->ColumnHeadersHeight = 25;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::DisableResizing;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(13) {this->Column1, 
				this->Column2, this->Column3, this->Column4, this->Column5, this->Column6, this->Column7, this->Column8, this->Column9, this->Column10, 
				this->Column11, this->Column12, this->Column13});
			this->dataGridView1->ContextMenuStrip = this->contextMenuStrip1;
			this->dataGridView1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->dataGridView1->Location = System::Drawing::Point(0, 0);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersVisible = false;
			this->dataGridView1->RowHeadersWidth = 35;
			this->dataGridView1->RowHeadersWidthSizeMode = System::Windows::Forms::DataGridViewRowHeadersWidthSizeMode::DisableResizing;
			this->dataGridView1->ScrollBars = System::Windows::Forms::ScrollBars::Vertical;
			this->dataGridView1->Size = System::Drawing::Size(924, 348);
			this->dataGridView1->TabIndex = 0;
			// 
			// contextMenuStrip1
			// 
			this->contextMenuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->pauseTraceToolStripMenuItem, 
				this->clearTraceToolStripMenuItem});
			this->contextMenuStrip1->Name = L"contextMenuStrip1";
			this->contextMenuStrip1->Size = System::Drawing::Size(174, 48);
//			this->contextMenuStrip1->Opening += gcnew System::ComponentModel::CancelEventHandler(this, &rollingTrace::contextMenuStrip1_Opening);
			// 
			// pauseTraceToolStripMenuItem
			// 
			this->pauseTraceToolStripMenuItem->Name = L"pauseTraceToolStripMenuItem";
			this->pauseTraceToolStripMenuItem->Size = System::Drawing::Size(173, 22);
			this->pauseTraceToolStripMenuItem->Text = L"Pause Trace";
			this->pauseTraceToolStripMenuItem->Click += gcnew System::EventHandler(this, &rollingTrace::pauseTraceToolStripMenuItem_Click);
			// 
			// clearTraceToolStripMenuItem
			// 
			this->clearTraceToolStripMenuItem->Name = L"clearTraceToolStripMenuItem";
			this->clearTraceToolStripMenuItem->Size = System::Drawing::Size(173, 22);
			this->clearTraceToolStripMenuItem->Text = L"Clear Trace";
			this->clearTraceToolStripMenuItem->Click += gcnew System::EventHandler(this, &rollingTrace::clearTraceToolStripMenuItem_Click);
			// 
			// Column1
			// 
			this->Column1->HeaderText = L"TRACE";
			this->Column1->Name = L"Column1";
			this->Column1->ReadOnly = true;
			this->Column1->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column1->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column1->Width = 50;
			// 
			// Column2
			// 
			this->Column2->HeaderText = L"ID";
			this->Column2->Name = L"Column2";
			this->Column2->ReadOnly = true;
			this->Column2->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column2->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			// 
			// Column3
			// 
			this->Column3->HeaderText = L"DLC";
			this->Column3->Name = L"Column3";
			this->Column3->ReadOnly = true;
			this->Column3->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column3->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column3->Width = 30;
			// 
			// Column4
			// 
			this->Column4->HeaderText = L"DATA 0";
			this->Column4->Name = L"Column4";
			this->Column4->ReadOnly = true;
			this->Column4->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column4->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column4->Width = 55;
			// 
			// Column5
			// 
			this->Column5->HeaderText = L"DATA 1";
			this->Column5->Name = L"Column5";
			this->Column5->ReadOnly = true;
			this->Column5->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column5->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column5->Width = 55;
			// 
			// Column6
			// 
			this->Column6->HeaderText = L"DATA 2";
			this->Column6->Name = L"Column6";
			this->Column6->ReadOnly = true;
			this->Column6->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column6->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column6->Width = 55;
			// 
			// Column7
			// 
			this->Column7->HeaderText = L"DATA 3";
			this->Column7->Name = L"Column7";
			this->Column7->ReadOnly = true;
			this->Column7->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column7->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column7->Width = 55;
			// 
			// Column8
			// 
			this->Column8->HeaderText = L"DATA 4";
			this->Column8->Name = L"Column8";
			this->Column8->ReadOnly = true;
			this->Column8->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column8->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column8->Width = 55;
			// 
			// Column9
			// 
			this->Column9->HeaderText = L"DATA 5";
			this->Column9->Name = L"Column9";
			this->Column9->ReadOnly = true;
			this->Column9->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column9->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column9->Width = 55;
			// 
			// Column10
			// 
			this->Column10->HeaderText = L"DATA 6";
			this->Column10->Name = L"Column10";
			this->Column10->ReadOnly = true;
			this->Column10->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column10->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column10->Width = 55;
			// 
			// Column11
			// 
			this->Column11->HeaderText = L"DATA 7";
			this->Column11->Name = L"Column11";
			this->Column11->ReadOnly = true;
			this->Column11->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column11->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column11->Width = 55;
			// 
			// Column12
			// 
			this->Column12->HeaderText = L"TIME STAMP (sec)";
			this->Column12->Name = L"Column12";
			this->Column12->ReadOnly = true;
			this->Column12->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column12->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column12->Width = 150;
			// 
			// Column13
			// 
			this->Column13->HeaderText = L"TIME DELTA (sec)";
			this->Column13->Name = L"Column13";
			this->Column13->ReadOnly = true;
			this->Column13->Resizable = System::Windows::Forms::DataGridViewTriState::False;
			this->Column13->SortMode = System::Windows::Forms::DataGridViewColumnSortMode::NotSortable;
			this->Column13->Width = 150;
			// 
			// rollingTrace
			// 
			this->AccessibleRole = System::Windows::Forms::AccessibleRole::None;
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->AutoValidate = System::Windows::Forms::AutoValidate::Disable;
			this->BackColor = System::Drawing::Color::White;
			this->CausesValidation = false;
			this->ClientSize = System::Drawing::Size(924, 348);
			this->ContextMenuStrip = this->contextMenuStrip1;
			this->Controls->Add(this->dataGridView1);
			this->DoubleBuffered = true;
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedToolWindow;
			this->Icon = (cli::safe_cast<System::Drawing::Icon^  >(resources->GetObject(L"$this.Icon")));
			this->ImeMode = System::Windows::Forms::ImeMode::Disable;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"rollingTrace";
			this->ShowInTaskbar = false;
			this->SizeGripStyle = System::Windows::Forms::SizeGripStyle::Hide;
			this->StartPosition = System::Windows::Forms::FormStartPosition::Manual;
			this->Text = L"Rolling Trace";
			this->FormClosing += gcnew System::Windows::Forms::FormClosingEventHandler(this, &rollingTrace::rollingTrace_Closing);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->contextMenuStrip1->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion

	private: System::Void pauseTraceToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
if (this->getPauseTraceWindow() == true)
{
	this->pauseTraceToolStripMenuItem->Text = "Pause Trace";
	this->setPauseTraceWindow(false);
}
else
{
	this->pauseTraceToolStripMenuItem->Text = "Start Trace";
	this->setPauseTraceWindow(true);
}
			 }

private: System::Void clearTraceToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
this->dataGridView1->Rows->Clear();
		 }

public: Void setPauseTraceWindow(bool passedInBool)
{
pauseTraceWindow = passedInBool;
}

public: bool getPauseTraceWindow(Void)
{
bool returnValue;
returnValue = pauseTraceWindow;
return(returnValue);
}
private: System::Void rollingTrace_Closing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e) {
			 
        e->Cancel=true;
        this->Hide();
		 }
//private: System::Void contextMenuStrip1_Opening(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
//		 }
};
}
