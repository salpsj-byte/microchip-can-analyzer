#pragma once
#define dNUMBER_FORMAT_HEX 0
#define dNUMBER_FORMAT_DECIMAL 1

//No header one or header two bytes
#define dSPI_CAN_PACKET_SIZE 19
#define dSPI_CAN_PACKET_CHECKSUM_LOCATION 18

//Defines used checking user input
#define dINPUT_TYPE_ID 0
#define dINPUT_TYPE_DLC 1
#define dINPUT_TYPE_DATA 2
#define dINPUT_TYPE_PERIOD 3
#define dINPUT_TYPE_REPEAT 4

//Defines used for the transmit/receive forms
#define dFORMAT_OR_DIRECTION_COLUMN_INDEX 0
#define dID_COLUMN_INDEX 1
#define dDLC_COLUMN_INDEX 2
#define dDATA0_COLUMN_INDEX 3
#define dDATA1_COLUMN_INDEX 4
#define dDATA2_COLUMN_INDEX 5
#define dDATA3_COLUMN_INDEX 6
#define dDATA4_COLUMN_INDEX 7
#define dDATA5_COLUMN_INDEX 8
#define dDATA6_COLUMN_INDEX 9
#define dDATA7_COLUMN_INDEX 10
#define dPERIOD_OR_TIMESTAMP_COLUMN_INDEX 11
#define dREPEAT_OR_DELTA_COLUMN_INDEX 12
#define dBUTTON_OR_COUNT_COLUMN_INDEX 13

#define dHEADER_BYTE_ONE 0x55
#define dHEADER_BYTE_TWO 0x46

////////////////////////////////
//Send to USB
#define dCHANGE_BIT_RATE_RSP 0xE1
#define dREAD_FW_VERSION_RSP 0xE8
#define dERROR_COUNT_STATUS 0xE6

#define dTRANSMIT_MESSAGE_RSP 0xE2
#define dRECEIVE_MESSAGE 0xE3
#define dTRIGGER_EVENT 0xE4
#define dSETUP_TRIGGER_RSP 0xE5
#define dREAD_REGISTER_DIRECTLY_RSP 0xE7
#define dDEBUG_MODE_RSP 0xF0
#define dI_AM_ALIVE_FROM_CAN 0xF5
#define dI_AM_ALIVE_FROM_USB 0xF7

////////////////////////////////
//Recieve from USB
#define dCHANGE_BIT_RATE 0xA1
#define dTRANSMIT_MESSAGE_PD 0xA2
#define dTRANSMIT_MESSAGE_EV 0xA3
#define dSETUP_TRIGGER 0xA4
#define dWRITE_REGISTER_DIRECTLY 0xA5
#define dREAD_REGISTER_DIRECTLY 0xA6
#define dTOGGLE_LED 0xA7
#define dSETUP_TERMINATION_RESISTANCE 0xA8
#define dREAD_FW_VERSION 0xA9
#define dCAN_RESET 0xAA
#define dCHANGE_CAN_MODE 0xAB
#define dSETUP_HW_FILTER 0xAC
#define dDEBUG_MODE 0xB0

#define dUSB_MICRO 1
#define dCAN_MICRO 2
#define dBOTH_PICMICROS 0x55



////////////////////////////////
		#define dNUMBER_OF_PERIODIC_MSGS 9
		#define dNUMBER_OF_PERIODIC_REPEAT_VARS 18
		#define dPERIODIC_FLAG 0
		#define dPERIODIC_VALUE 1
		#define dREPEAT_VALUE 2
		#define dCOUNTDOWN_COUNTER 3
		#define dCOMMAND 4
		#define dEIDH 5
		#define dEIDL 6
		#define dSIDH 7
		#define dSIDL 8
		#define dDLC 9
		#define dDATA0 10
		#define dDATA1 11
		#define dDATA2 12
		#define dDATA3 13
		#define dDATA4 14
		#define dDATA5 15
		#define dDATA6 16
		#define dDATA7 17

////////////////////////////////
//For CAN Mode Command
#define dCAN_MODE_CONFIG 1
#define dCAN_MODE_NORMAL 2
#define dCAN_MODE_LISTEN_ONLY 3



////////////////////////////////
#define dTRIGGER_TEST_ONE 1
#define dTRIGGER_TEST_TWO 2
#define dTRIGGER_TEST_THREE 3
#define dTRIGGER_TEST_FOUR 4



////////////////////////////////
//For LED Command dTOGGLE_LED
#define dLED_ALL 0x55
#define dLED_USB_ONE 2
#define dLED_USB_TWO 1
#define dLED_CAN_RGB1 3
#define dLED_CAN_RGB2 4
#define dLED_CAN_RGB3 5

#define dLED_STATE_ON 1
#define dLED_STATE_OFF 2
#define dLED_STATE_GREEN 3
#define dLED_STATE_YELLOW 4
#define dLED_STATE_RED 5


////////////////////////////////
#define dCAN_33_3KBPS_40MHZ 1
#define dCAN_50KBPS_40MHZ 2
#define dCAN_80KBPS_40MHZ 3
#define dCAN_83_3KBPS_40MHZ 4
#define dCAN_100KBPS_40MHZ 5
#define dCAN_125KBPS_40MHZ 6
#define dCAN_150KBPS_40MHZ 7
#define dCAN_175KBPS_40MHZ 8
#define dCAN_200KBPS_40MHZ 9
#define dCAN_225KBPS_40MHZ 10
#define dCAN_250KBPS_40MHZ 11
#define dCAN_275KBPS_40MHZ 12
#define dCAN_300KBPS_40MHZ 13
#define dCAN_500KBPS_40MHZ 14
#define dCAN_1000KBPS_40MHZ 15

////////////////////////////////
	extern unsigned int TransmitUSBMessageLifeCounter;
	extern unsigned int ReceivedCANMessageLifeCounter;
	extern unsigned int TransmitCANMessageLifeCounter;
	extern unsigned int ReceivedUSBMessageLifeCounter;
	extern unsigned int EatBadMsgLifeCounter;